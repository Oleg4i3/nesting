#!/bin/bash
cd /home/claude/nest
node train_v2.js pB_16_8 pd1 40 1 16,8 pd1 > results/tr_pB_16_8.log 2>&1 &
node train_v2.js pB_32_16 pd1 40 1 32,16 pd1 > results/tr_pB_32_16.log 2>&1 &
wait
