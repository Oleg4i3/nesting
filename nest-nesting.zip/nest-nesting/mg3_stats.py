import json,glob,math,random,itertools,statistics as st
D=json.load(open('ext/zscen/dens.json'))
rows=[]
M2={}
for f in glob.glob('results/mg2_part*.jsonl'):
    for l in open(f): r=json.loads(l); M2[r['name']]=r['res']
for f in glob.glob('results/abl_part*.jsonl'):
    for l in open(f):
        r=json.loads(l); nm=r['name'].split('|')[0]; s,k,sd,x=nm.split('/')
        sp=[v for v in D[f"mg_{r['rot']}_{s}_{k}_{sd}_{x}"] if v is not None]
        r['sp_mean']=sum(sp)/3; r['sp_best']=max(sp)
        r['res']={'lns':M2[r['name']]['lns'],'ctrl':r['res']['ctrl'],'net':r['res']['tm'],'netall':r['res']['all']}; rows.append(r)
rows.sort(key=lambda r:r['name'])
rng=random.Random(12345); B=200000
def val(r,m): return r['sp_mean'] if m=='spMean' else r['sp_best'] if m=='spBest' else r['res'][m]
def signflip_p(d,exact_max=16):
    n=len(d); obs=abs(sum(d))
    nz=[x for x in d if x!=0]
    if len(nz)<=exact_max:
        c=0;t=0
        for sg in itertools.product((1,-1),repeat=len(nz)):
            t+=1; c+= abs(sum(s*x for s,x in zip(sg,nz)))>=obs-1e-12
        return c/t
    c=0
    for _ in range(B):
        s=sum(x if rng.random()<.5 else -x for x in d)
        if abs(s)>=obs-1e-12: c+=1
    return (c+1)/(B+1)
def boot(d,reps=20000):
    n=len(d); m=sorted(sum(d[rng.randrange(n)] for _ in range(n))/n for _ in range(reps))
    return m[int(.025*reps)],m[int(.975*reps)]
def test(rs,a,b):
    d=[val(r,a)-val(r,b) for r in rs]
    out=dict(n=len(d),mean=sum(d)/len(d),median=st.median(d),up=sum(x>0.05 for x in d),down=sum(x<-0.05 for x in d))
    out['p']=signflip_p(d); out['ci']=boot(d)
    # кластерний тест: усереднення в межах набору лекал (8 кластерів), точний знако-перестановочний
    cl={}
    for r,x in zip(rs,d): cl.setdefault(r['set'],[]).append(x)
    cm=[sum(v)/len(v) for v in cl.values()]
    out['p_cl']=signflip_p(cm); out['ncl']=len(cm); out['cl_pos']=sum(x>0 for x in cm)
    return out
comps=[('net','ctrl'),('net','lns'),('lns','spMean'),('net','spMean'),('net','spBest'),('ctrl','spMean'),('lns','ctrl')]
slices={'ALL':lambda r:True}
for v in ('any','deg5'): slices['rot='+v]=lambda r,v=v:r['rot']==v
for v in ('both','pholes'): slices['kind='+v]=lambda r,v=v:r['kind']==v
for v in (2,3): slices['copies=%d'%v]=lambda r,v=v:r['copies']==v
for a in ('any','deg5'):
    for k in ('both','pholes'): slices[f'{a}&{k}']=lambda r,a=a,k=k:r['rot']==a and r['kind']==k
res={}
for a,b in comps:
    for sn,f in slices.items():
        res[f'{a}-{b}|{sn}']=test([r for r in rows if f(r)],a,b)
# Holm по всіх зрізах для кожного порівняння
for a,b in comps:
    keys=[k for k in res if k.startswith(f'{a}-{b}|') and not k.endswith('|ALL')]
    ps=sorted((res[k]['p'],k) for k in keys); m=len(ps); prev=0
    for i,(p,k) in enumerate(ps):
        prev=max(prev,min(1,(m-i)*p)); res[k]['p_holm']=prev
json.dump(res,open('results/mg3_stats.json','w'),indent=1)
for k,v in res.items():
    print(f"{k:30s} n={v['n']:2d} Δ={v['mean']:+.2f} [{v['ci'][0]:+.2f},{v['ci'][1]:+.2f}] мед {v['median']:+.2f} ↑{v['up']}/↓{v['down']} p={v['p']:.4f} holm={v.get('p_holm',float('nan')):.3f} | кластери {v['cl_pos']}/{v['ncl']} p_cl={v['p_cl']:.3f}")
