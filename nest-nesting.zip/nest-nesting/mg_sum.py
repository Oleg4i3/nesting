# Зведення комбінованого тесту: наші методи (results/mg_*_part*.jsonl) і Sparrow (ext/zscen/dens.json). python3 mg_sum.py
import json,glob,statistics as st,collections,math
rows=[json.loads(l) for f in glob.glob('results/mg_*_part*.jsonl') for l in open(f)]
try: dens=json.load(open('ext/zscen/dens.json'))
except Exception: dens={}
R={}
for r in rows:
    nm,rot=r['name'].split('|'); set_,kind,seed,cp=nm.split('/'); cp=int(cp[1:])
    d={k:(100*v['dens'] if v and v.get('dens') else None) for k,v in r['res'].items()}
    sid=f'mg_{rot}_{set_}_{kind}_{seed}_x{cp}'; sp=[x for x in dens.get(sid,[]) if x is not None]
    if sp: d['sp_mean']=st.mean(sp); d['sp_best']=max(sp)
    R[(rot,set_,kind,cp)]=d
M=['net:r3a','net:e3','bl','lns','hyb:r3a','hyb:e3','sp_mean','sp_best']
def mean(xs): return st.mean(xs) if xs else float('nan')
def se(xs): return st.stdev(xs)/math.sqrt(len(xs)) if len(xs)>1 else 0
def pair(a,b,sub):
    d=[v[a]-v[b] for k,v in R.items() if sub(k) and v.get(a) is not None and v.get(b) is not None]
    return (mean(d),se(d),len(d))
print('n задач',len(R),'зі Sparrow',sum(1 for v in R.values() if 'sp_best' in v))
for rot in ['any','deg5']:
    for kind in ['plain','both']:
        sub=lambda k,rot=rot,kind=kind:k[0]==rot and k[2]==kind
        xs={m:[v[m] for k,v in R.items() if sub(k) and v.get(m) is not None] for m in M}
        print(f'\n== кути {rot}, рулон {kind}: середня щільність, %  (n={len(xs["bl"])})')
        print('  '+'  '.join(f'{m}:{mean(xs[m]):.1f}' for m in M if xs[m]))
        for a,b in [('hyb:e3','bl'),('hyb:e3','lns'),('hyb:e3','hyb:r3a'),('net:e3','net:r3a'),('hyb:e3','sp_mean'),('hyb:e3','sp_best'),('bl','sp_mean'),('lns','sp_mean')]:
            m,s,n=pair(a,b,sub)
            if n: print(f'  {a} − {b}: {m:+.2f} ± {s:.2f} (n={n})')
print('\n== за наборами (усі кути й рулони), hyb:e3 − sp_mean / hyb:e3 − bl')
for set_ in sorted({k[1] for k in R}):
    sub=lambda k,set_=set_:k[1]==set_
    a=pair('hyb:e3','sp_mean',sub);b=pair('hyb:e3','bl',sub);c=pair('bl','sp_mean',sub)
    print(f'  {set_:16s} hyb−sp {a[0]:+.2f}±{a[1]:.2f} (n={a[2]})   hyb−bl {b[0]:+.2f}±{b[1]:.2f}   bl−sp {c[0]:+.2f}±{c[1]:.2f}')
print('\n== за кількістю виробів')
for cp in [1,2,3]:
    sub=lambda k,cp=cp:k[3]==cp
    a=pair('hyb:e3','sp_mean',sub);b=pair('hyb:e3','bl',sub);c=pair('bl','sp_mean',sub)
    print(f'  x{cp}: hyb−sp {a[0]:+.2f}±{a[1]:.2f} (n={a[2]})  hyb−bl {b[0]:+.2f}±{b[1]:.2f}  bl−sp {c[0]:+.2f}±{c[1]:.2f}')
json.dump({f'{k[0]}|{k[1]}|{k[2]}|x{k[3]}':v for k,v in R.items()},open('results/mg_table.json','w'))
