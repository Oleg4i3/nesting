// Permutation importance ознак: перемішуємо значення однієї ознаки між усіма кандидатами val, міряємо ріст loss і падіння top-1.
// node permimp.js <valTag> <weights.json> [повторів=3]
const fs=require('fs'),X=require('./nnx.js'),Fe=require('./features.js'),NN=require('./nn.js');const NF=Fe.NF,tag=process.argv[2],REP=+process.argv[4]||3;
const out=[];for(const f of fs.readdirSync('data').filter(f=>f.startsWith(`expert_${tag}_p`)&&f.endsWith('.json'))){const m=JSON.parse(fs.readFileSync('data/'+f,'utf8')),buf=fs.readFileSync('data/'+f.replace('.json','.bin')),all=new Float32Array(buf.buffer.slice(buf.byteOffset,buf.byteOffset+buf.byteLength));
 for(const s of m.meta){if(s.split!=='val')continue;let bad=false;for(let i=s.offset;i<s.offset+s.count*NF;i++)if(!Number.isFinite(all[i])){bad=true;break}if(bad)continue;const pos=new Uint8Array(s.count);s.pos.forEach(i=>{pos[i]=1});out.push({F:Float32Array.from(all.subarray(s.offset,s.offset+s.count*NF)),count:s.count,pos})}}
const net=X.MLPX.fromJSON(JSON.parse(fs.readFileSync(process.argv[3],'utf8')));
const ev=()=>{let l=0,h=0;for(const s of out){const e=net.evalSample(s);l+=e.loss;h+=e.hit}return{loss:l/out.length,hit:100*h/out.length}};
const base=ev(),rng=NN.mulberry32(5);console.log(`${process.argv[3]}: val ${out.length}, loss ${base.loss.toFixed(4)}, top1 ${base.hit.toFixed(1)}%`);
// пул значень кожної ознаки
const rows=[];for(let si=0;si<out.length;si++)for(let c=0;c<out[si].count;c++)rows.push([si,c]);
const MODE=process.argv[5]||'global';const res=[];
for(let j=0;j<NF;j++){let dl=0,dh=0;const orig=out.map(s=>Float32Array.from(s.F));
  for(let r=0;r<REP;r++){if(MODE==='step'){for(const s of out){const v=[];for(let c=0;c<s.count;c++)v.push(s.F[c*NF+j]);for(let i=v.length-1;i>0;i--){const k=Math.floor(rng()*(i+1));[v[i],v[k]]=[v[k],v[i]]}for(let c=0;c<s.count;c++)s.F[c*NF+j]=v[c]}const e=ev();dl+=e.loss-base.loss;dh+=base.hit-e.hit;out.forEach((s,i)=>s.F.set(orig[i]));continue}
    const vals=rows.map(([si,c])=>orig[si][c*NF+j]);for(let i=vals.length-1;i>0;i--){const k=Math.floor(rng()*(i+1));[vals[i],vals[k]]=[vals[k],vals[i]]}
    rows.forEach(([si,c],i)=>{out[si].F[c*NF+j]=vals[i]});const e=ev();dl+=e.loss-base.loss;dh+=base.hit-e.hit}
  out.forEach((s,i)=>s.F.set(orig[i]));res.push({n:Fe.FEATURE_NAMES[j],dl:dl/REP,dh:dh/REP})}
res.sort((a,b)=>b.dl-a.dl);for(const r of res)console.log(`${r.n.padEnd(22)} Δloss ${r.dl>=0?'+':''}${r.dl.toFixed(4)}  Δtop1 ${r.dh>=0?'-':'+'}${Math.abs(r.dh).toFixed(1)} пп`);
