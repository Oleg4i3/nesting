// Етап 4: пазли, де зони (півмісяці, S-смуги, плями, нерівні краї) вирізано ДО розбиття (zgen.py). Мітка = еталон (+ за потреби LNS).
// node expert_data12.js <ч> <частин> <тег> <тег_zgen_train> <тег_zgen_val> [msLNS=0]
// node expert_data9.js <ч> <частин> <тег> [N=300] [msSA=5000] [msLNS=10000]
const fs=require('fs'),Fe=require('./features.js'),N=require('./raster.js'),C=require('./common.js'),P=require('./puzzle.js'),B=require('./baselines.js'),L=require('./lns2.js');
const part=+process.argv[2]||0,parts=+process.argv[3]||1,tag=process.argv[4]||'r3',NT=+process.argv[5]||300,MSA=+process.argv[6]||5000,MLN=+process.argv[7]||10000;
const NF=Fe.NF,CELL=N.CELL,NEG_TOP=150,NEG_RND=150,MPER=300,rng=P.mulberry32(888+part);
function seqFromLayout(pz,vars,lay){const t=lay.map((x,i)=>({pi:i,vi:x.vi,A:x.A,cy:x.cy}));t.sort((a,b)=>a.cy-b.cy||a.A-b.A);return t}
function replay(pz,seq){
  const board=new Fe.Board(pz.width,4000);let bz=0;for(const bp of (pz.blocked||[])){Fe.blockPoly(board,bp);bz=Math.max(bz,Math.ceil(N.vertexBBox({vertices:bp.vertices.concat((bp.bezierControls||[]).filter(Boolean))}).maxY/CELL)+2)}
  const vars=pz.pieces.map(p=>N.makeVariants(p,N.allowedFor(p,pz.rules)));
  let rem=[];pz.pieces.forEach((_,i)=>{if(vars[i].some(v=>v.w<=board.W))rem.push(i)});
  const ctx=Fe.makeCtx(vars,board.W,rem,board);ctx.noSlit=true;const out=[];
  for(const st of seq){
    let c=Fe.genCandidates(board,vars,rem,MPER);if(!c.length)c=Fe.genCandidates(board,vars,rem,MPER,2);if(!c.length&&bz>board.len)c=Fe.genCandidates(board,vars,rem,MPER,bz-board.len);
    let idx=c.findIndex(x=>x.pi===st.pi&&x.vi===st.vi&&x.A===st.A&&x.cy===st.cy);
    if(idx<0){c.push({pi:st.pi,vi:st.vi,A:st.A,cy:st.cy,ct:board.contact(vars[st.pi][st.vi],st.A,st.cy),cheap:0});idx=c.length-1}
    const pos=c[idx];c.splice(idx,1);c.sort((a,b)=>b.cheap-a.cheap);
    const top=c.slice(0,NEG_TOP),rest=c.slice(NEG_TOP);for(let i=rest.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[rest[i],rest[j]]=[rest[j],rest[i]]}
    const sel=[pos,...top,...rest.slice(0,NEG_RND)],T=Fe.minDim(vars,rem),F=new Float32Array(sel.length*NF);
    for(let i=0;i<sel.length;i++)Fe.fillFeatures(board,ctx,sel[i],rem.length,T,F,i*NF);
    out.push({F,count:sel.length,pos:[0]});board.place(vars[st.pi][st.vi],st.A,st.cy);rem=rem.filter(x=>x!==st.pi)}
  return out}
const Z=require('./zpuzzle.js');
const zt=process.argv[5]||'z1',zv=process.argv[6]||'zv',MLNS=+process.argv[7]||0;
const jobs=[];Z.load(zt).forEach(r=>jobs.push({split:'train',rec:r}));Z.load(zv).forEach(r=>jobs.push({split:'val',rec:r}));
const meta=[],chunks=[];let offset=0,n=0;const wins={};const t0=Date.now();
jobs.forEach((j,ji)=>{
  if(ji%parts!==part)return;let pz;try{pz=Z.build(j.rec)}catch(e){return}
  const pcs=pz.pieces,W=pz.width,rules=pz.rules,bl=pz.blocked||[],vars=pcs.map(p=>N.makeVariants(p,N.allowedFor(p,rules)));
  const cand=[];
  const pl=pz.solution.map((s,i)=>{const vi=vars[i].findIndex(v=>Math.abs(v.rot-s.rot)<1e-9&&v.mirror===s.mirror);if(vi<0)return null;const v=vars[i][vi];return{vi,A:v.x0+s.px/CELL,cy:v.y0+s.py/CELL,h:v.h}});
  if(!pl.some(x=>!x))cand.push({src:'P',len:Math.max(...pl.map(x=>x.cy+x.h))*CELL,lay:pl});
  if(MLNS>0){const q=L.solveLNS(pcs,rules,{width:W,blocked:bl,budgetMs:MLNS,seed:j.rec.seed,recreate:'BL',kMin:6,kMax:14,T0:0.6});cand.push({src:'L',len:q.lengthPx,lay:q.layout})}
  if(!cand.length)return;cand.sort((a,b)=>a.len-b.len);const best=cand[0];wins[best.src]=(wins[best.src]||0)+1;
  for(const s of replay(pz,seqFromLayout(pz,vars,best.lay))){meta.push({split:j.split,kind:'z'+j.rec.kind+(j.rec.big?'b':''),lvl:j.rec.level,seed:j.rec.seed,count:s.count,pos:s.pos,offset});chunks.push(Buffer.from(s.F.buffer));offset+=s.count*NF}
  n++;if(n%25===0)console.log(`[${part}] ${n} пазлів, зразків ${meta.length}, перемоги ${JSON.stringify(wins)}, ${((Date.now()-t0)/1000).toFixed(0)}с`)});
fs.writeFileSync(`data/expert_${tag}_p${part}.bin`,Buffer.concat(chunks));
fs.writeFileSync(`data/expert_${tag}_p${part}.json`,JSON.stringify({NF,meta,n,wins}));
console.log(`[${part}] готово ${n} пазлів, ${meta.length} зразків, перемоги ${JSON.stringify(wins)}`);
