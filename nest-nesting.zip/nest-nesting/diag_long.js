// Малий прогін: чи є запас при довшому бюджеті. node diag_long.js <ч> <частин> [ms=90000]
const fs=require('fs'),P=require('./puzzle.js'),N=require('./raster.js'),X=require('./nnx.js'),B=require('./baselines.js'),L=require('./lns2.js'),G=require('./garment.js');
const part=+process.argv[2]||0,parts=+process.argv[3]||1,ms=+process.argv[4]||90000;
const net=X.MLPX.fromJSON(JSON.parse(fs.readFileSync('weights/v2/e1big.json','utf8')));
const suit=N.loadLayout(fs.readFileSync('/mnt/user-data/uploads/suit-manual.json','utf8'));
const base=suit.map(p=>{const b=N.vertexBBox(p);return N.translatePoly(p,-Math.floor(b.minX/10)*10,-Math.floor(b.minY/10)*10)});
const RG=[{rotations:'any',mirror:false},{rotations:'half',mirror:false},{rotations:'none',mirror:false}];
const tasks=[
 {name:'костюм N=1 повороти 90°',pcs:base,W:290,rules:RG[0]},{name:'костюм N=1 без поворотів',pcs:base,W:290,rules:RG[2]},
 {name:'костюм N=2 повороти 90°',pcs:[...base,...base],W:290,rules:RG[0]},
 ...[300001,300002,300003,300004].map((s,i)=>{const g=G.generate(s,{rules:RG[i%3]});return{name:'викрійки '+s,pcs:g.pieces,W:g.width,rules:g.rules}})];
const fd=fs.openSync(`results/diag_part${part}.jsonl`,'a');
tasks.forEach((t,i)=>{if(i%parts!==part)return;const row={name:t.name,res:{}};
  const run=(nm,fn)=>{const r=fn();const e=N.evaluateLayout(P.placementsToPolys(t.pcs,r.placements),{width:t.W,height:6000,rollWidth:t.W});row.res[nm]={eff:e.valid?e.efficiency:null,len:e.extent.length}};
  run('BL відпал',()=>B.solveBLSA(t.pcs,t.rules,{width:t.W,maxLength:6000,budgetMs:ms,seed:7}));
  run('LNS + BL',()=>L.solveLNS(t.pcs,t.rules,{width:t.W,maxLength:6000,budgetMs:ms,seed:7,recreate:'BL',kMin:6,kMax:14,T0:0.6}));
  run('LNS + мережа',()=>L.solveLNS(t.pcs,t.rules,{width:t.W,maxLength:6000,budgetMs:ms,seed:7,recreate:'GUIDED',net,temp:0.5,kMin:4,kMax:10,T0:0.6}));
  fs.writeSync(fd,JSON.stringify(row)+'\n');console.log(`[${part}] ${t.name}: `+Object.entries(row.res).map(([k,v])=>k+' '+(v.eff*100).toFixed(1)+'/'+v.len).join(' | '))});
