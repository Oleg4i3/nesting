// Пілот способів поєднання мережі з пошуком на задачах «кілька виробів» (ті самі задачі й зерна, що в mg).
// node hybpilot.js <ч> <частин> <тег> <net.json> <ms> <набори> <копій> <кути> <рулони>
const fs = require('fs'), X = require('./nnx.js'), T = require('./rl_tasks.js'), Pf = require('./portfolio.js'), B = require('./baselines.js'), L = require('./lns2.js');
const part = +process.argv[2], parts = +process.argv[3], tag = process.argv[4], net = X.MLPX.fromJSON(JSON.parse(fs.readFileSync(process.argv[5], 'utf8'))), ms = +process.argv[6];
const sets = process.argv[7].split(','), copies = process.argv[8].split(',').map(Number), rots = process.argv[9].split(','), kinds = process.argv[10].split(',');
const out = `results/${tag}_part${part}.jsonl`, done = new Set(fs.existsSync(out) ? fs.readFileSync(out, 'utf8').trim().split('\n').filter(Boolean).map(l => JSON.parse(l).name) : []), fd = fs.openSync(out, 'a'), jobs = [];
for (const rot of rots) for (const set of sets) for (const kind of kinds) for (const cp of copies) jobs.push({ set, kind, seed: 91, n: set === 'suit' ? 13 : 99, rot, copies: cp });
jobs.forEach((j, ji) => {
  if (ji % parts !== part) return;
  const t = T.build(j); if (done.has(t.name + '|' + j.rot)) return; const o = { width: t.W, maxLength: 4000, seed: 7, blocked: t.blocked }, ev = pl => { const r = T.evaluate(t, pl); return r ? 100 * r.dens : null; };
  const row = { name: t.name + '|' + j.rot, set: j.set, kind: j.kind, copies: j.copies, rot: j.rot, res: {} };
  const t0 = Date.now(), bm = Pf.solvePortfolio(t.pcs, t.rules, net, { width: t.W, maxLength: 4000, blocked: t.blocked, maxMs: 15000 }), tb = Date.now() - t0;
  row.res.net = ev(bm.placements); row.res.tb = tb;
  const init = new Array(t.pcs.length).fill(null); bm.seq.forEach(q => { init[q.pi] = { vi: q.vi, A: q.A, cy: q.cy }; });
  const lns = (extra, warm) => ev(L.solveLNS(t.pcs, t.rules, Object.assign({}, o, extra, warm ? { init, budgetMs: Math.max(1000, ms - tb) } : { budgetMs: ms })).placements);
  row.res.bl = ev(B.solveBLSA(t.pcs, t.rules, Object.assign({}, o, { budgetMs: ms })).placements);
  row.res.blsa_net = ev(B.solveBLSA(t.pcs, t.rules, Object.assign({}, o, { budgetMs: Math.max(1000, ms - tb), initOrder: bm.seq.map(q => q.pi), T0: 1.0 })).placements);
  row.res.lns = lns({ recreate: 'BL', kMin: 6, kMax: 14, T0: 0.6 }, false);
  const wb = { kMin: 4, kMax: 10, T0: 0.25 };
  row.res.hyb = lns(Object.assign({ recreate: 'BL' }, wb), true);
  row.res.hybG = lns(Object.assign({ recreate: 'GUIDED', net, temp: 0.3 }, wb), true);
  row.res.hybG1 = lns(Object.assign({ recreate: 'GUIDED', net, temp: 1.0 }, wb), true);
  row.res.hybM = lns(Object.assign({ recreate: 'MIX', mixP: 0.5, net, temp: 0.3 }, wb), true);
  row.res.coldM = lns({ recreate: 'MIX', mixP: 0.5, net, temp: 0.3, kMin: 6, kMax: 14, T0: 0.6 }, false);
  fs.writeSync(fd, JSON.stringify(row) + '\n'); console.log(row.name, Object.entries(row.res).filter(([k]) => k !== 'tb').map(([k, v]) => k + ' ' + (v ? v.toFixed(1) : '—')).join(' | '));
});
