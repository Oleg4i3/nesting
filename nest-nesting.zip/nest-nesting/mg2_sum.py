import json,glob,math,collections,statistics as st
D=json.load(open('ext/zscen/dens.json'))
rows=[]
for f in glob.glob('results/mg2_part*.jsonl'):
    for l in open(f):
        r=json.loads(l); nm=r['name'].split('|')[0]; s,k,sd,x=nm.split('/')
        id=f"mg_{r['rot']}_{s}_{k}_{sd}_{x}"
        sp=[v for v in D.get(id,[]) if v is not None]
        if len(sp)<3: print('skip',id,sp); continue
        r['sp_mean']=sum(sp)/len(sp); r['sp_best']=max(sp); rows.append(r)
print(len(rows),'tasks')
M=['lns','hyb','afterBL','afterM']
def mean(a): return sum(a)/len(a)
def se(a): return (st.stdev(a)/math.sqrt(len(a))) if len(a)>1 else 0
def line(lab,rs):
    out=f"{lab:22s} n={len(rs):2d} "
    for m in M: out+=f"{m} {mean([r['res'][m] for r in rs]):5.1f} "
    out+=f"| spMean {mean([r['sp_mean'] for r in rs]):5.1f} spBest {mean([r['sp_best'] for r in rs]):5.1f}"
    print(out)
line('ALL',rows)
for key in ['rot','kind','copies','set']:
    for v in sorted(set(r[key] for r in rows)): line(f'{key}={v}',[r for r in rows if r[key]==v])
print('\nпарні різниці (пп), середнє ± SE, виграш/програш:')
def pd(a,b,rs):
    d=[a(r)-b(r) for r in rs]; return f"{mean(d):+.2f}±{se(d):.2f} (↑{sum(x>0.05 for x in d)}/↓{sum(x<-0.05 for x in d)}/{len(d)})"
for lab,a,b in [('afterM-afterBL',lambda r:r['res']['afterM'],lambda r:r['res']['afterBL']),
 ('afterM-lns',lambda r:r['res']['afterM'],lambda r:r['res']['lns']),
 ('hyb-lns',lambda r:r['res']['hyb'],lambda r:r['res']['lns']),
 ('afterM-spMean',lambda r:r['res']['afterM'],lambda r:r['sp_mean']),
 ('afterM-spBest',lambda r:r['res']['afterM'],lambda r:r['sp_best']),
 ('lns-spMean',lambda r:r['res']['lns'],lambda r:r['sp_mean']),
 ('hyb-spMean',lambda r:r['res']['hyb'],lambda r:r['sp_mean'])]:
    print(lab,'ALL',pd(a,b,rows))
    for key in ['rot','kind','copies']:
        for v in sorted(set(r[key] for r in rows)): print('   ',key,v,pd(a,b,[r for r in rows if r[key]==v]))
