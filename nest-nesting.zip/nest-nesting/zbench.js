// Порівняння методів на пазлах із зонами різної форми (відкладені зерна).
// node zbench.js <ч> <частин> <zgen-тег> <models name=path,...> [ms=10000] [count=all] [out=zbench]
// Методи: net:<ім'я> (портфель), bl (BL-відпал), lns (LNS+BL), hyb:<ім'я> (мережа → LNS)
const fs = require('fs'), X = require('./nnx.js'), N = require('./raster.js'), P = require('./puzzle.js'), Pf = require('./portfolio.js'), B = require('./baselines.js'), L = require('./lns2.js'), Z = require('./zones.js'), ZP = require('./zpuzzle.js');
const part = +process.argv[2] || 0, parts = +process.argv[3] || 1, tag = process.argv[4];
const models = (process.argv[5] || '').split(',').filter(Boolean).map(s => { const [n, p] = s.split('='); return { n, net: X.MLPX.fromJSON(JSON.parse(fs.readFileSync(p, 'utf8'))) }; });
const ms = +process.argv[6] || 10000, CNT = +process.argv[7] || 1e9, outName = process.argv[8] || 'zbench';
const METHODS = (process.env.METHODS || 'net,bl,lns,hyb').split(',');
const out = `results/${outName}_part${part}.jsonl`, fd = fs.openSync(out, 'a');
const recs = ZP.load(tag).slice(0, CNT);
recs.forEach((rec, ji) => {
  if (ji % parts !== part) return;
  let pz; try { pz = ZP.build(rec); } catch (e) { return; }
  const W = pz.width, pcs = pz.pieces, rules = pz.rules, zones = pz.blocked, area = pcs.reduce((s, p) => s + N.polygonArea(p), 0);
  const ev = pl => { if (!pl || pl.filter(Boolean).length !== pcs.length) return null; const e = Z.evaluateWithZones(pcs, pl, zones, W); return e.valid ? { dens: area / (W * e.len), len: e.len } : null; };
  const pe = ev(pz.solution);
  const row = { name: `${rec.kind}/${rec.seed}`, kind: rec.kind, seed: rec.seed, n: pcs.length, big: rec.big, zoneFrac: rec.zoneFrac, planted: pe ? pe.dens : null, res: {} };
  const o = { width: W, maxLength: 6000, seed: 7, blocked: zones };
  const bms = {};
  for (const m of models) {
    if (!METHODS.includes('net') && !METHODS.includes('hyb')) break;
    const t0 = Date.now(); const bm = Pf.solvePortfolio(pcs, rules, m.net, { width: W, maxLength: 6000, blocked: zones, maxMs: 15000 }); const tb = Date.now() - t0; bms[m.n] = { bm, tb };
    if (METHODS.includes('net')) row.res['net:' + m.n] = Object.assign({ ms: tb, how: bm.how }, ev(bm.placements));
  }
  let t0;
  if (METHODS.includes('bl')) { t0 = Date.now(); row.res.bl = Object.assign({ ms: 0 }, ev(B.solveBLSA(pcs, rules, Object.assign({}, o, { budgetMs: ms })).placements), { ms: Date.now() - t0 }); }
  if (METHODS.includes('lns')) { t0 = Date.now(); row.res.lns = Object.assign({}, ev(L.solveLNS(pcs, rules, Object.assign({}, o, { budgetMs: ms, recreate: 'BL', kMin: 6, kMax: 14, T0: 0.6 })).placements), { ms: Date.now() - t0 }); }
  if (METHODS.includes('hyb')) for (const m of models) {
    const { bm, tb } = bms[m.n]; const init = new Array(pcs.length).fill(null); bm.seq.forEach(s => { init[s.pi] = { vi: s.vi, A: s.A, cy: s.cy }; });
    row.res['hyb:' + m.n] = Object.assign({}, ev(L.solveLNS(pcs, rules, Object.assign({}, o, { budgetMs: Math.max(1000, ms - tb), recreate: 'BL', kMin: 4, kMax: 10, T0: 0.25, init })).placements), { ms: ms });
  }
  fs.writeSync(fd, JSON.stringify(row) + '\n');
  console.log(row.name, 'planted', row.planted && row.planted.toFixed(3), Object.entries(row.res).map(([k, v]) => k + ' ' + (v.dens ? (100 * v.dens / row.planted).toFixed(1) : '—')).join('  '));
});
