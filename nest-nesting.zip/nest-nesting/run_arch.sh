#!/bin/bash
cd /home/claude/nest
q() { for spec in "$@"; do IFS=: read name act hid <<< "$spec"; ACT=$act node train_v3.js a_$name r1 16 1 $hid r1 > results/arch2_$name.log 2>&1; done; }
q relu_16_8:relu:16,8 silu_16_8:silu:16,8 tanh_8:tanh:8 softsign_16_8:softsign:16,8 &
q tanh_16_8:tanh:16,8 tanh_32_16:tanh:32,16 tanh_16_8_4:tanh:16,8,4 &
wait
