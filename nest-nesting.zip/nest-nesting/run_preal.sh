#!/bin/bash
cd /home/claude/nest
M=r3a=weights/v2/r3a.json,zA_16_8=weights/v2/zA_16_8.json,pB_16_8=weights/v2/pB_16_8.json,pB_32_16=weights/v2/pB_32_16.json
for part in 0 1; do
 ( for rot in any deg5; do ROT90=1 NONRECT=1 node rl_eval.js $part 2 preal_$rot $rot pholes,pragged 91,92 $M 6000 fs_jaeger,fs_charlie,fs_simon,fs_hugo,suit r3a,pB_16_8,pB_32_16 > results/preal_${rot}_$part.log 2>&1; done ) &
done
wait
