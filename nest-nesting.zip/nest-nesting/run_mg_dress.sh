#!/bin/bash
cd /home/claude/nest
M=r3a=weights/v2/r3a.json,e3=weights/v2/e3_mix_16_8.json
for part in 0 1; do
 ( for rot in any deg5; do COPIES=1,2,3 ROT90=1 node rl_eval.js $part 2 mg_$rot $rot plain,both 91 $M 6000 fs_korf_dress r3a,e3 > results/mgd_${rot}_$part.log 2>&1; done ) &
done
wait
for tag in mg_any_fs_korf_dress mg_deg5_fs_korf_dress; do bash ext/z_sparrow_run.sh $tag 10; done
python3 ext/z_sparrow_eval.py > results/mgd_sparrow_eval.log 2>&1
echo DONE > results/mgd_done.txt
