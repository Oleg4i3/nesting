#!/bin/bash
# Короткий підбір архітектури для мережі відновлення (30 епох, змішане навчання, дані rep2)
cd /home/claude/nest
run(){ name=$1; hid=$2; act=$3; skip=$4; ACT=$act SKIP=$skip node train_v3.js $name rep2 rep2 30 1 $hid 0 > logs/$name.log 2>&1; }
export -f run
printf '%s\n' "rA_32_16 32,16 tanh 0" "rA_32_16_8 32,16,8 tanh 0" "rA_16_8 16,8 tanh 0" "rA_16_8_relu 16,8 relu 0" "rA_8_4 8,4 tanh 0" | xargs -P2 -L1 bash -c 'run $0 $1 $2 $3'
echo DONE > results/rep_arch_done.txt
