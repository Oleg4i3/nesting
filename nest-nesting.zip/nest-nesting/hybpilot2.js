// «Мережа після»: LNS без мережі (0.7 бюджету), далі мережа як оператор відновлення з низькою температурою (0.3 бюджету). Контролі: той самий етап з BL.
// node hybpilot2.js <ч> <частин> <тег> <net.json> <ms> <набори> <копій> <кути> <рулони>
const fs = require('fs'), X = require('./nnx.js'), T = require('./rl_tasks.js'), L = require('./lns2.js');
const part = +process.argv[2], parts = +process.argv[3], tag = process.argv[4], netFile = process.argv[5], net = X.MLPX.fromJSON(JSON.parse(fs.readFileSync(netFile, 'utf8'))), ms = +process.argv[6];
const sets = process.argv[7].split(','), copies = process.argv[8].split(',').map(Number), rots = process.argv[9].split(','), kinds = process.argv[10].split(',');
const out = `results/${tag}_part${part}.jsonl`, done = new Set(fs.existsSync(out) ? fs.readFileSync(out, 'utf8').trim().split('\n').filter(Boolean).map(l => JSON.parse(l).name) : []), fd = fs.openSync(out, 'a'), jobs = [];
for (const rot of rots) for (const set of sets) for (const kind of kinds) for (const cp of copies) jobs.push({ set, kind, seed: 91, n: set === 'suit' ? 13 : 99, rot, copies: cp });
jobs.forEach((j, ji) => {
  if (ji % parts !== part) return;
  const t = T.build(j); if (done.has(t.name + '|' + j.rot)) return;
  const o = { width: t.W, maxLength: 4000, seed: 7, blocked: t.blocked }, ev = pl => { const r = T.evaluate(t, pl); return r ? 100 * r.dens : null; };
  const row = { name: t.name + '|' + j.rot, set: j.set, kind: j.kind, copies: j.copies, rot: j.rot, res: {} };
  const base = { recreate: 'BL', kMin: 6, kMax: 14, T0: 0.6 };
  row.res.lns = ev(L.solveLNS(t.pcs, t.rules, Object.assign({}, o, base, { budgetMs: ms })).placements);
  const first = L.solveLNS(t.pcs, t.rules, Object.assign({}, o, base, { budgetMs: Math.round((+process.env.SPLIT || 0.7) * ms) }));
  const init = first.layout, rest = ms - Math.round((+process.env.SPLIT || 0.7) * ms), pol = { init, budgetMs: rest, kMin: 3, kMax: 8, T0: 0.05, T1: 0.01 };
  row.res.lns70 = ev(first.placements);
  row.res.afterBL = ev(L.solveLNS(t.pcs, t.rules, Object.assign({}, o, pol, { recreate: 'BL' })).placements);
  row.res.afterG = ev(L.solveLNS(t.pcs, t.rules, Object.assign({}, o, pol, { recreate: 'GUIDED', net, temp: 0.3 })).placements);
  row.res.afterM = ev(L.solveLNS(t.pcs, t.rules, Object.assign({}, o, pol, { recreate: 'MIX', mixP: 0.5, net, temp: 0.3 })).placements);
  fs.writeSync(fd, JSON.stringify(row) + '\n'); console.log(row.name, Object.entries(row.res).map(([k, v]) => k + ' ' + (v ? v.toFixed(1) : '—')).join(' | '));
});
