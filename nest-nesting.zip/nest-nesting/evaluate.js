// Фінальна оцінка на НЕБАЧЕНИХ пазлах і на костюмі кравця.  node evaluate.js
const fs = require('fs');
const N = require('./raster.js');
const F = require('./features.js');
const NN = require('./nn.js');
const P = require('./puzzle.js');
const { randomSpec, makePuzzle } = require('./common.js');

const load = f => fs.existsSync(f) ? NN.MLP.fromJSON(JSON.parse(fs.readFileSync(f, 'utf8'))) : null;
const nets = { 'мережа (імітація)': load('weights/net_imitation.json'), 'мережа (імітація+ES)': load('weights/net_es.json') };
const f1 = x => (x * 100).toFixed(1).padStart(5) + '%';
const mean = a => a.reduce((s, x) => s + x, 0) / a.length;

// ---- 1. тестові пазли (seed 90001.., не використовувались ні в навчанні, ні у валідації) ----
const seeds = Array.from({ length: 80 }, (_, i) => 90001 + i);
const rows = [];
for (const s of seeds) {
  const spec = randomSpec(s), pz = makePuzzle(spec);
  const row = { spec, planted: pz.meta.plantedEfficiency };
  row.greedy = P.solveGreedy(pz.pieces, pz.rules, { width: pz.width, maxLength: 3000 }).efficiency;
  const rng = NN.mulberry32(s); let best = 0;
  for (let k = 0; k < 20; k++) best = Math.max(best, P.solveGreedy(pz.pieces, pz.rules, { width: pz.width, maxLength: 3000, order: 'random', rng }).efficiency);
  row.greedy20 = best;
  for (const [name, net] of Object.entries(nets)) if (net) {
    const r = F.solveNN(pz.pieces, pz.rules, net, { width: pz.width, maxLength: 3000 });
    const ev = N.evaluateLayout(P.placementsToPolys(pz.pieces, r.placements), { width: pz.width, height: 3000 });
    if (!ev.valid || r.placed !== pz.pieces.length) throw new Error('недійсна розкладка, seed ' + s);
    row[name] = r.efficiency;
  }
  rows.push(row);
}
const cols = ['planted', 'greedy', 'greedy20', ...Object.keys(nets).filter(k => nets[k])];
const label = { planted: 'еталон', greedy: 'жадібна (1 прохід)', greedy20: 'жадібна, best-of-20' };
const group = (title, pred) => {
  const rs = rows.filter(r => pred(r.spec)); if (!rs.length) return;
  console.log(`${title.padEnd(26)} n=${String(rs.length).padStart(2)} | ` + cols.map(c => f1(mean(rs.map(r => r[c])))).join(' | '));
};
console.log('Тестові пазли (80, невідомі seed).  Колонки: ' + cols.map(c => label[c] || c).join(' | '));
group('усі', () => true);
group('повороти+дзеркала', s => s.rules.rotations === 'any' && s.rules.mirror);
group('повороти без дзеркал', s => s.rules.rotations === 'any' && !s.rules.mirror);
group('лише 0°/180°', s => s.rules.rotations === 'half');
group('заборона поворотів', s => s.rules.rotations === 'none');
group('≤10 деталей', s => s.pieces <= 10);
group('>14 деталей', s => s.pieces > 14);
for (const k of cols.slice(3)) {
  const wins = rows.filter(r => r[k] > r.greedy + 1e-9).length, wins20 = rows.filter(r => r[k] > r.greedy20 + 1e-9).length;
  console.log(`${k}: краще за жадібну 1 прохід у ${wins}/${rows.length}, краще за best-of-20 у ${wins20}/${rows.length}`);
}

// ---- 2. костюм кравця (13 деталей, рулон 290) ----
console.log('\nКостюм кравця (suit-manual.json), рулон 290 px:');
const suit = N.loadLayout(fs.readFileSync('/mnt/user-data/uploads/suit-manual.json', 'utf8'));
const pieces = suit.map(p => { const b = N.vertexBBox(p); return N.translatePoly(p, -b.minX, -b.minY); });
const ev0 = N.evaluateLayout(suit, { width: 500, height: 500, rollWidth: 290 });
console.log(`  кравець: ефективність ${f1(ev0.efficiency)}, довжина ${ev0.extent.length} px`);
const rulesSet = { 'повороти+дзеркала': { rotations: 'any', mirror: true }, 'повороти': { rotations: 'any', mirror: false }, 'лише 180°': { rotations: 'half', mirror: false }, 'без поворотів': { rotations: 'none', mirror: false } };
for (const [rn, rules] of Object.entries(rulesSet)) {
  const g = P.solveGreedy(pieces, rules, { width: 290, maxLength: 3000 });
  let line = `  ${rn.padEnd(18)} жадібна ${f1(g.efficiency)} (${g.lengthPx} px)`;
  for (const [name, net] of Object.entries(nets)) if (net) { const r = F.solveNN(pieces, rules, net, { width: 290, maxLength: 3000 }); line += ` | ${name} ${f1(r.efficiency)} (${r.lengthPx} px)`; }
  console.log(line);
}
