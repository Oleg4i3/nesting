# Останній крок: лишаємо в рисунках 4–5 найпоказовіших рядків. Запускати після build_data3.py і build_data4.py.
import json
R='/home/claude/nest/'
d=json.load(open(R+'figures/data2.json'))
KEEP={
 'fig2_internal_box.svg':['Щільні пазли','Обрізка й відходи','Великі пазли: виїмки','Великі пазли: діра й обрізок','Великі пазли, усі'],
 'fig7_scenarios.svg':['Прямокутний рулон','З дефектами й обрізаними кутами','З нерівними краями','Усі сценарії'],
 'fig9_paired.svg':['Прямокутний рулон','З дефектами й обрізаними кутами','З нерівними краями','Усі сценарії'],
 'fig8_angles.svg':['Пазли 5°, 8–14 деталей, щільні','Реальні деталі 5°, прямокутний рулон','Реальні деталі 5°, дефекти й краї','Один набір викрійок костюма, повороти 0° і 180°','Один набір викрійок костюма, повороти 0°, 90°, 180°, 270°'],
 'fig10_width.svg':['Набір викрійок костюма, ширина ×0,8','Набір викрійок костюма, ширина ×1 ','Набір викрійок костюма, ширина ×2','Набори ESICUP, ширина ×1 ','Набори ESICUP, ширина ×2'],
}
for b in d['boxes']:
    k=KEEP.get(b['file'])
    if not k: continue
    idx=[i for i,r in enumerate(b['rows']) if any(r.startswith(p) for p in k)]
    b['rows']=[b['rows'][i] for i in idx]; b['vals']=[b['vals'][i] for i in idx]
    print(b['file'],len(b['rows']),b['rows'])
json.dump(d,open(R+'figures/data2.json','w'),ensure_ascii=False,indent=1)
