// Рисунки 7 і 8 (донавчання; кут 5°): точкові діаграми, на графіку лише осі й легенда. node figures/make_svgs2.js
const fs=require('fs'),path=require('path');
const C={text:'#1c1c1b',sec:'#5d5c58',grid:'#e4e3de',axis:'#aeada5'};
const esc=s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;'),fmt=v=>String(v).replace('.',',');
function dot({file,title,xmin,xmax,xticks,xlabel,rows,series,vals,lane,n}){
 const L=290,R=560,T=16,rh=46,B=T+rows.length*rh,x=v=>L+(v-xmin)/(xmax-xmin)*(R-L),cy=i=>T+i*rh+rh/2,W=900,H=B+64;
 let o=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W*1.4}" height="${H*1.4}" font-family="Helvetica, Arial, sans-serif" font-size="12"><rect width="${W}" height="${H}" fill="#fff"/>`;
 for(const v of xticks)o+=`<line x1="${x(v)}" y1="${T}" x2="${x(v)}" y2="${B}" stroke="${C.grid}"/><text x="${x(v)}" y="${B+16}" text-anchor="middle" fill="${C.sec}">${v}</text>`;
 rows.forEach((r,i)=>{o+=`<line x1="20" y1="${T+i*rh}" x2="${R}" y2="${T+i*rh}" stroke="${C.grid}" stroke-opacity="0.6"/><text x="20" y="${cy(i)+4}" fill="${C.text}">${esc(r)}</text>`});
 if(vline)o+=`<line x1="${x(vline.x)}" y1="${T}" x2="${x(vline.x)}" y2="${B}" stroke="#86857f" stroke-width="1.5" stroke-dasharray="5 3"/>`;
 o+=`<line x1="${L}" y1="${B}" x2="${R}" y2="${B}" stroke="${C.axis}"/><text x="${(L+R)/2}" y="${B+40}" text-anchor="middle" fill="${C.sec}">${esc(xlabel)}</text>`;
 rows.forEach((r,i)=>series.forEach((s,k)=>{const v=vals[i][s.k];if(v==null)return;o+=`<circle cx="${x(v).toFixed(1)}" cy="${(cy(i)+lane[k]).toFixed(1)}" r="4" fill="${s.hollow?'#fff':s.c}" stroke="${s.c}" stroke-width="1.8"><title>${esc(r)}: ${esc(s.name)}, ${fmt(v.toFixed(1))} %</title></circle>`}));
 o+=`<text x="600" y="30" fill="${C.text}">Розв’язувач (колір)</text>`;
 series.forEach((s,k)=>{o+=`<circle cx="610" cy="${50+k*20}" r="5" fill="${s.hollow?'#fff':s.c}" stroke="${s.c}" stroke-width="1.8"/><text x="624" y="${54+k*20}" fill="${C.text}">${esc(s.name)}</text>`});
 fs.writeFileSync(path.join(__dirname,file),o+'</svg>');console.log(file,o.length)}
const D=JSON.parse(fs.readFileSync(path.join(__dirname,'data4.json'),'utf8'));

// --- коробкові діаграми (box and whiskers): коробка = міжквартильний розмах, риска = медіана, вуса = мін–макс ---
function q(a,p){const s=[...a].sort((x,y)=>x-y),i=(s.length-1)*p,l=Math.floor(i),h=Math.ceil(i);return s[l]+(s[h]-s[l])*(i-l)}
let HAS_OUT=0;
function box({file,xmin,xmax,xticks,xlabel,rows,series,vals,vline}){
 const L=250,R=560,T=16,K=series.length,lh=10,rh=K*lh+14,B=T+rows.length*rh,x=v=>L+(v-xmin)/(xmax-xmin)*(R-L),W=900,H=B+64;
HAS_OUT=0;
 let o=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W*1.4}" height="${H*1.4}" font-family="Helvetica, Arial, sans-serif" font-size="12"><rect width="${W}" height="${H}" fill="#fff"/>`;
 for(const v of xticks)o+=`<line x1="${x(v)}" y1="${T}" x2="${x(v)}" y2="${B}" stroke="${C.grid}"/><text x="${x(v)}" y="${B+16}" text-anchor="middle" fill="${C.sec}">${v}</text>`;
 if(vline)o+=`<line x1="${x(vline.x)}" y1="${T}" x2="${x(vline.x)}" y2="${B}" stroke="#86857f" stroke-width="1.5" stroke-dasharray="5 3"/>`;
 rows.forEach((r,i)=>{const y0=T+i*rh;o+=`<line x1="20" y1="${y0}" x2="${R}" y2="${y0}" stroke="${C.grid}" stroke-opacity="0.8"/><text x="20" y="${y0+rh/2+4}" fill="${C.text}">${esc(r)}</text>`;
  series.forEach((s,k)=>{const a=vals[i][s.k];if(!a||!a.length)return;const cy=y0+7+k*lh+lh/2,mn0=Math.min(...a),mx0=Math.max(...a),q1=q(a,.25),q2=q(a,.5),q3=q(a,.75),iq=q3-q1,ins=a.length>=5?a.filter(v=>v>=q1-1.5*iq&&v<=q3+1.5*iq):a,mn=Math.min(...ins),mx=Math.max(...ins),outl=a.filter(v=>!ins.includes(v));if(outl.length)HAS_OUT=1;
   if(mx0-mn0<1.0){o+=`<g><title>${esc(r)}: ${esc(s.name)}; ${fmt(mx.toFixed(1))} %; n=${a.length}</title><path d="M${x(q2)-4.5},${cy} L${x(q2)},${cy-4.5} L${x(q2)+4.5},${cy} L${x(q2)},${cy+4.5} Z" fill="${s.c}" stroke="#fff" stroke-width="0.8"/></g>`;return}
   o+=`<g><title>${esc(r)}: ${esc(s.name)}; мін ${fmt(mn.toFixed(1))}, Q1 ${fmt(q1.toFixed(1))}, медіана ${fmt(q2.toFixed(1))}, Q3 ${fmt(q3.toFixed(1))}, макс ${fmt(mx.toFixed(1))} %; n=${a.length}</title><line x1="${x(mn)}" y1="${cy}" x2="${x(mx)}" y2="${cy}" stroke="${s.c}" stroke-width="1.4"/><line x1="${x(mn)}" y1="${cy-3}" x2="${x(mn)}" y2="${cy+3}" stroke="${s.c}" stroke-width="1.4"/><line x1="${x(mx)}" y1="${cy-3}" x2="${x(mx)}" y2="${cy+3}" stroke="${s.c}" stroke-width="1.4"/><rect x="${x(q1)}" y="${cy-4}" width="${Math.max(1,x(q3)-x(q1))}" height="8" fill="${s.c}" fill-opacity="0.85" stroke="${s.c}"/><line x1="${x(q2)}" y1="${cy-4}" x2="${x(q2)}" y2="${cy+4}" stroke="#fff" stroke-width="2"/>${outl.map(v=>`<circle cx="${x(v)}" cy="${cy}" r="2.6" fill="#fff" stroke="${s.c}" stroke-width="1.3"/>`).join('')}</g>`})});
 o+=`<line x1="${L}" y1="${B}" x2="${R}" y2="${B}" stroke="${C.axis}"/><text x="${(L+R)/2}" y="${B+40}" text-anchor="middle" fill="${C.sec}">${esc(xlabel)}</text>`;
 o+=`<text x="600" y="30" fill="${C.text}">Розв’язувач (колір)</text>`;
 series.forEach((s,k)=>{o+=`<rect x="604" y="${44+k*20}" width="12" height="10" fill="${s.c}" fill-opacity="0.85" stroke="${s.c}"/><text x="624" y="${54+k*20}" fill="${C.text}">${esc(s.name)}</text>`});
 let kk=series.length;if(vline){const k=series.length;kk++;o+=`<line x1="602" y1="${49+k*20}" x2="618" y2="${49+k*20}" stroke="#86857f" stroke-width="1.5" stroke-dasharray="5 3"/><text x="624" y="${54+k*20}" fill="${C.text}">${esc(vline.name)}</text>`}
 if(HAS_OUT){o+=`<circle cx="610" cy="${49+kk*20}" r="2.6" fill="#fff" stroke="${C.sec}" stroke-width="1.3"/><text x="624" y="${54+kk*20}" fill="${C.text}">Викид (поза 1,5 розмаху ящика)</text>`}
 fs.writeFileSync(path.join(__dirname,file),o+'</svg>');console.log(file,o.length)}
for(const f of (D.boxes||[]))box(f);
// --- основний графік із боксплотами: горизонталь — %, вертикаль — час (логарифм), форма маркера — задача, колір — розв'язувач.
// Для методів із кількома прогонами: коробка Q1–Q3, вуса мін–макс, маркер задачі в медіані; для одного прогону — лише маркер.
const SH={c:'M-5.5,0a5.5,5.5 0 1,0 11,0a5.5,5.5 0 1,0 -11,0',s:'M-5,-5h10v10h-10z',u:'M0,-6.5L6.5,5L-6.5,5Z',d:'M0,6.5L6.5,-5L-6.5,-5Z',m:'M0,-7L7,0L0,7L-7,0Z',p:'M-2,-6.5h4v4.5h4.5v4h-4.5v4.5h-4v-4.5h-4.5v-4h4.5z'};
function scatterBox({file,xmin,xmax,xticks,yticks,tmin,tmax,tasks,solvers,rows,lane,xlabel,opt,taskHead,H}){
 const L=70,R=540,T=24,B=H-60,x=v=>L+(v-xmin)/(xmax-xmin)*(R-L),y=t=>B-(Math.log(t)-Math.log(tmin))/(Math.log(tmax)-Math.log(tmin))*(B-T),W=830;
 const col=Object.fromEntries(solvers.map(s=>[s.s,s.c]));
 let o=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W*1.5}" height="${H*1.5}" font-family="Helvetica, Arial, sans-serif" font-size="12"><rect width="${W}" height="${H}" fill="#fff"/>`;
 for(const v of xticks)o+=`<line x1="${x(v)}" y1="${T}" x2="${x(v)}" y2="${B}" stroke="${C.grid}"/><text x="${x(v)}" y="${B+16}" text-anchor="middle" fill="${C.sec}">${v}</text>`;
 for(const v of yticks)o+=`<line x1="${L}" y1="${y(v)}" x2="${R}" y2="${y(v)}" stroke="${C.grid}"/><text x="${L-8}" y="${y(v)+4}" text-anchor="end" fill="${C.sec}">${fmt(v)}</text>`;
 o+=`<line x1="${L}" y1="${B}" x2="${R}" y2="${B}" stroke="${C.axis}"/><line x1="${L}" y1="${T}" x2="${L}" y2="${B}" stroke="${C.axis}"/>`;
 o+=`<text x="${(L+R)/2}" y="${B+38}" text-anchor="middle" fill="${C.sec}">${esc(xlabel)}</text><text x="18" y="${(T+B)/2}" text-anchor="middle" transform="rotate(-90 18 ${(T+B)/2})" fill="${C.sec}">Час роботи, с (логарифмічна шкала)</text>`;
 if(opt)o+=`<line x1="${x(100)}" y1="${T}" x2="${x(100)}" y2="${B}" stroke="#86857f" stroke-width="1.5" stroke-dasharray="4 3"/>`;
 o+=`<line x1="${L}" y1="${y(30)}" x2="${R}" y2="${y(30)}" stroke="#86857f" stroke-width="1.5" stroke-dasharray="4 3"/>`;
 const nT=tasks.length;
 for(const r of rows){const ti=tasks.findIndex(q=>q.k===r.k),t=tasks[ti],s=solvers.find(q=>q.s===r.s),a=r.vals,c=s.c;
  const cy=y(r.t)+(lane[r.s]||0)+(ti-(nT-1)/2)*3.2,mn=Math.min(...a),mx=Math.max(...a),q1=q(a,.25),q2=q(a,.5),q3=q(a,.75),multi=a.length>1&&mx-mn>=1.0;
  o+=`<g><title>${esc(t.name)}: ${esc(s.name)}; медіана ${fmt(q2.toFixed(1))} %${multi?`, Q1 ${fmt(q1.toFixed(1))}, Q3 ${fmt(q3.toFixed(1))}, мін ${fmt(mn.toFixed(1))}, макс ${fmt(mx.toFixed(1))} (${a.length} прогонів)`:' (один прогін)'}, ${fmt(r.t)} с</title>`;
  if(multi)o+=`<line x1="${x(mn).toFixed(1)}" y1="${cy.toFixed(1)}" x2="${x(mx).toFixed(1)}" y2="${cy.toFixed(1)}" stroke="${c}" stroke-width="1.1" stroke-opacity="0.9"/><rect x="${x(q1).toFixed(1)}" y="${(cy-1.8).toFixed(1)}" width="${Math.max(0.8,x(q3)-x(q1)).toFixed(1)}" height="3.6" fill="${c}" fill-opacity="0.55" stroke="${c}" stroke-width="0.8"/>`;
  o+=`<g transform="translate(${x(q2).toFixed(1)},${cy.toFixed(1)}) scale(0.62)${t.rot?' rotate(45)':''}"><path d="${SH[t.sh]}" fill="${c}" fill-opacity="${multi?1:0.9}" stroke="#fff" stroke-width="1.6"/></g></g>`}
 o+=`<text x="565" y="30" fill="${C.text}">${esc(taskHead)}</text>`;
 tasks.forEach((q,i)=>{o+=`<path d="${SH[q.sh]}" transform="translate(574,${50+i*16})${q.rot?' rotate(45)':''}" fill="${C.sec}"/><text x="588" y="${54+i*16}" fill="${C.text}">${esc(q.name)}</text>`});
 const y0=50+nT*16+14;o+=`<text x="565" y="${y0}" fill="${C.text}">Розв’язувач (колір)</text>`;
 solvers.forEach((q,i)=>{o+=`<rect x="568" y="${y0+10+i*16}" width="12" height="10" fill="${q.c}" fill-opacity="0.8"/><text x="588" y="${y0+19+i*16}" fill="${C.text}">${esc(q.name)}</text>`});
 let ly=y0+10+solvers.length*16+10;
 if(opt){o+=`<line x1="566" y1="${ly}" x2="582" y2="${ly}" stroke="#86857f" stroke-width="1.5" stroke-dasharray="4 3"/><text x="588" y="${ly+4}" fill="${C.text}">Закладений оптимум</text>`;ly+=17}
 o+=`<line x1="566" y1="${ly}" x2="582" y2="${ly}" stroke="#86857f" stroke-width="1.5" stroke-dasharray="4 3"/><text x="588" y="${ly+4}" fill="${C.text}">Бюджет 30 с</text>`;
 o+=`<rect x="568" y="${ly+16}" width="14" height="4" fill="#5d5c58" fill-opacity="0.55" stroke="#5d5c58" stroke-width="0.8"/><text x="588" y="${ly+22}" fill="${C.text}">Ящик Q1–Q3, вуса мін–макс</text>`;
 fs.writeFileSync(path.join(__dirname,file),o+'</svg>');console.log(file,o.length)}

