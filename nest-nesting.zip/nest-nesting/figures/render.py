import re,sys
from playwright.sync_api import sync_playwright
names=sys.argv[1:]
with sync_playwright() as p:
    b=p.chromium.launch(args=['--disable-gpu']);pg=b.new_page(viewport={'width':1400,'height':2400},device_scale_factor=2)
    for f in names:
        svg=open(f+'.svg',encoding='utf8').read()
        m=re.search(r'viewBox="0 0 ([\d.]+) ([\d.]+)"',svg); w,h=float(m.group(1)),float(m.group(2))
        pg.set_content('<html><body style="margin:0;background:#fff">'+svg+'</body></html>')
        mw=re.search(r'<svg[^>]* width="([\d.]+)" height="([\d.]+)"',svg);pg.screenshot(path=f+'_doc.png',clip={'x':0,'y':0,'width':float(mw.group(1)),'height':float(mw.group(2))})
    b.close()
