// Самостійні SVG-версії рисунків статті (ті самі дані й геометрія, що й у графіках документа): на графіку лише осі й легенда.
// node figures/make_svgs.js  ->  figures/fig1_puzzles.svg, fig2_internal.svg, fig5_real.svg
const fs=require('fs'),path=require('path');
const C={text:'#1c1c1b',sec:'#5d5c58',grid:'#e4e3de',axis:'#aeada5',ref:'#86857f',net:'#2a6fd6',hyb:'#e8683a',bl:'#1fa97a',lns:'#12336d',sp:'#d4527f',svg:'#4b3bb0',lnsn:'#d4527f'};
const esc=s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;');
const fmt=v=>String(v).replace('.',',');
const SH={c:'M-5.5,0a5.5,5.5 0 1,0 11,0a5.5,5.5 0 1,0 -11,0',s:'M-5,-5h10v10h-10z',u:'M0,-6.5L6.5,5L-6.5,5Z',d:'M0,6.5L6.5,-5L-6.5,-5Z',m:'M0,-7L7,0L0,7L-7,0Z',p:'M-2,-6.5h4v4.5h4.5v4h-4.5v4.5h-4v-4.5h-4.5v-4h4.5z'};
const head=(w,h)=>`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}" width="${w*1.5}" height="${h*1.5}" font-family="Helvetica, Arial, sans-serif" font-size="12"><rect width="${w}" height="${h}" fill="#ffffff"/>`;
// --- спільна функція «точки: ефективність × час» ---
function scatter({file,xmin,xmax,xticks,yticks,tmin,tmax,tasks,solvers,rows,dodge,rotLast,xlabel,refs}){
 const L=70,R=540,T=24,B=440,x=v=>L+(v-xmin)/(xmax-xmin)*(R-L),y=t=>B-(Math.log(t)-Math.log(tmin))/(Math.log(tmax)-Math.log(tmin))*(B-T);
 let o=head(760,500);
 for(const v of xticks)o+=`<line x1="${x(v)}" y1="${T}" x2="${x(v)}" y2="${B}" stroke="${C.grid}"/><text x="${x(v)}" y="${B+16}" text-anchor="middle" fill="${C.sec}">${v}</text>`;
 for(const v of yticks)o+=`<line x1="${L}" y1="${y(v)}" x2="${R}" y2="${y(v)}" stroke="${C.grid}"/><text x="${L-8}" y="${y(v)+4}" text-anchor="end" fill="${C.sec}">${fmt(v)}</text>`;
 o+=`<line x1="${L}" y1="${B}" x2="${R}" y2="${B}" stroke="${C.axis}"/><line x1="${L}" y1="${T}" x2="${L}" y2="${B}" stroke="${C.axis}"/>`;
 o+=`<text x="${(L+R)/2}" y="${B+38}" text-anchor="middle" fill="${C.sec}">${esc(xlabel)}</text><text x="18" y="${(T+B)/2}" text-anchor="middle" transform="rotate(-90 18 ${(T+B)/2})" fill="${C.sec}">Час роботи, с (логарифмічна шкала)</text>`;
 if(refs.opt)o+=`<line x1="${x(100)}" y1="${T}" x2="${x(100)}" y2="${B}" stroke="${C.ref}" stroke-width="1.5" stroke-dasharray="4 3"/>`;
 o+=`<line x1="${L}" y1="${y(30)}" x2="${R}" y2="${y(30)}" stroke="${C.ref}" stroke-width="1.5" stroke-dasharray="4 3"/>`;
 for(const r of rows){const t=tasks.find(q=>q.k===r.k),s=solvers.find(q=>q.s===r.s);
  o+=`<g transform="translate(${x(r.d).toFixed(1)},${(y(r.t)+(dodge[r.s]||0)).toFixed(1)})${t.rot?' rotate(45)':''}"><title>${esc(t.name)}: ${esc(s.name)}, ${fmt(r.d)} %, ${fmt(r.t)} с</title><path d="${SH[t.sh]}" fill="${C[r.s]}" fill-opacity="0.92" stroke="${C.text}" stroke-opacity="0.35" stroke-width="0.6"/></g>`}
 o+=`<text x="565" y="30" fill="${C.text}">${esc(refs.taskHead)}</text>`;
 tasks.forEach((q,i)=>{o+=`<path d="${SH[q.sh]}" transform="translate(574,${50+i*19})${q.rot?' rotate(45)':''}" fill="${C.sec}"/><text x="588" y="${54+i*19}" fill="${C.text}">${esc(q.name)}</text>`});
 o+=`<text x="565" y="204" fill="${C.text}">Розв’язувач (колір)</text>`;
 solvers.forEach((q,i)=>{o+=`<circle cx="574" cy="${224+i*19}" r="5.5" fill="${C[q.s]}"/><text x="588" y="${228+i*19}" fill="${C.text}">${esc(q.name)}</text>`});
 let ly=224+solvers.length*19+14;
 if(refs.opt){o+=`<line x1="566" y1="${ly}" x2="582" y2="${ly}" stroke="${C.ref}" stroke-width="1.5" stroke-dasharray="4 3"/><text x="588" y="${ly+4}" fill="${C.text}">Закладений оптимум</text>`;ly+=19}
 o+=`<line x1="566" y1="${ly}" x2="582" y2="${ly}" stroke="${C.ref}" stroke-width="1.5" stroke-dasharray="4 3"/><text x="588" y="${ly+4}" fill="${C.text}">Бюджет 30 с</text></svg>`;
 fs.writeFileSync(path.join(__dirname,file),o);console.log(file,o.length)}
const D=JSON.parse(fs.readFileSync(path.join(__dirname,'data.json'),'utf8'));
scatter({file:'fig1_puzzles.svg',xmin:50,xmax:100,xticks:[50,60,70,80,90,100],yticks:[0.5,1,2,5,10,30],tmin:0.3,tmax:60,tasks:D.puzzles.tasks,solvers:D.puzzles.solvers,rows:D.puzzles.rows,dodge:{bl:-21,lns:-7,sp:7,hyb:21},xlabel:'Ефективність розкладки, %',refs:{opt:true,taskHead:'Задача (форма)'}});
scatter({file:'fig5_real.svg',xmin:60,xmax:95,xticks:[60,65,70,75,80,85,90,95],yticks:[2,5,10,30],tmin:2,tmax:60,tasks:D.real.tasks,solvers:D.real.solvers,rows:D.real.rows,dodge:{bl:-21,lns:-7,hyb:7,sp:21},xlabel:'Щільність розкрою, % (сума площ деталей / площа смуги)',refs:{opt:false,taskHead:'Набір (форма)'}});
// --- рисунок 2: точкова діаграма за типами задач ---
{const d=D.internal,L=250,R=520,T=20,rh=40,B=T+d.tasks.length*rh,x=v=>L+(v-60)/40*(R-L),lane={net:-16,bl:-8,lns:0,lnsn:8,hyb:16},cy=k=>T+d.tasks.findIndex(q=>q.k===k)*rh+rh/2;
 let o=head(760,B+60);
 for(const v of [60,70,80,90,100])o+=`<line x1="${x(v)}" y1="${T}" x2="${x(v)}" y2="${B}" stroke="${C.grid}"/><text x="${x(v)}" y="${B+16}" text-anchor="middle" fill="${C.sec}">${v}</text>`;
 d.tasks.forEach((q,i)=>{o+=`<line x1="20" y1="${T+i*rh}" x2="${R}" y2="${T+i*rh}" stroke="${C.grid}" stroke-opacity="0.6"/><text x="20" y="${cy(q.k)+4}" fill="${C.text}">${esc(q.name)}</text>`});
 o+=`<line x1="${L}" y1="${B}" x2="${R}" y2="${B}" stroke="${C.axis}"/><text x="${(L+R)/2}" y="${B+40}" text-anchor="middle" fill="${C.sec}">Ефективність розкладки, %</text>`;
 for(const r of d.refs)o+=`<line x1="${x(r.d)}" y1="${cy(r.k)-18}" x2="${x(r.d)}" y2="${cy(r.k)+18}" stroke="${C.ref}" stroke-width="2"><title>Закладений еталон ${fmt(r.d)} %</title></line>`;
 for(const r of d.rows){const s=d.solvers.find(q=>q.s===r.s);o+=`<circle cx="${x(r.d).toFixed(1)}" cy="${cy(r.k)+lane[r.s]}" r="3.8" fill="${r.o===1?'#ffffff':C[r.s]}" stroke="${C[r.s]}" stroke-width="1.8"><title>${esc(d.tasks.find(q=>q.k===r.k).name)}: ${esc(s.name)}, ${fmt(r.d)} %</title></circle>`}
 o+=`<text x="550" y="34" fill="${C.text}">Розв’язувач (колір)</text>`;
 d.solvers.forEach((q,i)=>{o+=`<circle cx="560" cy="${54+i*20}" r="5" fill="${C[q.s]}"/><text x="574" y="${58+i*20}" fill="${C.text}">${esc(q.name)}</text>`});
 o+=`<circle cx="560" cy="170" r="5" fill="#ffffff" stroke="${C.net}" stroke-width="1.8"/><text x="574" y="174" fill="${C.text}">Мережа (ранжування lp)</text><line x1="560" y1="188" x2="560" y2="202" stroke="${C.ref}" stroke-width="2"/><text x="574" y="198" fill="${C.text}">Закладений еталон</text></svg>`;
 fs.writeFileSync(path.join(__dirname,'fig2_internal.svg'),o);console.log('fig2',o.length)}
