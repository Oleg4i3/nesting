# Рисунок про ширину рулона: ящики за зернами (костюм) і за наборами (ESICUP). Запускати після build_data3.py
import json,glob,collections,re
R='/home/claude/nest/'
d=json.load(open(R+'figures/data2.json'))
sc=collections.defaultdict(lambda: collections.defaultdict(list)); W={}
for f in glob.glob(R+'results/width/*_f*_s*.json'):
    j=json.load(open(f)); k=(j['set'],j['f']); W[k]=j['W']
    for m in ('net','bl','lns','hyb'):
        if j.get(m) and j[m].get('dens'): sc[k][m].append(100*j[m]['dens'])
facs=[0.8,1,1.25,1.5,2]
def fs(f): return ('×'+str(f)).replace('.',',')
rows=[];vals=[]
for f in facs:
    k=('suit',f)
    if k in sc: rows.append(f'Набір викрійок костюма, ширина {fs(f)} ({len(sc[k]["bl"])})'); vals.append({m:sc[k][m] for m in ('net','bl','lns','hyb')})
sets=sorted({k[0] for k in sc if k[0]!='suit'})
for f in facs:
    agg=collections.defaultdict(list); n=0
    for s in sets:
        k=(s,f)
        if k in sc:
            n+=1
            for m in ('net','bl','lns','hyb'): agg[m]+= [sum(sc[k][m])/len(sc[k][m])] if sc[k][m] else []
    if n: rows.append(f'Набори ESICUP, ширина {fs(f)} ({n})'); vals.append(dict(agg))
ser=[{'k':'net','name':'Мережа','c':'#2a6fd6'},{'k':'hyb','name':'Гібрид «мережа → LNS»','c':'#e8683a'},{'k':'bl','name':'BL-відпал','c':'#1fa97a'},{'k':'lns','name':'LNS + BL','c':'#12336d'}]
ref=[b for b in d['boxes'] if b['file']=='fig2_internal_box.svg'][0]
d['boxes']=[b for b in d['boxes'] if b['file']!='fig10_width.svg']
b={k:v for k,v in ref.items()}
b.pop('vline',None); b.update({'file':'fig10_width.svg','rows':rows,'vals':vals,'series':ser,'xmin':35,'xmax':95,'xticks':[40,50,60,70,80,90],'xlabel':'Щільність розкрою, %'})
d['boxes'].append(b)
json.dump(d,open(R+'figures/data2.json','w'),ensure_ascii=False,indent=1)
print(rows)
