# Рис. A: пазли із зонами різної форми (% від еталона) і Рис. B: реальні лекала із зонами (щільність, %). Додає боксплоти до data2.json.
import json,glob,statistics as st
R='/home/claude/nest/'
d=json.load(open(R+'figures/data2.json'))
sp=json.load(open(R+'ext/zscen/dens.json'))
SER=[('sp','Sparrow (з патчем про дефекти)','#d4527f'),('bl','BL-відпал','#1fa97a'),('lns','LNS + BL','#12336d'),('net:r3a','Мережа (базова)','#2a6fd6'),('net:zA_16_8','Мережа (перенавчена на зонах)','#8fb4ea'),('hyb:r3a','Гібрид «мережа → LNS»','#e8683a')]
def put(file,rows,vals,xmin,xmax,xticks,xlabel):
    d['boxes']=[b for b in d['boxes'] if b['file']!=file]
    d['boxes'].append({'file':file,'xmin':xmin,'xmax':xmax,'xticks':xticks,'xlabel':xlabel,'rows':rows,'series':[{'k':k,'name':n,'c':c} for k,n,c in SER],'vals':vals})
# --- A
P=[json.loads(l) for f in glob.glob(R+'results/zpuz_part*.jsonl') for l in open(f)]
kinds=[('moon','Півмісяці'),('sshape','S-подібні смуги'),('mix','Суміш зон і край'),('ragged','Нерівні краї')]
rows=[];vals=[]
for k,n in kinds:
    rs=[r for r in P if r['kind']==k]; rows.append(f'{n} ({len(rs)})'); v={}
    for m,_,_ in SER:
        if m=='sp': v[m]=[100*st.median([x for x in sp[f"zt_{r['kind']}_{r['seed']}"] if x])/ (100*r['planted']) *1.0 for r in rs if f"zt_{r['kind']}_{r['seed']}" in sp and any(sp[f"zt_{r['kind']}_{r['seed']}"])]
        else: v[m]=[100*r['res'][m]['dens']/r['planted'] for r in rs if r['res'].get(m,{}).get('dens')]
    vals.append(v)
put('fig11_zpuz.svg',rows,vals,40,105,[40,50,60,70,80,90,100],'Довжина розкрою відносно еталона: щільність у % від щільності закладеного розбиття (100 % = еталон)')
# --- B
Q=[json.loads(l) for f in glob.glob(R+'results/zreal_part*.jsonl') for l in open(f)]
sets=[('fs_jaeger','Піджак (FreeSewing)'),('fs_charlie','Брюки (FreeSewing)'),('fs_simon','Сорочка (FreeSewing)'),('fs_hugo','Худі (FreeSewing)'),('fs_wahid','Жилет (FreeSewing)'),('suit','Костюм кравця'),('marques','ESICUP marques'),('trousers','ESICUP trousers'),('shirts','ESICUP shirts')]
rows=[];vals=[]
for s,n in sets:
    rs=[r for r in Q if r['set']==s]; rows.append(f'{n} ({len(rs)})'); v={}
    for m,_,_ in SER:
        if m=='sp': v[m]=[st.median([x for x in sp[f"zr_{r['set']}_{r['kind']}_{r['seed']}"] if x]) for r in rs]
        else: v[m]=[100*r['res'][m]['dens'] for r in rs if r['res'].get(m,{}).get('dens')]
    vals.append(v)
put('fig12_zreal.svg',rows,vals,30,85,[30,40,50,60,70,80],'Щільність розкрою, % (сума площ деталей / площа смуги; заборонена площа лічиться відходом)')
json.dump(d,open(R+'figures/data2.json','w'),ensure_ascii=False,indent=1); print(rows)
