import json,glob,collections,os
R='/home/claude/nest/'
D=json.load(open(R+'figures/data.json'))
colors={'net':'#2a6fd6','hyb':'#e8683a','bl':'#1fa97a','lns':'#12336d','sp':'#d4527f','svg':'#4b3bb0'}
out=json.load(open(R+'figures/data2.json'))
out['boxscatter']=[];
def seedvals(pattern,key,sub):
    res=[]
    for f in sorted(glob.glob(R+pattern)):
        j=json.load(open(f))
        if sub in j and key in j[sub] and j[sub][key] and j[sub][key].get('dens'): res.append(100*j[sub][key]['dens'])
    return res
import re
def sparrow_runs(kind,id):
    res=[]
    pats=[R+f'ext/sp/{id}_30_s*.log'] if kind=='puzzles' else [R+f'ext/sp_real/{id}_s*.log']
    for p in pats:
        for f in sorted(glob.glob(p)):
            m=re.findall(r'compressed from [0-9.]+% to ([0-9.]+)%',open(f).read())
            if m: res.append(float(m[-1]))
    return res
def svg_runs(id):
    res=[]
    for f in sorted(glob.glob(R+'ext/svgnest_30_run[23].json')):
        d=json.load(open(f)).get(id)
        if d and d.get('dens') and d['dens']<=1.0: res.append(100*d['dens'])   # >100 % — похибка вимірювання, відкидаємо
    return res
def build(kind,idmap,pat,xmin,xmax,xticks,yticks,tmin,tmax,lane,xlabel,opt,fname,H,keep=None):
    sec=D[kind]; rows=[]
    if keep: sec=dict(sec,tasks=[t for t in sec['tasks'] if t['k'] in keep],rows=[r for r in sec['rows'] if r['k'] in keep])
    for r in sec['rows']:
        vals=[r['d']]
        if r['s'] in('bl','lns','hyb'): vals+=seedvals(pat,r['s'],idmap[r['k']])
        if r['s']=='sp': vals+=sparrow_runs(kind,idmap[r['k']])
        if r['s']=='svg': vals+=svg_runs(idmap[r['k']])
        rows.append({'k':r['k'],'s':r['s'],'t':r['t'],'vals':vals})
    out['boxscatter'].append({'file':fname,'xmin':xmin,'xmax':xmax,'xticks':xticks,'yticks':yticks,'tmin':tmin,'tmax':tmax,'tasks':sec['tasks'],
      'solvers':[{'s':s['s'],'name':s['name'],'c':colors[s['s']]} for s in sec['solvers']],'rows':rows,'lane':lane,'xlabel':xlabel,'opt':opt,'taskHead':'Задача (форма маркера)','H':H})
    n=collections.Counter(len(r['vals']) for r in rows if r['s'] in('bl','lns','hyb')); print(fname,dict(n))
build('puzzles',{'p1':'pz_a','p2':'pz_b','b1':'pzbig_a','b2':'pzbig_b','b3':'pzbig_c','t1':'trim_a','t2':'trim_b'},'ext/ours_30000_pf_s*.json',50,100,[50,60,70,80,90,100],[0.5,1,2,5,10,30],0.3,60,
      {'bl':-32,'lns':-11,'hyb':11,'sp':32,'net':0,'svg':0},'Ефективність розкладки, %',True,'fig1_puzzles_box.svg',400,keep=['p1','p2','b1','b3','t2'])
build('real',{k:k for k in ['marques','albano','dagli','mao','swim','trousers','shirts']},'ext/real_ours_30000_s*.json',60,95,[60,65,70,75,80,85,90,95],[2,5,10,30],2,60,
      {'bl':-32,'lns':-11,'hyb':11,'sp':32,'net':0},'Щільність розкрою, %',False,'fig5_real_box.svg',400,keep=['marques','dagli','swim','trousers','shirts'])
# Рис. 2: окремі розв'язки великих пазлів і щільних/обрізаних пазлів із кутами 15°
def load(p): return [json.loads(l) for f in sorted(glob.glob(R+p)) for l in open(f) if l.strip()]
e3=load('results/e3_r3a_part*.jsonl'); er=load('results/er_r2m_part*.jsonl')
rows=[];vals=[]
def pk(rs,m):
    def rel(r,k):
        e=r['res'].get(k,{}).get('eff') if k else None
        return None if e is None else 100*e/r['planted']
    d={'net':[rel(r,m[0]) for r in rs],'bl':[rel(r,m[1]) for r in rs],'lns':[rel(r,m[2]) for r in rs],'hyb':[rel(r,m[3]) for r in rs] if m[3] else []}
    return {k:[v for v in a if v is not None] for k,a in d.items()}
if glob.glob(R+'results/er3_part*.jsonl'): er=load('results/er3_part*.jsonl'); ERM=('мережа beam B=16','BL відпал','LNS + BL','гібрид: мережа→LNS'); print('er3 records',len(er))
else: ERM=('мережа beam B=16','BL відпал','LNS + BL',None)
for st,name in ((1,'Щільні пазли, кути 15°'),(2,'Обрізка й відходи, кути 15°')):
    rs=[r for r in er if r['stage']==st]; rows.append(f'{name} ({len(rs)})'); vals.append(pk(rs,ERM))
for kd,name in (('scoop','Великі пазли: виїмки'),('both','Великі пазли: діра й обрізок')):
    rs=[r for r in e3 if r['kind']==kd]; rows.append(f'{name} ({len(rs)})'); vals.append(pk(rs,('мережа beam B=16','BL відпал','LNS + BL','гібрид: мережа→LNS')))
rows.append(f'Великі пазли, усі ({len(e3)})'); vals.append(pk(e3,('мережа beam B=16','BL відпал','LNS + BL','гібрид: мережа→LNS')))
ser=[('net','Мережа','#2a6fd6'),('hyb','Гібрид «мережа → LNS»','#e8683a'),('bl','BL-відпал','#1fa97a'),('lns','LNS + BL','#12336d')]
out['boxes']=[b for b in out['boxes'] if b['file'] in('fig7_scenarios.svg','fig9_paired.svg','fig8_angles.svg')]
out['boxes'].append({'file':'fig2_internal_box.svg','xmin':55,'xmax':108,'xticks':[60,70,80,90,100],'xlabel':'Ефективність розкладки, % від закладеного розв’язку','vline':{'x':100,'name':'Закладений розв’язок = 100 %'},'rows':rows,'series':[{'k':k,'name':n,'c':c} for k,n,c in ser],'vals':vals})
# костюм: повороти 0°/180° проти 0°/90°/180°/270°
sr=collections.defaultdict(lambda: collections.defaultdict(list))
for f in glob.glob(R+'results/suitrot/*.json'):
    j=json.load(open(f))
    for m in ('net','bl','lns','hyb'): sr[(j['n'],j['rot'])][m].append(100*j[m]['dens'])
srows=[];sv=[]
for n,nm in ((1,'Один костюм'),(2,'Два костюми')):
    for rot,rn in (('half','0° і 180°'),('any','0°, 90°, 180°, 270°')):
        v=sr[(n,rot)]; srows.append(f'{nm}, повороти {rn} ({len(v["bl"])})'); sv.append({m:v[m] for m in ('net','bl','lns','hyb')})
out['suit']={'rows':srows,'vals':sv}

# додати рядки костюма в рисунок про кути/повороти
for b in out['boxes']:
    if b['file']=='fig8_angles.svg' and not any('Костюм' in r or 'костюм' in r for r in b['rows']):
        for r,v in zip(srows,sv):
            b['rows'].append(r.replace('Один костюм','Один набір викрійок костюма').replace('Два костюми','Два набори викрійок костюма'))
            b['vals'].append({'net:base':v['net'],'bl':v['bl'],'lns':v['lns'],'hyb:base':v['hyb']})
        b['xmin']=40; b['xmax']=103
json.dump(out,open(R+'figures/data2.json','w'),ensure_ascii=False,indent=1)
print('rows suit',srows)
