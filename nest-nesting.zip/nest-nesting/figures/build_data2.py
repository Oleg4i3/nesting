import json,glob
def rows(tag): return [json.loads(l) for f in glob.glob(f'/home/claude/nest/results/{tag}_part*.jsonl') for l in open(f) if l.strip()]
def vals(rs,key): return [100*r['res'][key]['dens'] for r in rs if r['res'].get(key,{}).get('dens')]
A=rows('evalA'); B=rows('evalB'); P=rows('puz5'); PB=rows('puz5big')
colors={'net:base':'#2a6fd6','net:rlreal':'#9b59d0','net:rlscen':'#d4527f','bl':'#1fa97a','lns':'#12336d','hyb:base':'#e8683a','hyb:rlscen':'#8a5a00'}
ser7=[('net:base','Мережа (вихідна)'),('net:rlreal','Мережа + RL (звичайний рулон)'),('net:rlscen','Мережа + RL (усі сценарії)'),('bl','BL-відпал'),('lns','LNS + BL'),('hyb:base','Гібрид (вихідна мережа)'),('hyb:rlscen','Гібрид (RL-мережа)')]
kinds=[('plain','Прямокутний рулон'),('defects','З дефектами й обрізаними кутами'),('ragged','З нерівними краями'),('both','Нерівні краї й дефекти')]
rows7=[f'{n} ({sum(1 for r in A if r["kind"]==k)})' for k,n in kinds]+[f'Усі сценарії ({len(A)})']
v7=[{k2:vals([r for r in A if r['kind']==k],k2) for k2,_ in ser7} for k,_ in kinds]+[{k2:vals(A,k2) for k2,_ in ser7}]
serB=[('net:base','Мережа (вихідна, навчена на 15°)'),('net:ctl15','Мережа (контрольна, 15°)'),('net:mix5','Мережа (дані з кроком 5°)')]
extra=[('net:rlfree','Мережа + RL (крок 5°)')]
import os
if any('net:rlfree' in r['res'] for r in B): serB+=extra
ser8=serB+[('bl','BL-відпал'),('lns','LNS + BL'),('hyb:base','Гібрид (вихідна мережа)')]
col8={**colors,'net:ctl15':'#9b59d0','net:mix5':'#d4527f','net:rlfree':'#b8860b'}
sp=lambda st:[r for r in P if r['stage']==st]; spb=lambda st:[r for r in PB if r['stage']==st]
rows8=[f'Пазли 5°, 8–14 деталей, щільні ({len(sp(1))})',f'Пазли 5°, 8–14 деталей, з відходами ({len(sp(2))})',f'Пазли 5°, 18–26 деталей, щільні ({len(spb(1))})',f'Пазли 5°, 18–26 деталей, з відходами ({len(spb(2))})',
 f'Реальні деталі 5°, прямокутний рулон ({sum(1 for r in B if r["kind"]=="plain")})',f'Реальні деталі 5°, дефекти й краї ({sum(1 for r in B if r["kind"]=="both")})']
def vv(rs,k): return vals(rs,k)
v8=[{k:vv(g,k) for k,_ in ser8} for g in (sp(1),sp(2),spb(1),spb(2),[r for r in B if r['kind']=='plain'],[r for r in B if r['kind']=='both'])]
out={'figs':[],'boxes':[
 {'file':'fig7_scenarios.svg','xmin':40,'xmax':95,'xticks':[40,50,60,70,80,90],'xlabel':'Щільність розкрою, % (сума площ деталей / площа смуги; заборонена площа лічиться відходом)','rows':rows7,'series':[{'k':k,'name':n,'c':colors[k]} for k,n in ser7],'vals':v7},
 {'file':'fig8_angles.svg','xmin':40,'xmax':103,'xticks':[40,50,60,70,80,90,100],'xlabel':'Ефективність розкладки (пазли) або щільність розкрою (реальні деталі), %','rows':rows8,'series':[{'k':k,'name':n,'c':col8[k]} for k,n in ser8],'vals':v8}]}

serD=[('net:rlreal','Мережа + RL (звичайний рулон)'),('net:rlscen','Мережа + RL (усі сценарії)'),('bl','BL-відпал'),('lns','LNS + BL'),('hyb:base','Гібрид (вихідна мережа)'),('hyb:rlscen','Гібрид (RL-мережа)')]
def diffs(rs,k): return [100*(r['res'][k]['dens']-r['res']['net:base']['dens']) for r in rs if r['res'].get(k,{}).get('dens') and r['res'].get('net:base',{}).get('dens')]
vD=[{k:diffs([r for r in A if r['kind']==kk],k) for k,_ in serD} for kk,_ in kinds]+[{k:diffs(A,k) for k,_ in serD}]
out['boxes'].append({'file':'fig9_paired.svg','xmin':-8,'xmax':26,'xticks':[-5,0,5,10,15,20,25],'xlabel':'Різниця щільності з вихідною мережею на тій самій задачі, в.п. (праворуч від нуля — краще)','rows':rows7,'series':[{'k':k,'name':n,'c':colors[k]} for k,n in serD],'vals':vD})
json.dump(out,open('/home/claude/nest/figures/data2.json','w'),ensure_ascii=False,indent=1)
print('ok',len(A),len(B),len(P),len(PB))
