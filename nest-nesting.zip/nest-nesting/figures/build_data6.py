# Рис. 6: чотири сценарії; донавчена мережа, BL-відпал, LNS + BL, гібрид і Sparrow (з патчем про дефекти; медіана 3 зерен на задачу). Запускати після build_data5.py
import json,glob,statistics as st
R='/home/claude/nest/'
d=json.load(open(R+'figures/data2.json'))
A=[json.loads(l) for f in glob.glob(R+'results/evalA_part*.jsonl') for l in open(f) if l.strip()]
sp=json.load(open(R+'ext/scen/dens.json'))
kinds=[('plain','Прямокутний рулон'),('defects','З дефектами й обрізаними кутами'),('ragged','З нерівними краями'),('both','Нерівні краї й дефекти')]
ser=[('net:rlscen','Донавчена мережа','#2a6fd6'),('bl','BL-відпал','#1fa97a'),('lns','LNS + BL','#12336d'),('hyb:base','Гібрид «мережа → LNS»','#e8683a'),('sp','Sparrow (з патчем про дефекти)','#d4527f')]
rows=[];vals=[]
for k,n in kinds:
    rs=[r for r in A if r['kind']==k]; rows.append(f'{n} ({len(rs)})')
    v={m:[100*r['res'][m]['dens'] for r in rs] for m,_,_ in ser if m!='sp'}
    v['sp']=[st.median(sp[f"{r['set']}_{k}_{r['seed']}"]) for r in rs]; vals.append(v)
b=[x for x in d['boxes'] if x['file']=='fig7_scenarios.svg'][0]
b['rows']=rows; b['vals']=vals; b['series']=[{'k':k,'name':n,'c':c} for k,n,c in ser]
json.dump(d,open(R+'figures/data2.json','w'),ensure_ascii=False,indent=1); print(rows)
