from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(args=['--disable-gpu']);pg=b.new_page(viewport={'width':1150,'height':900})
    for f in ['fig1_puzzles','fig2_internal','fig5_real']:
        svg=open('/home/claude/nest/figures/%s.svg'%f,encoding='utf8').read()
        pg.set_content('<html><body style="margin:0;background:#fff">'+svg+'</body></html>')
        pg.screenshot(path='/home/claude/nest/figures/%s.png'%f)
    b.close()
