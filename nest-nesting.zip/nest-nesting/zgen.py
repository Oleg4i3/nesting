#!/usr/bin/env python3
"""zgen.py — пазли з заборонними зонами (півмісяці, S-смуги, плями, нерівні краї) різного розміру, що комбінуються.
Спершу вирізаємо зони з прямокутника рулона, ПОТІМ розбиваємо вільну область на деталі (діаграма Вороного +
викривлені внутрішні краї), тому еталон — точне розбиття вільної області без зазорів і без шматочків-«обрізків».

python3 zgen.py <тег> <перше_зерно> <кількість> [kinds=moon,sshape,mix,ragged]  ->  data/zgen_<тег>.json
"""
import sys, json, math, random
import numpy as np
import shapely
from shapely.geometry import Polygon, MultiPolygon, LineString, Point, box, MultiPoint
from shapely.ops import unary_union, polygonize, linemerge, split, voronoi_diagram
from shapely import affinity

DEBUG = False
KINDS = ['moon', 'sshape', 'mix', 'ragged']


def circle(cx, cy, r, n=48):
    return Polygon([(cx + r * math.cos(2 * math.pi * i / n), cy + r * math.sin(2 * math.pi * i / n)) for i in range(n)])


def moon(rng, cx, cy, R):
    r2 = R * rng.uniform(0.72, 0.92); d = R * rng.uniform(0.3, 0.62)
    g = circle(cx, cy, R).difference(circle(cx + d, cy, r2))
    return affinity.rotate(g, rng.uniform(0, 360), origin=(cx, cy))


def sshape(rng, cx, cy, Lh, th):
    A = Lh * rng.uniform(0.16, 0.26); k = 40; ph = rng.choice([-1, 1]); pts = []
    for i in range(k + 1):
        t = i / k; pts.append((ph * A * math.sin(2 * math.pi * t), (t - 0.5) * Lh))
    line = LineString(pts)
    g = line.buffer(th / 2, cap_style=1, join_style=1, resolution=8)
    g = g.simplify(0.15)
    return affinity.translate(affinity.rotate(g, rng.uniform(0, 360), origin=(0, 0)), cx, cy)


def blob(rng, cx, cy, r):
    n = rng.randint(5, 8); pts = []
    for i in range(n):
        a = 2 * math.pi * i / n + rng.uniform(-0.25, 0.25); rr = r * rng.uniform(0.6, 1.1)
        pts.append((cx + rr * math.cos(a), cy + rr * math.sin(a)))
    return Polygon(pts).buffer(r * 0.25, resolution=6).buffer(-r * 0.1, resolution=6)


def ragged(rng, W, L, side):
    base = rng.uniform(0.03, 0.09) * W; amp = rng.uniform(0.01, 0.06) * W; lam = rng.uniform(120, 420); ph = rng.uniform(0, 6.28)
    walk = 0; pts = []
    y = -20
    while y <= L + 20:
        walk = max(-0.04 * W, min(0.04 * W, walk + (rng.random() - 0.5) * 0.02 * W))
        pts.append((max(0, min(0.22 * W, base + amp * math.sin(2 * math.pi * y / lam + ph) + walk)), y)); y += 15
    if side == 'left':
        ring = [(-5, -20)] + pts + [(-5, L + 20)]
    else:
        ring = [(W + 5, -20)] + [(W - x, y) for x, y in pts] + [(W + 5, L + 20)]
    return Polygon(ring).buffer(0)


def corner(rng, W, L):
    a = rng.uniform(0.1, 0.3) * W; b = rng.uniform(0.08, 0.25) * L; left = rng.random() < 0.5; top = rng.random() < 0.7
    x0 = 0 if left else W; y0 = 0 if top else L; sx = 1 if left else -1; sy = 1 if top else -1
    return Polygon([(x0 - 5 * sx, y0 - 5 * sy), (x0 + sx * a, y0 - 5 * sy), (x0 + sx * a * 0.6, y0 + sy * b * 0.35), (x0 + sx * a * 0.25, y0 + sy * b * 0.7), (x0 - 5 * sx, y0 + sy * b)])


def make_zones(rng, kind, W, L):
    zs = []; centers = []

    def place(kind1):
        # розмір різний: від дрібних до великих; інколи поруч з уже наявною зоною (комбінація)
        R = W * math.exp(rng.uniform(math.log(0.05), math.log(0.28)))
        if centers and rng.random() < 0.4:
            c = rng.choice(centers); a = rng.uniform(0, 6.28); d = R * rng.uniform(0.5, 1.3)
            cx, cy = c[0] + d * math.cos(a), c[1] + d * math.sin(a)
        else:
            cx = rng.uniform(R * 0.6, W - R * 0.6); cy = rng.uniform(0.02 * L, 0.98 * L)
        if kind1 == 'moon': g = moon(rng, cx, cy, R)
        elif kind1 == 'sshape': g = sshape(rng, cx, cy, R * rng.uniform(2.0, 3.6), R * rng.uniform(0.22, 0.55))
        else: g = blob(rng, cx, cy, R * 0.8)
        centers.append((cx, cy)); zs.append(g)

    if kind == 'moon':
        for _ in range(rng.randint(2, 6)): place('moon')
    elif kind == 'sshape':
        for _ in range(rng.randint(2, 6)): place('sshape')
    elif kind == 'mix':
        for _ in range(rng.randint(3, 8)): place(rng.choice(['moon', 'sshape', 'blob', 'moon', 'sshape']))
    elif kind == 'ragged':
        pass
    if kind in ('ragged', 'mix'):
        mode = rng.choice(['both', 'left', 'right']) if kind == 'ragged' else rng.choice(['left', 'right', 'none', 'none'])
        for s in (['left', 'right'] if mode == 'both' else ([] if mode == 'none' else [mode])): zs.append(ragged(rng, W, L, s))
        if kind == 'ragged':
            for _ in range(rng.randint(0, 3)): place(rng.choice(['moon', 'sshape', 'blob']))
        if rng.random() < 0.3: zs.append(corner(rng, W, L))
    return zs


def polys(g):
    if g.is_empty: return []
    if isinstance(g, Polygon): return [g]
    return [p for p in getattr(g, 'geoms', []) if isinstance(p, Polygon) and not p.is_empty] + \
           [q for p in getattr(g, 'geoms', []) if not isinstance(p, Polygon) for q in polys(p)]


def curve_edge(rng, ls, sc=1.0):
    """Замінює пряму ділянку ламаною-кривою з фіксованими кінцями."""
    n = ls.length
    if n < 22: return ls
    k = max(6, int(n / 10)); a1 = sc * min(0.14 * n, 26) * rng.uniform(-1, 1); a2 = sc * min(0.06 * n, 12) * rng.uniform(-1, 1); ph = rng.uniform(0, 6.28)
    pts = []
    for i in range(k + 1):
        s = i / k; p = ls.interpolate(s * n); q = ls.interpolate(min(n, s * n + 1)); p0 = ls.interpolate(max(0, s * n - 1))
        dx, dy = q.x - p0.x, q.y - p0.y; l = math.hypot(dx, dy) or 1
        d = a1 * math.sin(math.pi * s) + a2 * math.sin(2 * math.pi * s + ph) * math.sin(math.pi * s)
        pts.append((p.x - dy / l * d, p.y + dx / l * d))
    pts[0] = tuple(ls.coords[0]); pts[-1] = tuple(ls.coords[-1])
    return LineString(pts)


def partition(rng, F, nseeds, W, L, amin):
    """Розбиття вільної області F на деталі: Вороного за довільними вузлами + merge дрібних + викривлення країв."""
    F = shapely.set_precision(F, 0.001)
    for att in range(8):
        pts = []; tries = 0; mind = math.sqrt(F.area / max(1, nseeds)) * 0.62
        while len(pts) < nseeds and tries < 4000:
            tries += 1
            x, y = rng.uniform(0, W), rng.uniform(0, L); p = Point(x, y)
            if not F.contains(p): continue
            if all((x - a) ** 2 + (y - b) ** 2 > mind ** 2 for a, b in pts): pts.append((x, y))
        if len(pts) < 4: return None
        vor = voronoi_diagram(MultiPoint(pts), envelope=box(-50, -50, W + 50, L + 50))
        cells = list(vor.geoms)
        parts = []
        for c in cells:
            for p in polys(shapely.set_precision(c.intersection(F), 0.001)): parts.append(p)
        # з діркою (зона всередині клітинки) — розрізаємо прямою через дірку
        fixed = []
        for p in parts:
            if p.interiors:
                h = Polygon(p.interiors[0]); cx, cy = h.centroid.x, h.centroid.y; a = rng.uniform(0, math.pi)
                ln = LineString([(cx - 3000 * math.cos(a), cy - 3000 * math.sin(a)), (cx + 3000 * math.cos(a), cy + 3000 * math.sin(a))])
                try:
                    for q in split(p, ln).geoms: fixed += polys(q)
                except Exception: return None
            else: fixed.append(p)
        parts = [p for p in fixed if not p.is_empty]
        if any(p.interiors for p in parts): continue
        # злиття дрібних і тонких частин з сусідом за найдовшою спільною межею
        def thin(p): return p.area < amin or 4 * p.area / max(1e-9, p.length) < 11
        changed = True
        while changed:
            changed = False
            parts.sort(key=lambda p: p.area)
            for i, p in enumerate(parts):
                if not thin(p): continue
                best, bl = None, 0.5
                for j, q in enumerate(parts):
                    if i == j: continue
                    l = p.boundary.intersection(q.boundary).length
                    if l > bl: best, bl = j, l
                if best is None: continue
                m = unary_union([p, parts[best]])
                if isinstance(m, Polygon) and not m.interiors:
                    parts = [q for k, q in enumerate(parts) if k not in (i, best)] + [m]; changed = True; break
        # різні розміри: частину сусідніх пар зливаємо у більші деталі
        for _ in range(int(len(parts) * rng.uniform(0.0, 0.25))):
            i = rng.randrange(len(parts)); best, bl = None, 5.0
            for j, q in enumerate(parts):
                if j != i:
                    l = parts[i].boundary.intersection(q.boundary).length
                    if l > bl: best, bl = j, l
            if best is None or parts[i].area + parts[best].area > 2.6 * (F.area / max(1, nseeds)): continue
            m = unary_union([parts[i], parts[best]])
            if isinstance(m, Polygon) and not m.interiors: parts = [q for k, q in enumerate(parts) if k not in (i, best)] + [m]
        if len(parts) < 5: continue
        # викривлення внутрішніх країв
        noded = unary_union([p.boundary for p in parts])
        segs = [g for g in ([noded] if isinstance(noded, LineString) else list(noded.geoms)) if isinstance(g, LineString) and not g.is_empty]
        Fb = F.boundary
        if DEBUG: print('polygonize noded', len(list(polygonize(noded))), 'parts', len(parts), 'F parts', len(polys(F)), [round(p.area) for p in parts])
        Fbuf = Fb.buffer(0.03); inner = [g for g in segs if not Fbuf.contains(g)]
        lm = linemerge(inner) if inner else None
        interior = [] if lm is None else ([lm] if isinstance(lm, LineString) else list(lm.geoms))
        bnd = unary_union([g for g in segs if Fbuf.contains(g)])
        for amp in (1.0, 0.5, 0.2, 0.0):
            rr = random.Random(att * 17 + int(amp * 10)); lines = [bnd] + [curve_edge(rr, g, amp) if amp else g for g in interior]
            try:
                faces = [f for f in polygonize(unary_union(lines)) if f.area > 1.0 and F.buffer(0.01).contains(f.representative_point())]
            except Exception: continue
            tot = sum(f.area for f in faces)
            if DEBUG and amp == 0.0:
                global DBG; DBG = (F, parts, interior, bnd, noded)
            if DEBUG: print('amp',amp,'faces',len(faces),'parts',len(parts),'dA',round(tot-F.area,1),'valid',all(f.is_valid for f in faces),'holes',sum(1 for f in faces if f.interiors))
            if abs(tot - F.area) < 0.003 * F.area and all(f.is_valid and not f.interiors for f in faces) and len(faces) == len(parts):
                return faces
            if amp == 0.0 and abs(tot - F.area) < 0.003 * F.area and all(f.is_valid for f in faces): return faces
    return None


def gen(seed, kind, big):
    rng = random.Random(seed * 7919 + 13)
    n = rng.randint(18, 26) if big else rng.randint(8, 14)
    W = 10 * rng.randint(24, 36)
    L0 = round(n * 12500 * rng.uniform(0.9, 1.1) / W / 10) * 10
    for att in range(30):
        zs = make_zones(rng, kind, W, L0)
        R = box(0, 0, W, L0)
        zu = unary_union([z.buffer(0) for z in zs]).intersection(R)
        F = R.difference(zu)
        comps = sorted(polys(F), key=lambda p: -p.area)
        amin = 0.4 * (F.area / n)
        keep = [c for c in comps if c.area >= max(amin * 2, 2500) and not c.interiors]
        if not keep: continue
        Fk = unary_union(keep)
        zfrac = 1 - Fk.area / R.area
        if zfrac > 0.3 or zfrac < 0.02: continue
        ns = max(6, round(n * Fk.area / R.area))
        faces = None
        for pa in range(4):
            Fp = Fk if isinstance(Fk, Polygon) else Fk
            # деталі кожної компоненти окремо (щоб Вороного не «перестрибувало» через зону)
            res = []
            tot_ns = ns
            ok = True
            for c in keep:
                k = max(2, round(tot_ns * c.area / Fk.area))
                r = partition(rng, c, k, W, L0, amin)
                if r is None: ok = False; break
                res += r
            if ok: faces = res; break
        if faces is None: continue
        # заборонені зони: кожна окремо, обрізана прямокутником + кишені, що відпали (малі вільні ділянки)
        zon = []
        for z in zs:
            for p in polys(z.buffer(0).intersection(R)):
                zon.append(Polygon(p.exterior))
        for c in comps:
            if c not in keep: zon.append(Polygon(c.exterior))
        # зони — прості багатокутники; перевірка: деталі не перетинають зон
        zun = unary_union(zon)
        if any(f.intersection(zun).area > 3.0 for f in faces): continue
        if len(faces) < 6 or min(f.area for f in faces) < 800: continue
        return dict(seed=seed, kind=kind, big=big, width=W, length=L0, n=len(faces),
                    zones=[[list(c) for c in p.exterior.coords[:-1]] for p in zon],
                    pieces=[[list(c) for c in f.exterior.coords[:-1]] for f in faces],
                    zoneFrac=1 - sum(f.area for f in faces) / R.area)
    return None


def zones_for(seed, kind, W, L):
    """Тільки зони (для задач із реальними лекалами): кільця зовнішніх контурів, обрізані прямокутником рулона."""
    rng = random.Random(seed * 104729 + 29)
    for att in range(40):
        zs = make_zones(rng, kind, W, L)
        R = box(0, 0, W, L)
        zu = unary_union([z.buffer(0) for z in zs]).intersection(R)
        if not (0.02 <= zu.area / R.area <= 0.3): continue
        out = []
        for z in zs:
            for p in polys(z.buffer(0).intersection(R)): out.append([list(c) for c in p.exterior.coords[:-1]])
        return out
    return []


if __name__ == '__main__' and sys.argv[1] == 'zones':
    # python3 zgen.py zones <W> <L> <kind> <seed>  -> JSON у stdout
    print(json.dumps(zones_for(int(sys.argv[5]), sys.argv[4], float(sys.argv[2]), float(sys.argv[3]))))
    sys.exit(0)

if __name__ == '__main__':
    tag, s0, cnt = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
    kinds = (sys.argv[4] if len(sys.argv) > 4 else ','.join(KINDS)).split(',')
    out = []; fail = 0
    for i in range(cnt):
        kind = kinds[i % len(kinds)]; big = 0 if i % 3 == 0 else 1
        try: r = gen(s0 + i, kind, big)
        except Exception as e: r = None; print('ERR', s0 + i, kind, repr(e)[:100])
        if r: out.append(r)
        else: fail += 1
    json.dump(out, open(f'data/zgen_{tag}.json', 'w'))
    print(f'{tag}: {len(out)} пазлів, невдач {fail}')
