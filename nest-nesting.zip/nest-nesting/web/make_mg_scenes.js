// Сцени «кілька виробів на дефектному рулоні» для симулятора (ті самі задачі, на яких виконано остаточне порівняння, зерно 201).
// node web/make_mg_scenes.js  → examples/scenes/mg_*.json
const fs=require('fs'),path=require('path'),N=require('../raster.js'),T=require('../rl_tasks.js');
const rnd=v=>Math.round(v*10)/10,ser=p=>({v:p.vertices.map(a=>[rnd(a.x),rnd(a.y)]),c:(p.bezierControls||p.vertices.map(()=>null)).map(c=>c?[rnd(c.x),rnd(c.y)]:null)});
const LIST=[['fs_korf_dress','both','deg5',2,'Сукня ×2, рулон з рваним краєм і дірками, кути кожні 5°'],['fs_korf_dress','pholes','any',2,'Сукня ×2, рулон з дірками, кути 0°/90°/180°/270°'],
 ['fs_korf_blouse','both','deg5',3,'Блуза ×3, рулон з рваним краєм і дірками, кути кожні 5°'],['fs_korf_blouse','pholes','any',2,'Блуза ×2, рулон з дірками, кути 0°/90°/180°/270°'],
 ['suit','both','deg5',2,'Костюм кравця ×2, рулон з рваним краєм і дірками, кути кожні 5°'],['fs_hugo','both','deg5',2,'FreeSewing (Hugo) ×2, рулон з рваним краєм і дірками, кути кожні 5°']];
const out=[];
for(const [set,kind,rot,cp,title] of LIST){
  const spec={set,kind,seed:201,n:set==='suit'?13:99,rot,copies:cp},t=T.build(spec),id=`mg_${rot}_${set}_${kind}_201_x${cp}`;
  const ang=N.allowedFor(t.pcs[0],t.rules).rotations.map(a=>+(a*90).toFixed(6));
  const sc={format:'nest-scene-v1',name:id,title,width:t.W,rotations:ang,mirror:false,pieces:t.pcs.map(ser),blocked:t.blocked.map(ser),note:'Задача з остаточного порівняння: рулон з забороненими зонами (дірки за формами деталей, рваний край). Sparrow (найкращий із трьох запусків по 10 с, з нашим патчем для зон) показано попередньо.'};
  fs.writeFileSync(path.join(__dirname,'..','examples','scenes',id+'.json'),JSON.stringify(sc));out.push(id);console.log(id,t.pcs.length,t.W,t.blocked.length,ang.length);
}
fs.writeFileSync(path.join(__dirname,'mg_scene_ids.json'),JSON.stringify(out.map((id,i)=>({id,title:LIST[i][4],priv:LIST[i][0]!=='fs_hugo'&&LIST[i][0]!=='suit'?true:LIST[i][0]==='suit'}))));
