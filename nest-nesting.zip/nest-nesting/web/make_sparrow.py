# Перетворює розкладки Sparrow (final_*.json) на багатокутники в координатах симулятора. python3 web/make_sparrow.py
import json,math
O='/home/claude/ext/sparrow_src/repo/output/'; S='/home/claude/nest/ext/sp_sim/'
src={'puzzle_8':S+'final_puzzle_8.json','puzzle_21':S+'final_puzzle_21.json','trim_11':S+'final_trim_11.json','suit_1':S+'final_suit_1.json','suit_2':S+'final_suit_2.json',
 'esicup_marques':O+'final_marques.json','esicup_albano':O+'final_albano.json','esicup_dagli':O+'final_dagli.json','esicup_mao':O+'final_mao.json','esicup_swim':O+'final_swim.json'}
def conv(f,W):
    j=json.load(open(f)); H=j['strip_height']; s=W/H; polys=[]
    for pi in j['solution']['layout']['placed_items']:
        pts=j['items'][pi['item_id']]['shape']['data'][:-1]
        th=math.radians(pi['transformation']['rotation']); tx,ty=pi['transformation']['translation']; c,sn=math.cos(th),math.sin(th)
        q=[(c*x-sn*y+tx,sn*x+c*y+ty) for x,y in pts]
        polys.append({'v':[[round((H-y)*s,2),round(x*s,2)] for x,y in q]})   # поворот на 90°: x_sim=H-y, y_sim=x
    L=j['solution']['strip_width']*s
    return {'len':round(L,2),'polys':polys,'dens_sp':j['solution']['density']}
W={'puzzle_8':260,'puzzle_21':250,'trim_11':260,'suit_1':290,'suit_2':290}
out={k:conv(f,W.get(k,300)) for k,f in src.items()}
json.dump(out,open('/home/claude/nest/web/sparrow_layouts.json','w'),separators=(',',':'))
print({k:(len(v['polys']),v['len'],v['dens_sp']) for k,v in out.items()})
