# Розкладки SVGnest (ext/svg_sim/*.json, див. ext/run_svgnest_layouts.js) → багатокутники в координатах симулятора. python3 web/make_svgnest.py
import sys,json; sys.path.insert(0,'/home/claude/nest/ext')
import svg_eval
W={'puzzle_8':260,'puzzle_21':250,'trim_11':260}
out={}
for k in ['puzzle_8','puzzle_21','trim_11','esicup_marques','esicup_albano','esicup_dagli','esicup_mao','esicup_swim']:
    x=svg_eval.load(f'/home/claude/nest/ext/svg_sim/{k}.json'); H=x['W']; s=W.get(k,300)/H
    out[k]={'len':round(x['len']*s,2),'polys':[{'v':[[round((H-py)*s,2),round(px*s,2)] for px,py in q]} for q in x['polys']],'dens':x['dens'],'n':x['n'],'overlap':x['overlap']}
json.dump(out,open('/home/claude/nest/web/svgnest_layouts.json','w'),separators=(',',':'))
print({k:(v['n'],v['len'],round(v['dens']*100,1)) for k,v in out.items()})
