// Точка входу Web Worker: одна задача — один метод. Повідомлення: {scene, method, budgetMs, seed}
const N=__req('raster.js'),Bm=__req('beam.js'),Pf=__req('portfolio.js'),B=__req('baselines.js'),L=__req('lns2.js'),Z=__req('zones.js'),P=__req('puzzle.js'),X=__req('nnx.js');
const net=X.MLPX.fromJSON(__WEIGHTS__),repNet=X.MLPX.fromJSON(__REPWEIGHTS__);
const rnd=v=>Math.round(v*10)/10,ser=p=>({v:p.vertices.map(a=>[rnd(a.x),rnd(a.y)]),c:(p.bezierControls||p.vertices.map(()=>null)).map(c=>c?[rnd(c.x),rnd(c.y)]:null)});
const toPoly=p=>({vertices:p.v.map(a=>({x:a[0],y:a[1]})),bezierControls:p.c?p.c.map(c=>c?{x:c[0],y:c[1]}:null):null});
onmessage=e=>{
  const {scene,method,budgetMs,seed}=e.data,pcs=scene.pieces.map(toPoly),W=scene.width,bl=(scene.blocked||[]).map(toPoly);
  const rules={rotations:scene.rotations.map(a=>a/90),mirror:!!scene.mirror};
  const area=pcs.reduce((s,p)=>s+N.polygonArea(p),0),maxLen=Math.max(6000,Math.ceil(3*area/W/10)*10+500);
  const o={width:W,maxLength:maxLen,seed:seed||7,blocked:bl},ms=budgetMs||10000;
  const t0=Date.now();let pl=null,howNet=null;
  const beam=()=>Pf.solvePortfolio(pcs,rules,net,{width:W,maxLength:maxLen,blocked:bl,maxMs:15000});
  try{
    if(method==='net'){const r=beam();pl=r.placements;howNet=r.how}
    else if(method==='bl')pl=B.solveBLSA(pcs,rules,{...o,budgetMs:ms}).placements;
    else if(method==='lns')pl=L.solveLNS(pcs,rules,{...o,budgetMs:ms,recreate:'BL',kMin:6,kMax:14,T0:0.6}).placements;
    else if(method==='hyb'){const bm=beam(),tb=Date.now()-t0,init=new Array(pcs.length).fill(null);bm.seq.forEach(s=>{init[s.pi]={vi:s.vi,A:s.A,cy:s.cy}});
      pl=L.solveLNS(pcs,rules,{...o,budgetMs:Math.max(1000,ms-tb),recreate:'BL',kMin:4,kMax:10,T0:0.25,init}).placements}
    else if(method==='lns2'||method==='lns2net'){
      // двоетапний LNS: 1) звичайний LNS+BL на половину бюджету; 2) низькотемпературний LNS від його розкладки; відновлення лише BL (контроль) або BL/мережа 50/50
      const t1=Math.round(ms/2),first=L.solveLNS(pcs,rules,{...o,budgetMs:t1,recreate:'BL',kMin:6,kMax:14,T0:0.6}),
        pol={...o,init:first.layout,budgetMs:ms-t1,kMin:3,kMax:8,T0:0.05,T1:0.01};
      pl=(method==='lns2'?L.solveLNS(pcs,rules,{...pol,recreate:'BL'}):L.solveLNS(pcs,rules,{...pol,recreate:'MIX',mixP:0.5,net:repNet,temp:0.3})).placements}
  }catch(err){postMessage({method,failed:true,error:String(err),ms:Date.now()-t0});return}
  const dt=Date.now()-t0;
  if(!pl||pl.filter(Boolean).length!==pcs.length){postMessage({method,failed:true,ms:dt,placed:pl?pl.filter(Boolean).length:0});return}
  const ev=Z.evaluateWithZones(pcs,pl,bl,W);
  if(!ev.valid){postMessage({method,failed:true,ms:dt});return}
  postMessage({method,failed:false,ms:dt,how:howNet,len:ev.len,dens:area/(W*ev.len),polys:P.placementsToPolys(pcs,pl).map(ser)});
};
