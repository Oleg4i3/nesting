// Збирає web/simulator.html: рушій (UMD-модулі) + ваги + приклади в одному файлі. node web/build.js
const fs=require('fs'),path=require('path'),root=path.join(__dirname,'..');
const mods=['raster.js','features.js','puzzle.js','guided.js','baselines.js','lns2.js','zones.js','beam.js','portfolio.js','nn.js','nnx.js'];
let w='const __defs={},__mods={};function __req(p){const n=p.replace(/^\\.\\//,"");if(!__mods[n]){const m={exports:{}};__mods[n]=m;__defs[n](m,m.exports,__req)}return __mods[n].exports}\n';
for(const m of mods)w+=`__defs[${JSON.stringify(m)}]=function(module,exports,require){\n${fs.readFileSync(path.join(root,m),'utf8')}\n};\n`;
const weights=fs.readFileSync(path.join(root,'weights/v2/r3a.json'),'utf8');
w+=fs.readFileSync(path.join(__dirname,'worker_main.js'),'utf8').replace('__WEIGHTS__',weights.trim());
fs.writeFileSync(path.join(__dirname,'worker.bundle.js'),w);
const ex=[];
const add=(file,title)=>ex.push({id:path.basename(file,'.json'),title,json:JSON.parse(fs.readFileSync(path.join(root,file),'utf8'))});
if(!process.env.NOSUIT){add('examples/private/suit_1.json','Костюм кравця, 1 шт. (13 деталей, рулон 290 px, повороти 0°/180°)');add('examples/private/suit_2.json','Костюм кравця, 2 шт. (26 деталей)')}
add('examples/scenes/puzzle_8.json','Пазл, 8 деталей');add('examples/scenes/puzzle_21.json','Пазл, 21 деталь');add('examples/scenes/trim_11.json','Пазл з обрізками, 11 деталей');add('examples/scenes/hole.json','Пазл з діркою, 21 деталь');
for(const [n,t] of [['marques','ESICUP marques: одяг, 24 деталі'],['albano','ESICUP albano: одяг, 24 деталі'],['dagli','ESICUP dagli: одяг, 30 деталей'],['mao','ESICUP mao: одяг, 20 деталей'],['swim','ESICUP swim: купальники, 48 деталей']])add(`examples/real/esicup_${n}.json`,t);
let t=fs.readFileSync(path.join(__dirname,'sim.template.html'),'utf8');
t=t.replace('/*WORKER*/""',()=>JSON.stringify(w)).replace('/*EXAMPLES*/[]',()=>JSON.stringify(ex)).replace('/*EDITOR*/""',()=>JSON.stringify(fs.readFileSync(path.join(__dirname,'editor_embed.html'),'utf8')).replace(/</g,'\\u003c'));
fs.writeFileSync(path.join(__dirname,'simulator.html'),t);console.log('simulator.html',(t.length/1024).toFixed(0)+'KB');
