const {chromium}=require('playwright');
(async()=>{const b=await chromium.launch(),p=await b.newPage({viewport:{width:1200,height:900}});
 const logs=[];p.on('console',m=>logs.push(m.text()));p.on('pageerror',e=>logs.push('ERR '+e.message));
 await p.goto('file:///home/claude/nest/web/simulator.html');
 await p.fill('#budget','3');
 await p.click('#run');
 await p.waitForFunction(()=>document.getElementById('status').textContent==='Готово.',null,{timeout:120000});
 await p.screenshot({path:'/home/claude/nest/web/shot1.png',fullPage:true});
 console.log(await p.innerText('#tbl'));
 // real example
 await p.click('#list button:has-text("marques")');await p.click('#run');await p.waitForFunction(()=>document.getElementById('status').textContent.startsWith('Виконується'));
 await p.waitForFunction(()=>document.getElementById('status').textContent==='Готово.',null,{timeout:120000});
 console.log(await p.innerText('#tbl'));await p.screenshot({path:'/home/claude/nest/web/shot2.png',fullPage:true});
 console.log(logs.join('\n'));await b.close()})();
