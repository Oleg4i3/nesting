import json,glob,collections,statistics as st,sys
rows=[json.loads(l) for f in glob.glob('results/zreal_part*.jsonl') for l in open(f)]
print(len(rows),'задач')
def show(sel,label):
    m=collections.defaultdict(list)
    for r in sel:
        best=max((v['dens'] for v in r['res'].values() if v.get('dens')),default=None)
        for k,v in r['res'].items():
            if v.get('dens'): m[k].append(100*v['dens'])
    print(label,len(sel),' | '.join(f"{k} {st.mean(v):.1f}" for k,v in m.items()))
show(rows,'усі')
for g in sorted({r['set'] for r in rows}): show([r for r in rows if r['set']==g],g)
for k in sorted({r['kind'] for r in rows}): show([r for r in rows if r['kind']==k],k)
