#!/usr/bin/env python3
"""zgen2.py — пазли «з точковими дотиками»: деталі торкаються сусідів лише в кількох точках (як у реальних розкладках),
заборонені зони — нерівні краї й діри у формі деталей викройок (кишеня, рукав, ...). Зони вирізано до розбиття.
python3 zgen2.py <тег> <перше_зерно> <кількість> [pool=train|test]  ->  data/zgen_<тег>.json
python3 zgen2.py zones <W> <L> <kind> <seed> [pool]  -> зони (JSON) для задач із реальними лекалами
Пул форм: train — brian, teagan, bella, penelope, sandy, aaron, titan; test — carlton, yuri, bent, sven (не збігаються)."""
import sys, json, math, random
import shapely
from shapely.geometry import Polygon, LineString, Point, box
from shapely.ops import unary_union, linemerge
from shapely import affinity
import zgen as Z0

POOLS = {'train': ['brian', 'teagan', 'bella', 'penelope', 'sandy', 'aaron', 'titan'], 'test': ['carlton', 'yuri', 'bent', 'sven']}
_parts = None
def parts(pool):
    global _parts
    if _parts is None: _parts = json.load(open('/home/claude/ext/fs/fs_parts.json'))
    out = []
    for d in POOLS[pool]:
        for q in _parts.get(d, []):
            p = Polygon(q['pts']).buffer(0)
            if p.geom_type == 'Polygon' and p.area > 2e4: out.append((d + '.' + q['name'].split('.')[-1], p.simplify(0.5)))
    return out

def part_zone(rng, pool, W, L):
    name, p = rng.choice(parts(pool))
    c = p.centroid; p = affinity.translate(p, -c.x, -c.y)
    p = affinity.rotate(p, rng.uniform(0, 360), origin=(0, 0))
    if rng.random() < 0.5: p = affinity.scale(p, -1, 1, origin=(0, 0))
    s = (W / 1500.0) * rng.uniform(0.7, 1.6)
    p = affinity.scale(p, s, s, origin=(0, 0))
    b = p.bounds; w, h = b[2] - b[0], b[3] - b[1]
    cx = rng.uniform(w / 2 * 0.7, W - w / 2 * 0.7); cy = rng.uniform(h / 2 * 0.5, max(h / 2 * 0.5 + 1, L - h / 2 * 0.5))
    return affinity.translate(p, cx, cy)

def make_zones2(rng, kind, W, L, pool):
    zs = []
    if kind == 'pplain': return zs
    n = rng.randint(1, 4) if kind == 'phole' else rng.randint(0, 2)
    for _ in range(n):
        for att in range(30):
            z = part_zone(rng, pool, W, L)
            if all(z.distance(o) > 12 for o in zs) and z.intersection(box(0, 0, W, L)).area > 0.6 * z.area: zs.append(z); break
    if kind == 'pragged':
        mode = rng.choice(['both', 'left', 'right'])
        for s in (['left', 'right'] if mode == 'both' else [mode]): zs.append(Z0.ragged(rng, W, L, s))
        if rng.random() < 0.25: zs.append(Z0.corner(rng, W, L))
    return zs

def sparsify(rng, faces, gmin=5.0, gmax=10.0):
    n = len(faces); strips = [[] for _ in range(n)]
    for i in range(n):
        for j in range(i + 1, n):
            it = faces[i].boundary.intersection(faces[j].boundary)
            gs = [g for g in ([it] if isinstance(it, LineString) else list(getattr(it, 'geoms', []))) if isinstance(g, LineString) and not g.is_empty]
            if not gs: continue
            lm = linemerge(gs)
            for g in ([lm] if isinstance(lm, LineString) else list(lm.geoms)):
                ln = g.length
                if ln < 8: continue
                nn = rng.choice([i, j]); k = rng.choices([0, 1, 2], [0.3, 0.5, 0.2])[0]
                ts = sorted(rng.uniform(0.15, 0.85) * ln for _ in range(k)); h = max(6.0, 0.12 * ln); G = rng.uniform(gmin, gmax)
                m = max(3, int(ln / 3)); P = []; Q = []
                for t in range(m + 1):
                    s = ln * t / m; p = g.interpolate(s); a = g.interpolate(max(0, s - 1.5)); b = g.interpolate(min(ln, s + 1.5))
                    dx, dy = b.x - a.x, b.y - a.y; l = math.hypot(dx, dy) or 1; nx, ny = -dy / l, dx / l
                    if faces[nn].buffer(0).contains(Point(p.x + nx * 0.8, p.y + ny * 0.8)) is False: nx, ny = -nx, -ny
                    w = 1.0
                    for s0 in ts: w = min(w, min(1.0, ((s - s0) / h) ** 2))
                    P.append((p.x, p.y)); Q.append((p.x + nx * G * w, p.y + ny * G * w))
                poly = Polygon(P + Q[::-1]).buffer(0)
                if not poly.is_empty: strips[nn].append(poly)
    out = []
    for f, st in zip(faces, strips):
        if st:
            g = f.difference(unary_union(st))
            ps = Z0.polys(g)
            if ps:
                big = max(ps, key=lambda q: q.area)
                if big.area >= 0.7 * f.area and not big.interiors: g = big
                else: g = f
            else: g = f
        else: g = f
        out.append(g)
    return out


def wave(g, rg, amp, lam, W, L, wall_ragged):
    """Хвилястість контуру: кожна вершина зсувається ВСЕРЕДИНУ деталі на w(s)∈[0,amp] (дві гармоніки з довжинами хвиль lam і ~0.45*lam,
    випадкові фази). Гребені w=0 лишаються на місці — там і виникають точки дотику. Ділянки на краю рулона: або прямі (w=0), або хвилясті."""
    if g.is_empty or amp < 0.3: return g
    amp = min(amp, lam / 5.0)
    ring = g.exterior
    if not ring.is_ccw: ring = type(ring)(list(ring.coords)[::-1])
    ring = ring.segmentize(4.0); co = list(ring.coords)[:-1]; n = len(co)
    f1, f2, l2 = rg.uniform(0, 6.283), rg.uniform(0, 6.283), lam * rg.uniform(0.35, 0.6)
    out = []; s_ = 0.0
    for i in range(n):
        p0, p1, p2 = co[i - 1], co[i], co[(i + 1) % n]
        s_ += math.hypot(p1[0] - p0[0], p1[1] - p0[1])
        tx, ty = p2[0] - p0[0], p2[1] - p0[1]; h = math.hypot(tx, ty) or 1.0
        w = amp * (0.5 + 0.25 * math.sin(6.283 * s_ / lam + f1) + 0.25 * math.sin(6.283 * s_ / l2 + f2))
        onwall = p1[0] < 0.6 or p1[0] > W - 0.6 or p1[1] < 0.6 or p1[1] > L - 0.6
        if onwall and not wall_ragged: w = 0.0
        out.append((p1[0] - ty / h * w, p1[1] + tx / h * w))
    h = Polygon(out)
    if not h.is_valid: h = h.buffer(0)
    ps = Z0.polys(h)
    if not ps: return g
    h = max(ps, key=lambda q: q.area)
    return Polygon(h.exterior) if h.area > 0.75 * g.area else g


def bite(g, rg, ub, W, L):
    """Лакуни: еліптичні «відкушені» ділянки контуру. Мало, але великі: розмір росте з ub, кількість — помірно."""
    if ub <= 0 or g.is_empty or g.area < 1500: return g
    bd = g.boundary; per = bd.length; h = g
    nb = int(per / 100 * 0.45 * ub + rg.random() * 0.8)
    for _ in range(nb):
        c = bd.interpolate(rg.random() * per)
        rr = (6 + 24 * ub) * rg.uniform(0.5, 1.0)
        e = affinity.rotate(affinity.scale(c.buffer(1, 12), rr * rg.uniform(1.0, 2.6), rr * rg.uniform(0.45, 0.9)), rg.uniform(0, 180), origin=c)
        ps = Z0.polys(h.difference(e))
        if ps:
            t = max(ps, key=lambda q: q.area)
            if t.area > 0.8 * g.area: h = Polygon(t.exterior)
    return h


def gap_params(seed, t):
    """Незалежні ручки зазору. Кожна росте з t зі своєю швидкістю r_k (0 — ручку вимкнено у цього пазла); u_k=min(1,t*r_k).
    shr — середній зазор (стиск), wav — амплітуда хвилястості, wedge — кут розходження (поворот навколо точки дотику), trav — дальність осаджування."""
    rp = random.Random(seed * 31 + 5); r = {}
    for k in ['shr', 'wav', 'wedge', 'trav', 'bite']: r[k] = rp.uniform(0.35, 1.7) if rp.random() > 0.25 else 0.0
    if max(r.values()) == 0: r['wedge'] = 1.0
    return {k: min(1.0, t * v) for k, v in r.items()}, rp.random() < 0.5


def settle(seed, faces, zones, W, L, t=0.5):
    """Осаджування за параметрами gap_params: стиск → хвилястість → кілька раундів «повернути навколо точки дотику і підсунути до першого
    контакту». Контакти точкові, зазори — змінної ширини та клиноподібні. t=0 — точний розбиток (повний дотик)."""
    u, wall_ragged = gap_params(seed, t)
    rect = box(0, 0, W, L); zun = unary_union(zones) if zones else None
    shr = 0.3 + 16.0 * u['shr']; amp = 1.5 + 14.0 * u['wav']; alpha = 0.3 + 16.0 * u['wedge']; tmax = 2 + 90 * u['trav']
    rounds = 2 + int(round(3 * max(u.values())))
    n = len(faces); R = [random.Random(seed * 1000 + i) for i in range(n)]
    P = []
    for i, f in enumerate(faces):
        rg = R[i]; g = f
        if t > 0.01:
            d = shr * rg.uniform(0.3, 1.0)
            if d > 0.2:
                h = g.buffer(-d, join_style=1); ps = Z0.polys(h)
                if ps and max(ps, key=lambda q: q.area).area > 0.6 * f.area: g = Polygon(max(ps, key=lambda q: q.area).exterior)
            g = bite(g, rg, u['bite'], W, L)
            if u['wav'] > 0: g = wave(g, rg, amp * rg.uniform(0.5, 1.0), rg.uniform(60, 220), W, L, wall_ragged and rg.random() < 0.8)
        P.append(g if t <= 0.01 else g.simplify(0.4))
    if t <= 0.01: return P
    def ok(g, i):
        if not rect.buffer(0.01).contains(g): return False
        if zun is not None and g.intersects(zun) and g.intersection(zun).area > 1e-4: return False
        for j, q in enumerate(P):
            if j != i and g.bounds[0] <= q.bounds[2] and q.bounds[0] <= g.bounds[2] and g.bounds[1] <= q.bounds[3] and q.bounds[1] <= g.bounds[3]:
                if g.intersects(q) and g.intersection(q).area > 1e-4: return False
        return True
    order = list(range(n)); random.Random(seed * 77 + 3).shuffle(order)
    for rd in range(rounds):
        for i in order:
            g = P[i]; rg = R[i]
            if u['wedge'] > 0 or t > 0.3:
                piv = g.exterior.interpolate(rg.random() * g.exterior.length)
                d = rg.uniform(-alpha, alpha); h = affinity.rotate(g, d, origin=piv)
                if ok(h, i): g = h
            a = rg.uniform(0, 2 * math.pi); dx, dy = math.cos(a), math.sin(a)
            lo, hi = 0.0, rg.uniform(0.3 * tmax, tmax)
            if ok(affinity.translate(g, dx * hi, dy * hi), i): lo = hi
            else:
                for _ in range(12):
                    m = (lo + hi) / 2
                    if ok(affinity.translate(g, dx * m, dy * m), i): lo = m
                    else: hi = m
            P[i] = affinity.translate(g, dx * lo, dy * lo)
    return P

def contact_stats(P):
    n = len(P); cl = []; gaps = []
    for i in range(n):
        for j in range(i + 1, n):
            d = P[i].distance(P[j])
            if d < 25:
                gaps.append(d)
                if d < 1.0: cl.append(P[i].boundary.intersection(P[j].buffer(1.5)).length)
    return cl, gaps

def gen2(seed, kind, big, pool='train', lvl=None):
    rng = random.Random(seed * 7919 + 17)
    if lvl is None: lvl = (seed * 0.6180339887) % 1.0
    n = rng.randint(14, 24) if big else rng.randint(8, 13)
    W = 10 * rng.randint(24, 36)
    L0 = round(n * 12500 * rng.uniform(0.9, 1.1) / W / 10) * 10
    for att in range(30):
        zs = make_zones2(rng, kind, W, L0, pool)
        R = box(0, 0, W, L0)
        zu = unary_union([z.buffer(0) for z in zs]).intersection(R) if zs else Polygon()
        F = R.difference(zu)
        comps = sorted(Z0.polys(F), key=lambda p: -p.area)
        amin = 0.4 * (F.area / n)
        keep = [c for c in comps if c.area >= max(amin * 2, 2500) and not c.interiors]
        if not keep: continue
        Fk = unary_union(keep); zfrac = 1 - Fk.area / R.area
        if zfrac > 0.3 or (kind != 'pplain' and zfrac < 0.02): continue
        ns = max(6, round(n * Fk.area / R.area)); faces = []; ok = True
        for c in keep:
            r = Z0.partition(rng, c, max(2, round(ns * c.area / Fk.area)), W, L0, amin)
            if r is None: ok = False; break
            faces += r
        if not ok or len(faces) < 6: continue
        zon0 = [z.buffer(0).intersection(R) for z in zs] + [c for c in comps if c not in keep]
        sp = settle(seed, faces, [z for z in zon0 if not z.is_empty], W, L0, lvl)
        sp = [f for f in sp if f.area > 800]
        zon = [Polygon(p.exterior) for z in zs for p in Z0.polys(z.buffer(0).intersection(R))] + [Polygon(c.exterior) for c in comps if c not in keep]
        zun = unary_union(zon) if zon else Polygon()
        if zon and any(f.intersection(zun).area > (30.0 if lvl < 0.05 else 3.0) for f in sp): continue
        if len(sp) < 6: continue
        ov = sum(sp[i].intersection(sp[j]).area for i in range(len(sp)) for j in range(i + 1, len(sp)) if sp[i].intersects(sp[j]))
        if ov > (60.0 if lvl < 0.05 else 5.0): continue
        rot = random.Random(seed * 13 + 1).choices(['any', 'deg15', 'deg5', 'half'], [0.3, 0.35, 0.15, 0.2])[0]
        return dict(seed=seed, kind=kind, big=big, level=round(lvl, 4), gap={k: round(v, 3) for k, v in gap_params(seed, lvl)[0].items()}, width=W, length=L0, n=len(sp), rot=rot, pool=pool,
                    zones=[[list(c) for c in p.exterior.coords[:-1]] for p in zon],
                    pieces=[[list(c) for c in f.exterior.coords[:-1]] for f in sp],
                    zoneFrac=1 - sum(f.area for f in sp) / R.area, zoneOnly=zfrac)
    return None

def zones_for2(seed, kind, W, L, pool='test'):
    rng = random.Random(seed * 104729 + 31)
    for att in range(40):
        zs = make_zones2(rng, kind, W, L, pool)
        R = box(0, 0, W, L)
        zu = unary_union([z.buffer(0) for z in zs]).intersection(R) if zs else Polygon()
        if kind == 'pplain' or 0.02 <= zu.area / R.area <= 0.3:
            return [[list(c) for c in p.exterior.coords[:-1]] for z in zs for p in Z0.polys(z.buffer(0).intersection(R))]
    return []

if __name__ == '__main__':
    if sys.argv[1] == 'zones':
        pool = sys.argv[6] if len(sys.argv) > 6 else 'test'
        print(json.dumps(zones_for2(int(sys.argv[5]), sys.argv[4], float(sys.argv[2]), float(sys.argv[3]), pool))); sys.exit(0)
    tag, s0, cnt = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]); pool = sys.argv[4] if len(sys.argv) > 4 else 'train'
    kinds = ['phole', 'pragged', 'phole', 'pragged', 'pplain']
    out = []; fail = 0
    for i in range(cnt):
        try: r = gen2(s0 + i, kinds[i % 5], 0 if i % 3 == 0 else 1, pool)
        except Exception as e: r = None; print('ERR', s0 + i, repr(e)[:100])
        if r: out.append(r)
        else: fail += 1
    json.dump(out, open(f'data/zgen_{tag}.json', 'w')); print(f'{tag}: {len(out)} пазлів, невдач {fail}')
