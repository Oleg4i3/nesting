#!/bin/bash
# Комбінований тест «1–2–3 вироби» на рулонах без дефектів і з дефектами+нерівними краями; кути 90° і 5°.
cd /home/claude/nest
M=r3a=weights/v2/r3a.json,e3=weights/v2/e3_mix_16_8.json
SETS=suit,fs_jaeger,fs_charlie,fs_wahid,fs_korf_blouse,fs_korf_dress,fs_simon,fs_hugo
for part in 0 1; do
 ( for rot in any deg5; do COPIES=1,2,3 ROT90=1 node rl_eval.js $part 2 mg_$rot $rot plain,both 91 $M 6000 $SETS r3a,e3 > results/mg_${rot}_$part.log 2>&1; done ) &
done
wait
echo OURS_DONE > results/mg_ours_done.txt
for tag in mg_any mg_deg5; do bash ext/z_sparrow_run.sh $tag 10; done
python3 ext/z_sparrow_eval.py > results/mg_sparrow_eval.log 2>&1
echo ALL_DONE > results/mg_all_done.txt
