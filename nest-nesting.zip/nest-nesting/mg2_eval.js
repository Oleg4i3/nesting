// Фінальне порівняння на нових рулонах (зерно 201) з однаковим бюджетом: LNS, гібрид (мережа→LNS), «після»-контроль (BL) та «після» (мережа відновлення).
// node mg2_eval.js <ч> <частин> <тег> <repnet.json> <hybnet.json> <ms> <набори> <копій> <кути> <рулони> [seed=201]
const fs = require('fs'), X = require('./nnx.js'), T = require('./rl_tasks.js'), Pf = require('./portfolio.js'), L = require('./lns2.js');
const part = +process.argv[2], parts = +process.argv[3], tag = process.argv[4], rep = X.MLPX.fromJSON(JSON.parse(fs.readFileSync(process.argv[5], 'utf8'))), hnet = X.MLPX.fromJSON(JSON.parse(fs.readFileSync(process.argv[6], 'utf8'))), ms = +process.argv[7];
const sets = process.argv[8].split(','), copies = process.argv[9].split(',').map(Number), rots = process.argv[10].split(','), kinds = process.argv[11].split(','), SEED = +(process.argv[12] || 201), SPLIT = +(process.env.SPLIT || 0.5);
const out = `results/${tag}_part${part}.jsonl`, done = new Set(fs.existsSync(out) ? fs.readFileSync(out, 'utf8').trim().split('\n').filter(Boolean).map(l => JSON.parse(l).name) : []), fd = fs.openSync(out, 'a'), jobs = [];
for (const rot of rots) for (const set of sets) for (const kind of kinds) for (const cp of copies) jobs.push({ set, kind, seed: SEED, n: set === 'suit' ? 13 : 99, rot, copies: cp });
jobs.forEach((j, ji) => {
  if (ji % parts !== part) return;
  const t = T.build(j); if (done.has(t.name + '|' + j.rot)) return;
  const o = { width: t.W, maxLength: 4000, seed: 7, blocked: t.blocked }, ev = pl => { const r = T.evaluate(t, pl); return r ? 100 * r.dens : null; };
  const row = { name: t.name + '|' + j.rot, set: j.set, kind: j.kind, copies: j.copies, rot: j.rot, res: {} };
  const base = { recreate: 'BL', kMin: 6, kMax: 14, T0: 0.6 };
  row.res.lns = ev(L.solveLNS(t.pcs, t.rules, Object.assign({}, o, base, { budgetMs: ms })).placements);
  const t0 = Date.now(), bm = Pf.solvePortfolio(t.pcs, t.rules, hnet, { width: t.W, maxLength: 4000, blocked: t.blocked, maxMs: 15000 }), tb = Date.now() - t0;
  const init = new Array(t.pcs.length).fill(null); bm.seq.forEach(q => { init[q.pi] = { vi: q.vi, A: q.A, cy: q.cy }; });
  row.res.hyb = ev(L.solveLNS(t.pcs, t.rules, Object.assign({}, o, { budgetMs: Math.max(1000, ms - tb), recreate: 'BL', kMin: 4, kMax: 10, T0: 0.25, init })).placements);
  const first = L.solveLNS(t.pcs, t.rules, Object.assign({}, o, base, { budgetMs: Math.round((1 - SPLIT) * ms) })), pol = { init: first.layout, budgetMs: ms - Math.round((1 - SPLIT) * ms), kMin: 3, kMax: 8, T0: 0.05, T1: 0.01 };
  row.res.afterBL = ev(L.solveLNS(t.pcs, t.rules, Object.assign({}, o, pol, { recreate: 'BL' })).placements);
  row.res.afterM = ev(L.solveLNS(t.pcs, t.rules, Object.assign({}, o, pol, { recreate: 'MIX', mixP: 0.5, net: rep, temp: 0.3 })).placements);
  fs.writeSync(fd, JSON.stringify(row) + '\n'); console.log(row.name, Object.entries(row.res).map(([k, v]) => k + ' ' + (v ? v.toFixed(1) : '—')).join(' | '));
});
