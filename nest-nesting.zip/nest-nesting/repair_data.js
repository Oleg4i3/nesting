// Дані для оператора відновлення в LNS: з доброї розкладки (LNS) вилучаємо кластер із k сусідніх деталей, відновлюємо їх в порядку експерта.
// Зразок = крок вставки в розкладку з «діркою»; позитив — позиція деталі в добрій розкладці, негативи — інші BL-кандидати.
// node repair_data.js <ч> <частин> <тег> <nTrainmix> <nZgen> [msLNS=6000] [R=12]
const fs = require('fs'), N = require('./raster.js'), Fe = require('./features.js'), P = require('./puzzle.js'), L = require('./lns2.js'), Gd = require('./guided.js'), T = require('./rl_tasks.js'), ZP = require('./zpuzzle.js'), Z = require('./zones.js');
const part = +process.argv[2] || 0, parts = +process.argv[3] || 1, tag = process.argv[4], NA = +process.argv[5] || 60, NB = +process.argv[6] || 60, MS = +process.argv[7] || 6000, R = +process.argv[8] || 12;
const NF = Fe.NF, rng = P.mulberry32(4242 + part), NEG = 150;
const jobs = [], rots = ['any', 'deg5', 'deg15'];
for (let i = 0; i < NA; i++) jobs.push({ src: 'tm', spec: { set: 'fs_trainmix', kind: i % 2 ? 'both' : 'plain', seed: 1000 + i, n: [12, 18, 29][i % 3], rot: rots[i % 3], copies: 1 + (i % 4 === 3 ? 1 : 0) } });
const zr = ZP.load('p3a'); for (let i = 0; i < NB; i++) jobs.push({ src: 'zg', rec: zr[(i * 7) % zr.length] });
const meta = [], chunks = []; let offset = 0, nT = 0, nS = 0; const t0 = Date.now();
const flush = () => { fs.writeFileSync(`data/expert_${tag}_p${part}.bin`, Buffer.concat(chunks)); fs.writeFileSync(`data/expert_${tag}_p${part}.json`, JSON.stringify({ NF, meta, n: nT })); };
jobs.forEach((j, ji) => {
  if (ji % parts !== part) return;
  let pcs, W, rules, blocked, kind;
  try {
    if (j.src === 'tm') { const t = T.build(j.spec); pcs = t.pcs; W = t.W; rules = t.rules; blocked = t.blocked; kind = 'tm_' + j.spec.kind + '_' + j.spec.rot; }
    else { const pz = ZP.build(j.rec); pcs = pz.pieces; W = pz.width; rules = pz.rules; blocked = pz.blocked; kind = 'zg_' + j.rec.kind; }
  } catch (e) { return; }
  let lay; try { lay = L.solveLNS(pcs, rules, { width: W, maxLength: 6000, seed: 7, blocked, budgetMs: MS, recreate: 'BL', kMin: 6, kMax: 14, T0: 0.6 }).layout; } catch (e) { return; }
  const G = new Gd.Guided(pcs, rules, W, 6000, false, blocked), vars = G.vars, n = pcs.length, split = ji % 10 === 0 ? 'val' : 'train';
  const ctr = i => { const v = vars[i][lay[i].vi]; return [lay[i].A + v.w / 2, lay[i].cy + v.h / 2]; };
  for (let r = 0; r < R; r++) {
    const k = Math.min(n - 1, 4 + Math.floor(rng() * 7)), sp = Math.floor(rng() * n), c0 = ctr(sp);
    const removed = [...Array(n).keys()].sort((a, b) => { const A = ctr(a), B = ctr(b); return Math.hypot(A[0] - c0[0], A[1] - c0[1]) - Math.hypot(B[0] - c0[0], B[1] - c0[1]); }).slice(0, k);
    const rs = new Set(removed), b2 = G.tpl.clone();
    for (let i = 0; i < n; i++) if (!rs.has(i)) b2.place(vars[i][lay[i].vi], lay[i].A, lay[i].cy);
    const order = removed.slice().sort((a, b) => lay[a].cy - lay[b].cy || lay[a].A - lay[b].A), st = G.start(); st.board = b2; st.rem = removed.slice();
    for (const pi of order) {
      const c = G.actions(st), e = lay[pi]; let ix = c.findIndex(x => x.pi === pi && x.vi === e.vi && x.A === e.A && x.cy === e.cy);
      if (ix < 0) { if (!b2.fits(vars[pi][e.vi], e.A, e.cy)) break; c.push({ pi, vi: e.vi, A: e.A, cy: e.cy, ct: b2.contact(vars[pi][e.vi], e.A, e.cy), cheap: 0 }); ix = c.length - 1; }
      const pos = c[ix]; c.splice(ix, 1);
      for (let i = c.length - 1; i > 0; i--) { const q = Math.floor(rng() * (i + 1)); [c[i], c[q]] = [c[q], c[i]]; }
      const sel = [pos, ...c.slice(0, NEG)], F = new Float32Array(sel.length * NF); G.features(st, sel, F);
      meta.push({ split, kind, seed: ji, count: sel.length, pos: [0], offset }); chunks.push(Buffer.from(F.buffer)); offset += sel.length * NF; nS++;
      G.place(st, pos);
    }
  }
  nT++; if (nT % 25 === 0) flush(); if (nT % 10 === 0) console.log(`[${part}] ${nT} задач, зразків ${nS}, ${((Date.now() - t0) / 1000).toFixed(0)}с`);
});
flush();
console.log(`[${part}] готово ${nT} задач, ${nS} зразків`);
