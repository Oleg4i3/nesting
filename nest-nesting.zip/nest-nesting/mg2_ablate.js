// Абляція даних оператора відновлення: спільний перший етап, другий етап — контроль BL / мережа на всіх даних / мережа без даних з пазлів.
// node mg2_ablate.js <ч> <частин> <тег> <netAll.json> <netTm.json> <ms> <набори> <копій> <кути> <рулони> [seed=201]
const fs = require('fs'), X = require('./nnx.js'), T = require('./rl_tasks.js'), L = require('./lns2.js');
const part = +process.argv[2], parts = +process.argv[3], tag = process.argv[4], netAll = X.MLPX.fromJSON(JSON.parse(fs.readFileSync(process.argv[5], 'utf8'))), netTm = X.MLPX.fromJSON(JSON.parse(fs.readFileSync(process.argv[6], 'utf8'))), ms = +process.argv[7];
const sets = process.argv[8].split(','), copies = process.argv[9].split(',').map(Number), rots = process.argv[10].split(','), kinds = process.argv[11].split(','), SEED = +(process.argv[12] || 201);
const out = `results/${tag}_part${part}.jsonl`, done = new Set(fs.existsSync(out) ? fs.readFileSync(out, 'utf8').trim().split('\n').filter(Boolean).map(l => JSON.parse(l).name) : []), fd = fs.openSync(out, 'a'), jobs = [];
for (const rot of rots) for (const set of sets) for (const kind of kinds) for (const cp of copies) jobs.push({ set, kind, seed: SEED, n: set === 'suit' ? 13 : 99, rot, copies: cp });
jobs.forEach((j, ji) => {
  if (ji % parts !== part) return;
  const t = T.build(j); if (done.has(t.name + '|' + j.rot)) return;
  const o = { width: t.W, maxLength: 4000, seed: 7, blocked: t.blocked }, ev = pl => { const r = T.evaluate(t, pl); return r ? 100 * r.dens : null; };
  const row = { name: t.name + '|' + j.rot, set: j.set, kind: j.kind, copies: j.copies, rot: j.rot, res: {} };
  const base = { recreate: 'BL', kMin: 6, kMax: 14, T0: 0.6 };
  const first = L.solveLNS(t.pcs, t.rules, Object.assign({}, o, base, { budgetMs: Math.round(ms / 2) })), pol = { init: first.layout, budgetMs: ms - Math.round(ms / 2), kMin: 3, kMax: 8, T0: 0.05, T1: 0.01 };
  row.res.ctrl = ev(L.solveLNS(t.pcs, t.rules, Object.assign({}, o, pol, { recreate: 'BL' })).placements);
  row.res.all = ev(L.solveLNS(t.pcs, t.rules, Object.assign({}, o, pol, { recreate: 'MIX', mixP: 0.5, net: netAll, temp: 0.3 })).placements);
  row.res.tm = ev(L.solveLNS(t.pcs, t.rules, Object.assign({}, o, pol, { recreate: 'MIX', mixP: 0.5, net: netTm, temp: 0.3 })).placements);
  fs.writeSync(fd, JSON.stringify(row) + '\n'); console.log(row.name, Object.entries(row.res).map(([k, v]) => k + ' ' + (v ? v.toFixed(1) : '—')).join(' | '));
});
