// Навчання з curriculum за рівнем зазорів (0 — майже повний дотик … 1 — великі клиноподібні зазори) і детальним логом.
// node train_v3.js <ім'я> <теги_train> <тег_val> [епох=60] [seed=1] [hidden=16,8] [CUR=1|0]
// CUR=1: cap(ep) зростає від 0.2 до 1 за перші 60% епох; навчання лише на зразках з lvl<=cap; далі — усі рівні. CUR=0: усі рівні одразу.
const fs=require('fs'),X=require('./nnx.js'),NN=require('./nn.js'),Fe=require('./features.js');
const name=process.argv[2],tags=process.argv[3].split(','),valTag=process.argv[4],EP=+process.argv[5]||60,seed=+process.argv[6]||1,hidden=(process.argv[7]||'16,8').split(',').map(Number),CUR=(process.argv[8]||'1')==='1';
const NF=Fe.NF,NB=4;
function load(tag,split){const out=[];
  for(const f of fs.readdirSync('data').filter(f=>f.startsWith(`expert_${tag}_p`)&&f.endsWith('.json'))){
    const m=JSON.parse(fs.readFileSync('data/'+f,'utf8')),buf=fs.readFileSync('data/'+f.replace('.json','.bin')),all=new Float32Array(buf.buffer.slice(buf.byteOffset,buf.byteOffset+buf.byteLength));
    for(const s of m.meta){if(s.split!==split)continue;let bad=false;for(let i=s.offset;i<s.offset+s.count*NF;i++)if(!Number.isFinite(all[i])){bad=true;break}if(bad)continue;
      const pos=new Uint8Array(s.count);s.pos.forEach(i=>{pos[i]=1});out.push({F:all.subarray(s.offset,s.offset+s.count*NF),count:s.count,pos,lvl:s.lvl==null?0.5:s.lvl})}}
  return out}
const train=tags.flatMap(t=>load(t,'train')),val=load(valTag,'val');
const bk=l=>Math.min(NB-1,Math.floor(l*NB));
console.log(`${name}: train ${train.length}, val ${val.length}, curriculum ${CUR?'ТАК':'НІ'}, hidden ${hidden}, act ${process.env.ACT||'tanh'}, skip ${process.env.SKIP==='1'?1:0}`);
const net=new X.MLPX(NF,hidden,process.env.ACT||'tanh',process.env.SKIP==='1').init(seed),rng=NN.mulberry32(77*seed+3),opt=new NN.Adam(net.n,3e-3),g=new Float64Array(net.n);
const ev=set=>{const r={n:0,l:0,h:0,b:Array.from({length:NB},()=>({n:0,l:0,h:0}))};for(const s of set){const e=net.evalSample(s),b=r.b[bk(s.lvl)];r.n++;r.l+=e.loss;r.h+=e.hit;b.n++;b.l+=e.loss;b.h+=e.hit}r.loss=r.l/r.n;r.hit=r.h/r.n;return r};
const CUREP=Math.round(0.6*EP);let best={loss:1e9,p:null,ep:0};if(process.env.INIT){net.p.set(X.MLPX.fromJSON(JSON.parse(fs.readFileSync(process.env.INIT,'utf8'))).p);console.log('старт з ваг',process.env.INIT)}
const t0=Date.now();
for(let ep=1;ep<=EP;ep++){
  const cap=CUR?Math.min(1,0.2+0.8*(ep-1)/Math.max(1,CUREP-1)):1;
  const idx=[];train.forEach((s,i)=>{if(s.lvl<=cap+1e-9)idx.push(i)});
  for(let i=idx.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[idx[i],idx[j]]=[idx[j],idx[i]]}
  let tl=0;
  for(let b=0;b<idx.length;b+=16){g.fill(0);const n=Math.min(16,idx.length-b);for(let k=0;k<n;k++){const e=net.lossGrad(train[idx[b+k]],g);if(typeof e==='number')tl+=e}for(let i=0;i<g.length;i++)g[i]/=n;opt.step(net.p,g,1e-4)}
  if(ep%2===0||ep===EP||ep===1){const v=ev(val);
    console.log(`ep ${String(ep).padStart(3)} cap ${cap.toFixed(2)} навч.зразків ${idx.length} | val loss ${v.loss.toFixed(4)} top1 ${(100*v.hit).toFixed(1)}% | за рівнями loss/top1: ${v.b.map(b=>b.n?`${(b.l/b.n).toFixed(3)}/${(100*b.h/b.n).toFixed(0)}%`:'—').join('  ')} | ${((Date.now()-t0)/1000).toFixed(0)}с`);
    if(cap>=1&&v.loss<best.loss){best={loss:v.loss,p:Float64Array.from(net.p),ep,hit:v.hit};const sv=net.p.slice?Float64Array.from(net.p):null;const keep=Float64Array.from(net.p);fs.mkdirSync('weights/v2',{recursive:true});net.p.set(best.p);fs.writeFileSync(`weights/v2/${name}.json`,JSON.stringify(net.toJSON()));net.p.set(keep)}}}
net.p.set(best.p);
fs.mkdirSync('weights/v2',{recursive:true});fs.writeFileSync(`weights/v2/${name}.json`,JSON.stringify(net.toJSON()));
console.log(`${name}: параметрів ${net.n}, найкраща епоха ${best.ep}, val loss ${best.loss.toFixed(4)}, top1 ${(best.hit*100).toFixed(1)}%`);
