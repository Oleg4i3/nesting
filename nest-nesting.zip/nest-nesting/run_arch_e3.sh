#!/bin/bash
# підбір архітектури на e3 (змішане навчання); 2 потоки
cd /home/claude/nest
run(){ name=$1; hid=$2; act=$3; skip=$4; ACT=$act SKIP=$skip node train_v3.js $name e3 e3 60 1 $hid 0 > logs/$name.log 2>&1; }
export -f run
printf '%s\n' "e3a_32_16_8 32,16,8 tanh 0" "e3a_32_16 32,16 tanh 0" "e3a_16_8_relu 16,8 relu 0" "e3a_16_8_silu 16,8 silu 0" "e3a_16_8_gelu 16,8 gelu 0" "e3a_16_8_skip 16,8 tanh 1" "e3a_8_4 8,4 tanh 0" | xargs -P2 -L1 bash -c 'run $0 $1 $2 $3'
