#!/bin/bash
# chain A and chain B run in parallel
cd /home/claude/nest
( for cfg in "16,8" "32,16,8"; do n=zA_${cfg//,/_}; node train_v2.js $n zd1 40 1 $cfg zd1 > results/tr_$n.log 2>&1; done ) &
( for cfg in "32,16" "64,32"; do n=zA_${cfg//,/_}; node train_v2.js $n zd1 40 1 $cfg zd1 > results/tr_$n.log 2>&1; done ) &
wait
