// Готує сцени для браузерного симулятора. node export_sim.js <ч> <частин> [ms=15000]
const fs=require('fs'),P=require('./puzzle.js'),N=require('./raster.js'),X=require('./nnx.js'),Bm=require('./beam.js'),B=require('./baselines.js'),L=require('./lns2.js'),C=require('./common.js'),Z=require('./zones.js');
const part=+process.argv[2]||0,parts=+process.argv[3]||1,ms=+process.argv[4]||15000;
const net=X.MLPX.fromJSON(JSON.parse(fs.readFileSync(process.env.NETF||'weights/v2/r3a.json','utf8')));const ONLY=process.env.ONLY?process.env.ONLY.split(','):null;
const suit=N.loadLayout(fs.readFileSync('/mnt/user-data/uploads/suit-manual.json','utf8')).map(p=>{const b=N.vertexBBox(p);return N.translatePoly(p,-Math.floor(b.minX/10)*10,-Math.floor(b.minY/10)*10)});
const suitScene=(n,rn,rules)=>{const pcs=[];for(let k=0;k<n;k++)for(const p of suit)pcs.push(p);return{pieces:pcs,width:290,rules,blocked:[],solution:null}};
const SC=[
 ['puzzle','Пазл (щільний, кути кратні 15°)',()=>C.makePuzzle(C.randomSpecAng(700002,1,0))],
 ['puzzle_big','Пазл великий (22 деталі)',()=>C.makePuzzle(C.randomSpecAng(701002,1,1))],
 ['trim','Пазл з обрізаними дугами (прямі зрізи + відходи)',()=>C.makePuzzle(C.randomSpecAng(702002,2,0))],
 ['scoop','Пазл з виїмками (прямі → увігнуті дуги)',()=>C.makeHole(800012,'scoop',1)],
 ['hole','Пазл з діркою (заборонена зона)',()=>C.makeHole(800025,'hole',1)],
 ['remnant','Пазл на обрізку (непрямокутний рулон)',()=>C.makeHole(800014,'remnant',1)],
 ['both','Обрізок + діра',()=>C.makeHole(800018,'both',1)],
 ['suit1','Костюм кравця, 1 шт. (повороти 180°)',()=>suitScene(1,'half',{rotations:'half',mirror:false})],
 ['suit2','Костюм кравця, 2 шт. на рулоні',()=>suitScene(2,'half',{rotations:'half',mirror:false})],
];
const rnd=v=>Math.round(v*10)/10,ser=p=>({v:p.vertices.map(a=>[rnd(a.x),rnd(a.y)]),c:(p.bezierControls||p.vertices.map(()=>null)).map(c=>c?[rnd(c.x),rnd(c.y)]:null)});
const out=[];
SC.forEach(([id,title,mk],si)=>{if(si%parts!==part||(ONLY&&!ONLY.includes(id)))return;const pz=mk();if(!pz)return;
  const pcs=pz.pieces,W=pz.width,rules=pz.rules,bl=pz.blocked||[],budget=id==='suit2'?2*ms:ms,maxLen=6000;
  const sc={id,title,width:W,n:pcs.length,rules:rules.rotations,blocked:bl.map(ser),methods:[]};
  const add=(key,name,placements,t,extra)=>{if(!placements||placements.filter(Boolean).length!==pcs.length){sc.methods.push({key,name,failed:true});return}
    const e=Z.evaluateWithZones(pcs,placements,bl,W);if(!e.valid){sc.methods.push({key,name,failed:true});return}
    const polys=P.placementsToPolys(pcs,placements);sc.methods.push(Object.assign({key,name,eff:e.efficiency,len:e.len,ms:t,polys:polys.map(ser)},extra||{}))};
  if(pz.solution){const pl=pz.solution.map(s=>({rot:s.rot,mirror:s.mirror,px:s.px,py:s.py}));const polys=P.placementsToPolys(pcs,pl);
    const ev=N.evaluateLayout(polys,{width:W,height:6000,rollWidth:W});sc.methods.push({key:'planted',name:'Еталон (відомий розв\'язок)',eff:pz.meta.plantedEfficiency,len:pz.meta.plantedLength,ms:0,polys:polys.map(ser)})}
  const o={width:W,maxLength:maxLen,seed:7,blocked:bl};
  let t0=Date.now();const bm=Bm.solveBeam(pcs,rules,net,{width:W,maxLength:maxLen,beam:16,rank:'logp',K:1000,noSlit:true,blocked:bl});const tb=Date.now()-t0;add('net','Мережа (beam 16)',bm.placements,tb);
  t0=Date.now();add('bl','BL-відпал',B.solveBLSA(pcs,rules,{...o,budgetMs:budget}).placements,Date.now()-t0);
  t0=Date.now();add('lns','LNS + BL',L.solveLNS(pcs,rules,{...o,budgetMs:budget,recreate:'BL',kMin:6,kMax:14,T0:0.6}).placements,Date.now()-t0);
  t0=Date.now();try{const init=new Array(pcs.length).fill(null);bm.seq.forEach(s=>{init[s.pi]={vi:s.vi,A:s.A,cy:s.cy}});
    add('hyb','Гібрид: мережа → LNS',L.solveLNS(pcs,rules,{...o,budgetMs:Math.max(1000,budget-tb),recreate:'BL',kMin:4,kMax:10,T0:0.25,init}).placements,Date.now()-t0+tb)}catch(e){sc.methods.push({key:'hyb',name:'Гібрид: мережа → LNS',failed:true})}
  out.push(sc);console.log(`[${part}] ${id}: `+sc.methods.map(m=>m.name.slice(0,8)+' '+(m.failed?'—':(m.eff*100).toFixed(1))).join(' | '))});
fs.writeFileSync(`results/sim${process.env.TAG||''}_part${part}.json`,JSON.stringify(out));
