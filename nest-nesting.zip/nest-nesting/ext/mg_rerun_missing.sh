#!/bin/bash
# Перезапуск Sparrow для задач mg_*, яких бракує в ext/zscen/out/s<зерно>/ (після виправлення зон)
cd /home/claude/ext/sparrow_def
run(){ id=$1; sd=$2; mkdir -p /home/claude/nest/ext/zscen/out/s$sd; ./target/release/sparrow -i /home/claude/nest/ext/zscen/$id.json -t 10 --workers 1 -s $sd > /home/claude/nest/ext/zscen/out/s$sd/$id.log 2>&1 && cp output/final_$id.json /home/claude/nest/ext/zscen/out/s$sd/final_$id.json; }
export -f run
for sd in 1 2 3; do
  for f in /home/claude/nest/ext/zscen/mg_*.json; do id=$(basename $f .json); [ -f /home/claude/nest/ext/zscen/out/s$sd/final_$id.json ] || echo "$id $sd"; done
done | xargs -P2 -L1 bash -c 'run $0 $1'
python3 /home/claude/nest/ext/z_sparrow_eval.py
echo RERUN_DONE > /home/claude/nest/results/mg_rerun_done.txt
