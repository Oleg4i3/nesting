#!/bin/bash
# 10x бюджет (100 с), deg5 × both × copies=2 × 8 наборів, seed 201. Усі завдання в одному пулі з 2 слотів (без перевантаження ядер).
cd /home/claude/nest
SETS="suit fs_jaeger fs_charlie fs_wahid fs_korf_blouse fs_korf_dress fs_simon fs_hugo"
{
for s in $SETS; do
  echo "ours $s"
  for sd in 1 2 3; do echo "sp $s $sd"; done
done
} | xargs -P2 -L1 bash -c '
if [ "$0" = ours ]; then cd /home/claude/nest && node mg4_long.js 0 1 long_$1 weights/v2/rep2tm_16_8.json weights/v2/rep2tm_16_8.json 100000 $1 2 deg5 both 201 > results/long_$1.log 2>&1
else id=mg_deg5_$1_both_201_x2; mkdir -p ext/zscen/out100/s$2; cd /home/claude/ext/sparrow_def && ./target/release/sparrow -i /home/claude/nest/ext/zscen/$id.json -t 100 --workers 1 -s $2 > /home/claude/nest/ext/zscen/out100/s$2/$id.log 2>&1 && cp output/final_$id.json /home/claude/nest/ext/zscen/out100/s$2/final_$id.json; fi'
python3 ext/z_sparrow_eval100.py > results/long_sparrow_eval.log 2>&1
echo DONE > results/long_done.txt
