// Перевірка точного перетину розкладок на реальних наборах: node ext/overlap_check.js <id> <ms> -> ext/ov_<id>.json (полігони для shapely)
const fs=require('fs'),path=require('path'),R=require('../ext_real.js'),N=require('../raster.js'),L=require('../lns2.js'),P=require('../puzzle.js'),Z=require('../zones.js');
const id=process.argv[2],ms=+process.argv[3]||8000,{pcs,W,rules}=R.load(id);for(const p of pcs)p.constraints={rotations:p._rot,mirror:false};
const pl=L.solveLNS(pcs,rules,{width:W,maxLength:20000,seed:7,blocked:[],budgetMs:ms,recreate:'BL',kMin:6,kMax:14,T0:0.6}).placements;
const polys=P.placementsToPolys(pcs,pl).map(p=>Array.from(N.flatten(p)));
const e=Z.evaluateWithZones(pcs,pl,[],W);fs.writeFileSync(path.join(__dirname,`ov_${id}.json`),JSON.stringify({W,len:e.len,polys}));console.log(id,e.len,polys.length);
