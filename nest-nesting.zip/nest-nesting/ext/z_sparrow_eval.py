# Перевірка й щільність розкладок Sparrow на пазлах із зонами (точна геометрія) → ext/zscen/dens.json (відсотки)
import json,glob,math,collections
from shapely.geometry import Polygon
from shapely.ops import unary_union
D0='/home/claude/nest/ext/zscen/'
meta=json.load(open(D0+'meta.json')); res=collections.defaultdict(list); bad=[]
for f in sorted(glob.glob(D0+'out/s*/final_*.json')):
    id=f.split('final_')[1][:-5]
    if id not in meta: continue
    j=json.load(open(f)); inst=json.load(open(D0+id+'.json'))
    P=[]
    for pi in j['solution']['layout']['placed_items']:
        pts=j['items'][pi['item_id']]['shape']['data'][:-1]; th=math.radians(pi['transformation']['rotation']); tx,ty=pi['transformation']['translation']; c,s=math.cos(th),math.sin(th)
        P.append(Polygon([(c*x-s*y+tx,s*x+c*y+ty) for x,y in pts]).buffer(0))
    Dz=[Polygon(d).buffer(0) for d in inst['defects']]
    area=sum(p.area for p in P); ov=area-unary_union(P).area
    odef=sum(p.intersection(d).area for p in P for d in Dz)
    L=j['solution']['strip_width']; W=inst['strip_height']
    ok=len(P)==meta[id]['n'] and ov/area<2e-3 and odef/area<2e-3
    if not ok: bad.append((f,len(P),ov/area,odef/area))
    res[id].append(100*area/(W*L) if ok else None)
json.dump(res,open(D0+'dens.json','w')); print(len(res),'tasks; bad:',len(bad))
