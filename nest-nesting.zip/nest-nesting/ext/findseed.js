const N=require('../raster.js'),C=require('../common.js');
const inter=(a,b,c,d)=>{const o=(p,q,r)=>(q[0]-p[0])*(r[1]-p[1])-(q[1]-p[1])*(r[0]-p[0]);return o(a,b,c)*o(a,b,d)<0&&o(c,d,a)*o(c,d,b)<0};
const simple=pts=>{const n=pts.length;for(let i=0;i<n;i++)for(let j=i+2;j<n;j++){if(i===0&&j===n-1)continue;if(inter(pts[i],pts[(i+1)%n],pts[j],pts[(j+1)%n]))return false}return true};
const ok=[];for(let s=701006;ok.length<3&&s<701100;s+=2){const pz=C.makePuzzle(C.randomSpecAng(s,1,1));let good=true;for(const p of pz.pieces){const f=N.flatten(p),pts=[];for(let k=0;k<f.length;k+=2)pts.push([f[k],f[k+1]]);if(!simple(pts)){good=false;break}}if(good)ok.push(s)}
console.log(ok);
