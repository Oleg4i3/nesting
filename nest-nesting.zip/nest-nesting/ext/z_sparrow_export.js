// Експорт пазлів із зонами (zgen-тег) у формат Sparrow із дефектами. node ext/z_sparrow_export.js <тег> <каталог>
// Рулон Sparrow: довжина вздовж x, висота = ширина нашого рулона; (x,y) → (y, W − x) — поворот на 90°, дозволені кути не змінюються.
const fs = require('fs'), path = require('path'), N = require('../raster.js'), ZP = require('../zpuzzle.js');
const tag = process.argv[2], dir = path.resolve(process.argv[3] || 'ext/zscen'); fs.mkdirSync(dir, { recursive: true });
const ccw = pts => { let s = 0; for (let i = 0; i < pts.length; i++) { const q = pts[(i + 1) % pts.length]; s += pts[i][0] * q[1] - q[0] * pts[i][1]; } return s < 0 ? pts.slice().reverse() : pts; };
const pts = (p, W) => { const f = N.flatten(p), o = []; for (let k = 0; k < f.length; k += 2) o.push([f[k + 1], W - f[k]]); return ccw(o); };
const meta = {};
ZP.load(tag).forEach(rec => {
  let pz; try { pz = ZP.build(rec); } catch (e) { return; }
  const id = `${tag}_${rec.kind}_${rec.seed}`, W = pz.width;
  const ang = a => { const r = pz.rules.rotations; return (Array.isArray(r) ? r.map(x => x * 90) : N.angleSet ? N.angleSet(r).map(x => x * 90) : null); };
  const rot = N.allowedFor(pz.pieces[0], pz.rules).rotations.map(x => +(x * 90).toFixed(6));
  const items = pz.pieces.map((p, i) => { const q = pts(p, W); q.push(q[0].slice()); return { id: i, demand: 1, orientation: { rotation: { mode: 'discrete', angles: rot } }, shape: { type: 'simple_polygon', data: q } }; });
  const defects = pz.blocked.map(z => pts(z, W));
  fs.writeFileSync(path.join(dir, id + '.json'), JSON.stringify({ name: id, items, strip_height: W, defects }));
  meta[id] = { kind: rec.kind, seed: rec.seed, n: pz.pieces.length, W, area: pz.pieces.reduce((s, p) => s + N.polygonArea(p), 0), nz: defects.length, plantedLen: pz.length, rot: pz.rules.rotations };
});
fs.writeFileSync(path.join(dir, 'meta.json'), JSON.stringify(meta)); console.log(Object.keys(meta).length, 'задач у', dir);
