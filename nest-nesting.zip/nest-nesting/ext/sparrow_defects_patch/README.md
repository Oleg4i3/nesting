# Патч Sparrow v0.3.0 / jagua-rs 1.1.0: нерухомі зони заборони (дефекти, обрізані кути, нерівні краї)
Застосування: розпакувати jagua-rs 1.1.0 (crates.io) у `jagua_def`, застосувати `jagua-rs.patch`; у клоні Sparrow застосувати `sparrow.patch` (додає `[patch.crates-io] jagua-rs = { path = "../jagua_def" }`), `cargo build --release`.
Вхідний JSON Sparrow отримує необов'язкове поле `defects: [[[x,y],...], ...]` у координатах смуги (x — довжина, y — висота). Зони передаються в контейнер як зони якості 0; перетин деталі із зоною рахується як перетин двох деталей з вагою межі смуги.
Задачі Рис. 2: `ext/scen_sparrow_export.js` → `ext/scen/*.json`; запуск `ext/scen_sparrow_run.sh`; перевірка точною геометрією `ext/scen_sparrow_eval.py`.
