// Експорт задач «кілька виробів» (mg) у формат Sparrow: ext/zscen/mg_<кути>_<набір>_<рулон>_<копій>.json. ROT90=1 node ext/mg_sparrow_export.js
const fs = require('fs'), path = require('path'), N = require('../raster.js'), T = require('../rl_tasks.js');
const dir = path.join(__dirname, 'zscen'); fs.mkdirSync(dir, { recursive: true });
const ccw = pts => { let s = 0; for (let i = 0; i < pts.length; i++) { const q = pts[(i + 1) % pts.length]; s += pts[i][0] * q[1] - q[0] * pts[i][1]; } return s < 0 ? pts.slice().reverse() : pts; };
const pts = (p, W) => { const f = N.flatten(p), o = []; for (let k = 0; k < f.length; k += 2) o.push([f[k + 1], W - f[k]]); return ccw(o); };
const metaF = path.join(dir, 'meta.json'), meta = fs.existsSync(metaF) ? JSON.parse(fs.readFileSync(metaF)) : {};
const SETS = (process.env.MGSETS || 'suit,fs_jaeger,fs_charlie,fs_wahid,fs_korf_blouse,fs_korf_dress,fs_simon,fs_hugo').split(','), KINDS = (process.env.MGKINDS || 'plain,both').split(','), COPIES = (process.env.COPIES || '1,2,3').split(',').map(Number), ROTS = (process.env.MGROTS || 'any,deg5').split(','), SEED = +(process.env.MGSEED || 91);
let cnt = 0;
for (const rot of ROTS) for (const set of SETS) for (const kind of KINDS) for (const cp of COPIES) {
  const spec = { set, kind, seed: SEED, n: set === 'suit' ? 13 : 99, rot, copies: cp }, t = T.build(spec), id = `mg_${rot}_${set}_${kind}_${SEED}_x${cp}`;
  const ang = N.allowedFor(t.pcs[0], t.rules).rotations.map(a => +(a * 90).toFixed(6));
  const items = t.pcs.map((p, i) => { const q = pts(p, t.W); q.push(q[0].slice()); return { id: i, demand: 1, orientation: { rotation: { mode: 'discrete', angles: ang } }, shape: { type: 'simple_polygon', data: q } }; });
  fs.writeFileSync(path.join(dir, id + '.json'), JSON.stringify({ name: id, items, strip_height: t.W, defects: t.blocked.map(z => pts(z, t.W)) }));
  meta[id] = { set, kind, seed: SEED, n: t.pcs.length, W: t.W, area: t.area, nz: t.blocked.length, copies: cp, rot }; cnt++;
}
fs.writeFileSync(metaF, JSON.stringify(meta)); console.log(cnt, 'задач');
