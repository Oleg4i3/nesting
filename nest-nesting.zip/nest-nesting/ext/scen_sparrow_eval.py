# Перевірка й щільність розкладок Sparrow на задачах Рис. 6 (точна геометрія): ext/scen/out/s*/final_*.json → ext/scen/dens.json
import json,glob,math,collections
from shapely.geometry import Polygon
from shapely.ops import unary_union
meta=json.load(open('/home/claude/nest/ext/scen/meta.json')); res=collections.defaultdict(list); bad=[]
for f in sorted(glob.glob('/home/claude/nest/ext/scen/out/s*/final_*.json')):
    id=f.split('final_')[1][:-5]; j=json.load(open(f)); inst=json.load(open(f'/home/claude/nest/ext/scen/{id}.json'))
    P=[]
    for pi in j['solution']['layout']['placed_items']:
        pts=j['items'][pi['item_id']]['shape']['data'][:-1]; th=math.radians(pi['transformation']['rotation']); tx,ty=pi['transformation']['translation']; c,s=math.cos(th),math.sin(th)
        P.append(Polygon([(c*x-s*y+tx,s*x+c*y+ty) for x,y in pts]).buffer(0))
    D=[Polygon(d).buffer(0) for d in inst['defects']]
    area=sum(p.area for p in P); ov=area-unary_union(P).area
    odef=sum(p.intersection(d).area for p in P for d in D)
    L=j['solution']['strip_width']; W=inst['strip_height']
    ok=len(P)==meta[id]['n'] and ov/area<2e-3 and odef/area<2e-3
    if not ok: bad.append((f,len(P),ov/area,odef/area))
    res[id].append(100*area/(W*L) if ok else None)
json.dump(res,open('/home/claude/nest/ext/scen/dens.json','w')); print(len(res),'tasks; bad:',bad)
for k,v in list(res.items())[:8]: print(k,[None if x is None else round(x,1) for x in v])
