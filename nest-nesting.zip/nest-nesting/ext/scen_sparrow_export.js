// Експорт 32 задач Рис. 6 у формат Sparrow із дефектами (патч: поле defects). node ext/scen_sparrow_export.js
// Рулон Sparrow: довжина вздовж x, висота = ширина нашого рулона. Перетворення (x,y) → (y, W − x) — поворот на 90°, тож дозволені кути деталей не змінюються.
const fs=require('fs'),path=require('path'),N=require('../raster.js'),T=require('../rl_tasks.js');
const rows=fs.readdirSync(path.join(__dirname,'../results')).filter(f=>/^evalA_part\d+\.jsonl$/.test(f)).flatMap(f=>fs.readFileSync(path.join(__dirname,'../results',f),'utf8').split('\n').filter(Boolean).map(JSON.parse));
fs.mkdirSync(path.join(__dirname,'scen'),{recursive:true});const meta={};
const ccw=pts=>{let s=0;for(let i=0;i<pts.length;i++){const q=pts[(i+1)%pts.length];s+=pts[i][0]*q[1]-q[0]*pts[i][1]}return s<0?pts.slice().reverse():pts};
const pts=(p,W)=>{const f=N.flatten(p),o=[];for(let k=0;k<f.length;k+=2)o.push([f[k+1],W-f[k]]);return ccw(o)};
for(const r of rows){const spec={set:r.set,kind:r.kind,seed:r.seed,n:r.set==='suit'?13:18,rot:'dataset'},t=T.build(spec),id=`${r.set}_${r.kind}_${r.seed}`;
 if(t.name+'|dataset'!==r.name)throw new Error('task mismatch '+t.name+' '+r.name);
 const items=t.pcs.map((p,i)=>{const q=pts(p,t.W);q.push(q[0].slice());return{id:i,demand:1,orientation:{rotation:{mode:'discrete',angles:p._rot.map(a=>a*90)}},shape:{type:'simple_polygon',data:q}}});
 const defects=t.blocked.map(z=>pts(z,t.W));
 fs.writeFileSync(path.join(__dirname,`scen/${id}.json`),JSON.stringify({name:id,items,strip_height:t.W,defects}));
 meta[id]={set:r.set,kind:r.kind,seed:r.seed,n:t.pcs.length,W:t.W,area:t.area,nz:defects.length};}
fs.writeFileSync(path.join(__dirname,'scen/meta.json'),JSON.stringify(meta));console.log(Object.keys(meta).length,'tasks');
