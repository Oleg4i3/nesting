#!/bin/bash
# Sparrow (з патчем про дефекти) на 32 задачах Рис. 6: 3 зерна, 10 с, 1 потік; по 2 процеси паралельно. Результат: ext/scen/out/s<зерно>/final_<задача>.json
cd /home/claude/ext/sparrow_def
mkdir -p /home/claude/nest/ext/scen/out
run(){ id=$1; sd=$2; mkdir -p /home/claude/nest/ext/scen/out/s$sd; ./target/release/sparrow -i /home/claude/nest/ext/scen/$id.json -t 10 --workers 1 -s $sd > /home/claude/nest/ext/scen/out/s$sd/$id.log 2>&1; cp output/final_$id.json /home/claude/nest/ext/scen/out/s$sd/final_$id.json; }
export -f run
for sd in 1 2 3; do ls /home/claude/nest/ext/scen/*_*_9*.json | xargs -n1 basename | sed 's/.json//' | xargs -P2 -I{} bash -c "run {} $sd"; done
echo DONE > /home/claude/nest/ext/scen/out/done.txt
