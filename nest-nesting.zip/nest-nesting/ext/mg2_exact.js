// Точний перетин розкладок LNS та LNS+мережа на підвибірці задач seed 201: node ext/mg2_exact.js <repnet> <ms> <step>
const fs=require('fs'),X=require('../nnx.js'),T=require('../rl_tasks.js'),L=require('../lns2.js'),P=require('../puzzle.js'),N=require('../raster.js');
const rep=X.MLPX.fromJSON(JSON.parse(fs.readFileSync(process.argv[2],'utf8'))),ms=+process.argv[3]||10000,step=+process.argv[4]||4;
const sets='suit,fs_jaeger,fs_charlie,fs_wahid,fs_korf_blouse,fs_korf_dress,fs_simon,fs_hugo'.split(',');
const jobs=[];for(const rot of ['any','deg5'])for(const set of sets)for(const kind of ['both','pholes'])for(const cp of [2,3])jobs.push({set,kind,seed:201,n:set==='suit'?13:99,rot,copies:cp});
jobs.forEach((j,ji)=>{if(ji%step!==(+process.env.OFF||1))return;const t=T.build(j),id=(t.name+'|'+j.rot).replace(/\W+/g,'_');
 const o={width:t.W,maxLength:4000,seed:7,blocked:t.blocked},base={recreate:'BL',kMin:6,kMax:14,T0:0.6};
 const dump=(m,pl)=>{const polys=P.placementsToPolys(t.pcs,pl).map(p=>Array.from(N.flatten(p)));const e=T.evaluate(t,pl);
  fs.writeFileSync(`ext/ov2/${id}__${m}.json`,JSON.stringify({id,m,W:t.W,area:t.area,dens:e?e.dens:null,len:e?e.len:null,polys,zones:t.blocked.map(z=>Array.from(N.flatten(z)))}))};
 dump('lns',L.solveLNS(t.pcs,t.rules,Object.assign({},o,base,{budgetMs:ms})).placements);
 const first=L.solveLNS(t.pcs,t.rules,Object.assign({},o,base,{budgetMs:Math.round(0.5*ms)})),pol={init:first.layout,budgetMs:ms-Math.round(0.5*ms),kMin:3,kMax:8,T0:0.05,T1:0.01};
 dump('afterM',L.solveLNS(t.pcs,t.rules,Object.assign({},o,pol,{recreate:'MIX',mixP:0.5,net:rep,temp:0.3})).placements);
 console.log(id);});
