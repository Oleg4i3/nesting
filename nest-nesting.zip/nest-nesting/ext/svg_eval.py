# Точна оцінка розкладки SVGnest: кількість деталей, перетини, довжина, щільність. Використання: import svg_eval; svg_eval.load(path)
import json,math,re
from shapely.geometry import Polygon
from shapely.ops import unary_union
def load(path):
    d=json.load(open(path)); b=d['best']
    if not b: return None
    polys=[]
    for g in b['items']:
        m=re.match(r'translate\(\s*([-\d.e]+)[ ,]+([-\d.e]+)\s*\)\s*rotate\(\s*([-\d.e]+)',g['tr']); tx,ty,a=map(float,m.groups())
        th=math.radians(a); c,s=math.cos(th),math.sin(th)
        for p in g['polys']:
            if p['hole']: continue
            pts=[tuple(map(float,q.split(','))) for q in p['pts'].split()]
            polys.append((int(p['id'][1:]),[(c*x-s*y+tx,s*x+c*y+ty) for x,y in pts]))
    polys.sort()
    P=[Polygon(q).buffer(0) for _,q in polys]
    area=sum(p.area for p in P); U=unary_union(P)
    L=max(p.bounds[2] for p in P); mn=min(p.bounds[0] for p in P)
    return {'n':len(P),'area':area,'overlap':(area-U.area)/area,'len':L,'minx':mn,'miny':min(p.bounds[1] for p in P),'maxy':max(p.bounds[3] for p in P),'W':d['W'],'dens':area/(d['W']*L),'polys':[q for _,q in polys],'ids':[i for i,_ in polys]}
if __name__=='__main__':
    import sys,glob
    for f in sorted(glob.glob(sys.argv[1])):
        r=load(f)
        if r: print(f.split('/')[-1],r['n'],'dens %.1f'%(100*r['dens']),'overlap %.4f'%r['overlap'],'minx %.2f maxy %.2f (W %g)'%(r['minx'],r['maxy'],r['W']))
