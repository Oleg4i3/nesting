#!/bin/bash
# Sparrow (з патчем про дефекти) на пазлах із зонами: 3 зерна, T с, 1 потік; по 2 процеси паралельно. Результат: ext/zscen/out/s<зерно>/final_<задача>.json
# bash ext/z_sparrow_run.sh <тег> [T=10]
TAG=$1; T=${2:-10}
cd /home/claude/ext/sparrow_def
run(){ id=$1; sd=$2; T=$3; mkdir -p /home/claude/nest/ext/zscen/out/s$sd; ./target/release/sparrow -i /home/claude/nest/ext/zscen/$id.json -t $T --workers 1 -s $sd > /home/claude/nest/ext/zscen/out/s$sd/$id.log 2>&1; cp output/final_$id.json /home/claude/nest/ext/zscen/out/s$sd/final_$id.json; }
export -f run
for sd in 1 2 3; do ls /home/claude/nest/ext/zscen/${TAG}_*.json | xargs -n1 basename | sed 's/.json//' | xargs -P2 -I{} bash -c "run {} $sd $T"; done
echo DONE > /home/claude/nest/ext/zscen/out/done.txt
