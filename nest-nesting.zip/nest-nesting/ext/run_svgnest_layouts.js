// node ext/run_svgnest_layouts.js <seconds> <name:file,...> — SVGnest зі збереженням розкладки (перетворення кожної деталі).
// Деталі беруться з вхідних файлів у форматі Sparrow; смуга: висота = strip_height, довжина необмежена (великий контейнер).
const {chromium}=require('playwright'),fs=require('fs');
const SEC=+process.argv[2]||30, list=process.argv[3].split(',').map(s=>s.split(':'));
(async()=>{
 const br=await chromium.launch({args:['--allow-file-access-from-files']});
 for(const [id,file] of list){
  const inst=JSON.parse(fs.readFileSync(file,'utf8')),W=inst.strip_height;let parts=[];
  for(const it of inst.items)for(let k=0;k<(it.demand||1);k++)parts.push(it);
  const rot=(parts[0].orientation&&parts[0].orientation.rotation&&parts[0].orientation.rotation.angles)||[0,90,180,270];
  const ar=p=>{let s=0;for(let i=0;i<p.length-1;i++)s+=p[i][0]*p[i+1][1]-p[i+1][0]*p[i][1];return Math.abs(s)/2};
  const area=parts.reduce((s,it)=>s+ar(it.shape.data),0);const Lbin=Math.ceil(area/W*3);
  let svg=`<svg xmlns="http://www.w3.org/2000/svg" width="${Lbin}" height="${W}" viewBox="0 0 ${Lbin} ${W}"><rect id="bin" x="0" y="0" width="${Lbin}" height="${W}"/>`;
  // УВАГА: SVGnest вважає багатокутник, що лежить усередині іншого, «діркою» й не розміщує його. Тому деталі на вході розкладаємо поруч, без накладання.
  let ox=0;const oy=W+30;
  parts.forEach((it,i)=>{const d=it.shape.data.slice(0,-1),x0=Math.min(...d.map(p=>p[0])),y0=Math.min(...d.map(p=>p[1])),w=Math.max(...d.map(p=>p[0]))-x0;
   const pts=d.map(p=>(p[0]-x0+ox).toFixed(3)+','+(p[1]-y0+oy).toFixed(3)).join(' ');ox+=w+20;svg+=`<polygon id="p${i}" points="${pts}"/>`});svg+='</svg>';
  const page=await br.newPage();page.on('pageerror',e=>console.log('pageerror',e.message.slice(0,200)));
  await page.goto('file:///home/claude/ext/svgnest_src/repo/index.html');await page.waitForTimeout(1500);
  const res=await page.evaluate(async({svg,SEC,ROT})=>{
    const s=window.SvgNest.parsesvg(svg);const bin=[...s.childNodes].find(n=>n.id==='bin');window.SvgNest.setbin(bin);
    window.SvgNest.config({rotations:ROT,populationSize:10,mutationRate:10,spacing:0,curveTolerance:0.3,useHoles:false,exploreConcave:false});
    let best=null,t0=Date.now(),n=0;
    const disp=(svglist,eff,placed,total)=>{n++;if(placed!==total)return;const sv=svglist[0];
      const host=document.createElement('div');host.style.cssText='position:absolute;left:0;top:0';document.body.appendChild(host);host.appendChild(sv);
      let mx=0;const o=sv.getBoundingClientRect();sv.querySelectorAll('g').forEach(g=>{const r=g.getBoundingClientRect();mx=Math.max(mx,r.right-o.left)});host.remove();
      if(best&&mx>=best.len)return;
      const items=[...sv.querySelectorAll('g')].map(g=>({tr:g.getAttribute('transform'),polys:[...g.querySelectorAll('polygon')].map(c=>({id:c.id,pts:c.getAttribute('points'),hole:c.classList.contains('hole')}))}));
      best={len:mx,t:Date.now()-t0,items};};
    window.SvgNest.start(()=>{},disp);
    await new Promise(r=>setTimeout(r,SEC*1000));window.SvgNest.stop();return{best,n,total:null};
  },{svg,SEC,ROT:rot.length});
  console.log(id,'parts',parts.length,'rot',rot.length,'calls',res.n,res.best?`len ${res.best.len.toFixed(1)} t ${res.best.t} items ${res.best.items.length} polys ${res.best.items.reduce((a,g)=>a+g.polys.length,0)}`:'no full placement');
  fs.writeFileSync(`${process.env.OUT||"ext/svg_sim"}/${id}.json`,JSON.stringify({id,W,Lbin,area,rot,best:res.best}));
  await page.close();
 }
 await br.close();
})();
