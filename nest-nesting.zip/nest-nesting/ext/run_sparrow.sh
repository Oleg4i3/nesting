#!/bin/bash
# Sparrow на синтетичних пазлах (ext/<id>.json, створені node ext_export.js export): T секунд, 1 потік.
SPARROW_DIR=${SPARROW_DIR:-$HOME/sparrow}; HERE=$(cd "$(dirname "$0")/.." && pwd); T=${1:-30}; mkdir -p "$HERE/ext/sp"
cd "$SPARROW_DIR"
for id in pz_a pz_b pzbig_a pzbig_b pzbig_c trim_a trim_b; do
  ./target/release/sparrow -i "$HERE/ext/$id.json" -t $T --workers 1 -s 1 > "$HERE/ext/sp/${id}_$T.log" 2>&1
  cp output/final_$id.json "$HERE/ext/sp/${id}_$T.json"
done
