#!/bin/bash
# Sparrow на реальних наборах: 30 с, 1 потік. SPARROW_DIR — каталог зібраного Sparrow (git clone + cargo build --release).
SPARROW_DIR=${SPARROW_DIR:-$HOME/sparrow}; HERE=$(cd "$(dirname "$0")/.." && pwd); mkdir -p "$HERE/ext/sp_real"
cd "$SPARROW_DIR"
for id in marques albano dagli mao swim trousers shirts; do
  ./target/release/sparrow -i "$HERE/examples/real/esicup_$id.json" -t 30 --workers 1 -s 1 > "$HERE/ext/sp_real/${id}.log" 2>&1
  cp output/final_esicup_$id.json "$HERE/ext/sp_real/${id}.json" 2>/dev/null || cp output/final_$id.json "$HERE/ext/sp_real/${id}.json"
done
