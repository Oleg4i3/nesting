#!/bin/bash
# 3 запуски SVGnest (30 с) на 7 пазлах із виправленим входом (деталі не накладаються)
cd /home/claude/nest
L=pz_a:ext/pz_a.json,pz_b:ext/pz_b.json,pzbig_a:ext/pzbig_a.json,pzbig_b:ext/pzbig_b.json,pzbig_c:ext/pzbig_c.json,trim_a:ext/trim_a.json,trim_b:ext/trim_b.json
for r in 1 2 3; do mkdir -p ext/svg_fix/run$r; OUT=ext/svg_fix/run$r node ext/run_svgnest_layouts.js 30 $L > ext/svg_fix/run$r.log 2>&1; done
echo DONE > ext/svg_fix/done.txt
