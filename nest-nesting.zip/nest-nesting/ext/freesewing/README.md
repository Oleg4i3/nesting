# Реальні лекала з відкритого параметричного конструктора FreeSewing (MIT)

`extract.mjs` — креслить деталі (з припусками 10 мм) для вибірки розмірів: чоловічий 40 (`cisMaleAdult40`) і жіночий 36 (`cisFemaleAdult36`), та зберігає контури (криві Безьє розбито на 14 відрізків) і кількість деталей з основної тканини у `fs_parts.json`.
`mkset.py` — складає набори у форматі Sparrow JSON (`examples/real/fs_<назва>.json`): деталі «на згині» розгорнуто до цілої, парні — з дзеркальною копією; нитка основи повернута вздовж довжини рулона; дозволені кути 0/180; ширина рулона 1500 мм.

Встановлення: `npm i @freesewing/core @freesewing/models @freesewing/config @freesewing/plugin-transform @freesewing/plugin-theme @freesewing/plugin-i18n @freesewing/jaeger @freesewing/charlie @freesewing/simon @freesewing/hugo @freesewing/carlton @freesewing/wahid @freesewing/yuri @freesewing/bent @freesewing/sven` (версія 4.10.2).
