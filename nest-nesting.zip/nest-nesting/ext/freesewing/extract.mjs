import * as M from '@freesewing/models'
import fs from 'fs'
import { createRequire } from 'module'
const require = createRequire(import.meta.url)
const pc = require('/home/claude/nest/node_modules/polygon-clipping')
const designs = {
  brian:['@freesewing/brian','Brian','m'], simon:['@freesewing/simon','Simon','m'], teagan:['@freesewing/teagan','Teagan','m'],
  bella:['@freesewing/bella','Bella','f'], jaeger:['@freesewing/jaeger','Jaeger','m'], charlie:['@freesewing/charlie','Charlie','m'],
  titan:['@freesewing/titan','Titan','m'], sven:['@freesewing/sven','Sven','m'], wahid:['@freesewing/wahid','Wahid','m'],
  carlton:['@freesewing/carlton','Carlton','m'], penelope:['@freesewing/penelope','Penelope','f'], sandy:['@freesewing/sandy','Sandy','f'],
  bent:['@freesewing/bent','Bent','m'], hugo:['@freesewing/hugo','Hugo','m'], yuri:['@freesewing/yuri','Yuri','m'], aaron:['@freesewing/aaron','Aaron','m'],
}
const meas = { m: M.cisMaleAdult40, f: M.cisFemaleAdult36 }
function sampleOps(ops, seg = 14) {
  const pts = []; let cur = null
  for (const o of ops) {
    if (o.type === 'move') { cur = [o.to.x, o.to.y]; pts.push(cur) }
    else if (o.type === 'line') { cur = [o.to.x, o.to.y]; pts.push(cur) }
    else if (o.type === 'curve') {
      const p0 = cur, p1 = [o.cp1.x, o.cp1.y], p2 = [o.cp2.x, o.cp2.y], p3 = [o.to.x, o.to.y]
      for (let k = 1; k <= seg; k++) { const t = k / seg, u = 1 - t, a = u*u*u, b = 3*u*u*t, c = 3*u*t*t, d = t*t*t; pts.push([a*p0[0]+b*p1[0]+c*p2[0]+d*p3[0], a*p0[1]+b*p1[1]+c*p2[1]+d*p3[1]]) }
      cur = p3
    }
  }
  return pts
}
function dedupe(pts) { const o = []; for (const p of pts) { const q = o[o.length-1]; if (!q || Math.hypot(p[0]-q[0], p[1]-q[1]) > 0.05) o.push(p) } if (o.length>1 && Math.hypot(o[0][0]-o[o.length-1][0], o[0][1]-o[o.length-1][1])<0.05) o.pop(); return o }
const out = {}
for (const [key, [pkg, cls, g]] of Object.entries(designs)) {
  try {
    const mod = await import(pkg); const D = mod[cls]
    const p = new D({ measurements: meas[g], sa: 10, complete: false }); p.draft()
    const cl = p.setStores[0].get('cutlist') || {}
    const parts = []
    for (const [name, pt] of Object.entries(p.parts[0])) {
      if (pt.hidden) continue
      const path = pt.paths.sa || pt.paths.seam; if (!path) continue
      const mats = cl[name]?.materials?.fabric; if (!mats) continue
      let pts = dedupe(sampleOps(path.ops)); if (pts.length < 3) continue
      const fold = cl[name]?.cutOnFold, grain = cl[name]?.grain
      let ringsets = [pts]
      if (fold && fold.length === 2) {
        const xf = fold[0].x, mir = pts.map(q => [2 * xf - q[0], q[1]]).reverse()
        const u = pc.union([pts.concat([pts[0]])], [mir.concat([mir[0]])])
        if (u.length === 1 && u[0].length === 1) pts = dedupe(u[0][0])
      }
      for (const m of mats) parts.push({ name, pts, cut: m.cut || 1, onFold: !!m.onFold, identical: m.identical !== false, grain: grain ?? 270, bias: !!m.onBias })
    }
    out[key] = parts
    console.log(key, parts.map(q => `${q.name.split('.').pop()}x${q.cut}${q.onFold?'F':''}g${q.grain}`).join(' '))
  } catch (e) { console.log(key, 'ERR', String(e.message).slice(0, 150)) }
}
fs.writeFileSync('fs_parts.json', JSON.stringify(out))
