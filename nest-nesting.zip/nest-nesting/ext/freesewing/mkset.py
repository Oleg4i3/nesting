import json, math
from shapely.geometry import Polygon
P=json.load(open('fs_parts.json'))
SCALE=1.0
def piece_items(parts, name):
    items=[]; 
    for q in parts:
        pts=q['pts']
        # rotate so grain (FreeSewing y) lies along Sparrow x: (x,y)->(y,-x)
        def rot(p): return [round(p[1],2), round(-p[0],2)]
        def rotm(p): return [round(p[1],2), round(p[0],2)]   # mirror across fold: (x,y)->(-x,y) then rot => (y, x)
        cut=q['cut']
        sh=[rot(p) for p in pts]
        if Polygon(sh).area==0: continue
        n_orig=cut; n_mir=0
        if cut>=2 and not q['identical']:
            n_orig=(cut+1)//2; n_mir=cut//2
        elif cut>=2 and q['name'].split('.')[-1] in ('front','back','sleeve','topsleeve','undersleeve','pocket'):
            n_orig=(cut+1)//2; n_mir=cut//2
        items.append((q['name'].split('.')[-1],sh,n_orig))
        if n_mir:
            msh=[rotm(p) for p in pts][::-1]
            items.append((q['name'].split('.')[-1]+'_m',msh,n_mir))
    return items
def build(name, keys):
    its=[]
    for k in keys:
        for (nm,sh,dm) in piece_items(P[k],k): its.append((k+'.'+nm,sh,dm))
    data={'name':'fs_'+name,'strip_height':1500.0,'items':[]}
    area=0
    for i,(nm,sh,dm) in enumerate(its):
        # normalize min to 0
        mx=min(p[0] for p in sh); my=min(p[1] for p in sh)
        sh=[[round(p[0]-mx,2),round(p[1]-my,2)] for p in sh]
        # drop collinear/dup via simplify
        poly=Polygon(sh).buffer(0).simplify(0.6)
        if poly.geom_type!='Polygon': continue
        c=list(poly.exterior.coords)[:-1]
        area+=poly.area*dm
        data['items'].append({'id':i,'name':nm,'demand':dm,'allowed_orientations':[0,180],'shape':{'type':'simple_polygon','data':[[round(a,2),round(b,2)] for a,b in c]}})
    json.dump(data,open(f'/home/claude/nest/examples/real/fs_{name}.json','w'))
    n=sum(i['demand'] for i in data['items'])
    print(f'{name:10s} типів {len(data["items"]):3d} деталей {n:3d} площа {area/1e6:.2f} м2, довжина при 70% ≈ {area/1500/0.7/1000:.2f} м')
build('jaeger',['jaeger']); build('carlton',['carlton']); build('charlie',['charlie']); build('simon',['simon'])
build('hugo',['hugo']); build('bent',['bent']); build('wahid',['wahid']); build('suit3',['jaeger','charlie','wahid'])
build('yuri',['yuri'])
