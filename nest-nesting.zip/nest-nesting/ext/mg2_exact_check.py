import json,glob,sys
from shapely.geometry import Polygon
from shapely.strtree import STRtree
res={}
for f in sorted(glob.glob('ext/ov2/*.json')):
    d=json.load(open(f)); 
    mk=lambda f_:Polygon([(f_[i],f_[i+1]) for i in range(0,len(f_),2)]).buffer(0)
    P=[mk(p) for p in d['polys']]; Z=[mk(z) for z in d['zones']]
    tot=sum(p.area for p in P); ov=0; oz=0
    for i in range(len(P)):
        for j in range(i+1,len(P)):
            if P[i].bounds[2]<P[j].bounds[0] or P[j].bounds[2]<P[i].bounds[0] or P[i].bounds[3]<P[j].bounds[1] or P[j].bounds[3]<P[i].bounds[1]: continue
            ov+=P[i].intersection(P[j]).area
        for z in Z:
            if P[i].intersects(z): oz+=P[i].intersection(z).area
    res.setdefault(d['id'],{})[d['m']]=dict(dens=100*d['dens'],ov=100*ov/tot,oz=100*oz/tot)
import statistics as st
for m in ('lns','afterM'):
    ov=[v[m]['ov'] for v in res.values() if m in v]; oz=[v[m]['oz'] for v in res.values() if m in v]; dn=[v[m]['dens'] for v in res.values() if m in v]
    tot=[o+z for o,z in zip(ov,oz)]
    print(m,'n=%d'%len(ov),'пер. деталь-деталь: сер. %.2f%% макс %.2f%%'%(st.mean(ov),max(ov)),'деталь-зона: сер. %.2f%% макс %.2f%%'%(st.mean(oz),max(oz)),'дод. щільність %.1f'%st.mean(dn),'поправл. %.1f'%st.mean([d-t for d,t in zip(dn,tot)]))
dif=[(v['afterM']['dens']-v['afterM']['ov']-v['afterM']['oz'])-(v['lns']['dens']-v['lns']['ov']-v['lns']['oz']) for v in res.values() if 'afterM' in v and 'lns' in v]
print('різниця afterM−lns з поправкою: %.2f пп (n=%d)'%(st.mean(dif),len(dif)))
json.dump(res,open('results/mg2_exact.json','w'))
