# Об'єднання перетинних зон у непересічні полігони для Sparrow (його контейнер не будується з перетинними зонами)
import json,glob
from shapely.geometry import Polygon
from shapely.ops import unary_union
for f in glob.glob('/home/claude/nest/ext/zscen/mg_*_201_x*.json'):
    d=json.load(open(f))
    if not d['defects']: continue
    u=unary_union([Polygon(z).buffer(0) for z in d['defects']]);gs=[u] if u.geom_type=='Polygon' else list(u.geoms);new=[]
    for g in gs:
        g=Polygon(g.exterior)
        if g.area<1: continue
        c=list(g.simplify(0.05).exterior.coords)[:-1]
        if not Polygon(c).exterior.is_ccw: c=c[::-1]
        new.append([list(p) for p in c])
    d['defects']=new;json.dump(d,open(f,'w'))
print('union done')
