// node ext/run_svgnest.js <seconds> [ids]  — запускає SVGnest (з клону репозиторію) у headless Chromium
const {chromium}=require('playwright'),fs=require('fs');
const SEC=+process.argv[2]||30, ids=(process.argv[3]||'pz_a,pz_b,pzbig_a,pzbig_b,trim_a,trim_b').split(',');
const meta=JSON.parse(fs.readFileSync('ext/meta.json','utf8'));
const ROT=24;
(async()=>{
 const br=await chromium.launch({args:['--allow-file-access-from-files']});const out={};
 for(const id of ids){
  const inst=JSON.parse(fs.readFileSync(`ext/${id}.json`,'utf8')),W=inst.strip_height,Lbin=Math.round(meta[id].plantedLen*1.8);
  let svg=`<svg xmlns="http://www.w3.org/2000/svg" width="${Lbin}" height="${W}" viewBox="0 0 ${Lbin} ${W}"><rect id="bin" x="0" y="0" width="${Lbin}" height="${W}"/>`;
  inst.items.forEach((it,i)=>{const pts=it.shape.data.slice(0,-1).map(p=>p[0].toFixed(3)+','+p[1].toFixed(3)).join(' ');svg+=`<polygon id="p${i}" points="${pts}"/>`});svg+='</svg>';
  const page=await br.newPage();page.on('pageerror',e=>console.log('pageerror',e.message.slice(0,200)));
  await page.goto('file://'+(process.env.SVGNEST_DIR||process.env.HOME+'/SVGnest')+'/index.html');await page.waitForTimeout(1500);
  const res=await page.evaluate(async({svg,SEC,ROT})=>{
    const s=window.SvgNest.parsesvg(svg);const bin=[...s.childNodes].find(n=>n.id==='bin');window.SvgNest.setbin(bin);
    window.SvgNest.config({rotations:ROT,populationSize:10,mutationRate:10,spacing:0,curveTolerance:0.3,useHoles:false,exploreConcave:false});
    let best=null,t0=Date.now(),hist=[];
    const disp=(svglist,eff,placed,total)=>{ if(placed===total){const host=document.createElement('div');host.style.cssText='position:absolute;left:0;top:0';document.body.appendChild(host);host.appendChild(svglist[0]);
        let mx=0;svglist[0].querySelectorAll('g').forEach(g=>{const r=g.getBoundingClientRect();const o=svglist[0].getBoundingClientRect();mx=Math.max(mx,r.right-o.left)});host.remove();
        hist.push([Date.now()-t0,mx]);if(!best||mx<best.len)best={len:mx,eff,t:Date.now()-t0}}};
    window.SvgNest.start(()=>{},disp);
    await new Promise(r=>setTimeout(r,SEC*1000));window.SvgNest.stop();return{best,hist,n:null};
  },{svg,SEC,ROT});
  const area=meta[id].area;const r=res.best?{len:res.best.len,dens:area/(W*res.best.len),tBest:res.best.t,hist:res.hist}:null;out[id]=r;console.log(id,r?`len ${r.len.toFixed(1)} dens ${(r.dens*100).toFixed(1)}% tBest ${r.tBest}ms evals ${r.hist.length}`:'no full placement');
  await page.close();fs.writeFileSync(`ext/svgnest_${SEC}.json`,JSON.stringify(out));
 }
 await br.close();
})();
