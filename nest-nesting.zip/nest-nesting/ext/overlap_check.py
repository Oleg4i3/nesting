# Точний перетин розкладки: Σ площ попарних перетинів / Σ площ деталей. python3 -I ext/overlap_check.py ext/ov_<id>.json
import json,sys
from shapely.geometry import Polygon
d=json.load(open(sys.argv[1]));P=[]
for f in d['polys']:
    pts=[(f[i],f[i+1]) for i in range(0,len(f),2)];p=Polygon(pts)
    P.append(p if p.is_valid else p.buffer(0))
tot=sum(p.area for p in P);ov=0;mx=0
for i in range(len(P)):
    for j in range(i+1,len(P)):
        if P[i].bounds[2]<P[j].bounds[0] or P[j].bounds[2]<P[i].bounds[0] or P[i].bounds[3]<P[j].bounds[1] or P[j].bounds[3]<P[i].bounds[1]:continue
        a=P[i].intersection(P[j]).area;ov+=a;mx=max(mx,a)
print(sys.argv[1],'overlap %.2f%% of area, max pair %.1f px2 (%.2f%% of piece)'%(100*ov/tot,mx,100*mx/min(p.area for p in P)))
