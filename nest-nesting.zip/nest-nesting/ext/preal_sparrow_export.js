// Експорт задач preal (фігурні деталі, діри у формі деталей, кути 90° і 5°) у формат Sparrow → ext/zscen/pr_<кути>_*.json. ROT90=1 NONRECT=1 node ext/preal_sparrow_export.js
const fs = require('fs'), path = require('path'), N = require('../raster.js'), T = require('../rl_tasks.js');
const dir = path.join(__dirname, 'zscen'); fs.mkdirSync(dir, { recursive: true });
const ccw = pts => { let s = 0; for (let i = 0; i < pts.length; i++) { const q = pts[(i + 1) % pts.length]; s += pts[i][0] * q[1] - q[0] * pts[i][1]; } return s < 0 ? pts.slice().reverse() : pts; };
const pts = (p, W) => { const f = N.flatten(p), o = []; for (let k = 0; k < f.length; k += 2) o.push([f[k + 1], W - f[k]]); return ccw(o); };
const metaF = path.join(dir, 'meta.json'), meta = fs.existsSync(metaF) ? JSON.parse(fs.readFileSync(metaF)) : {};
let cnt = 0;
for (const rot of ['any', 'deg5']) for (const f of fs.readdirSync(path.join(__dirname, '../results')).filter(f => new RegExp(`^preal_${rot}_part\\d+\\.jsonl$`).test(f))) for (const l of fs.readFileSync(path.join(__dirname, '../results', f), 'utf8').split('\n').filter(Boolean)) {
  const r = JSON.parse(l), spec = { set: r.set, kind: r.kind, seed: r.seed, n: r.set === 'suit' ? 13 : 99, rot }, t = T.build(spec), id = `pr_${rot}_${r.set}_${r.kind}_${r.seed}`;
  if (t.name + '|' + rot !== r.name) throw new Error('task mismatch ' + t.name + ' ' + r.name);
  const ang = N.allowedFor(t.pcs[0], t.rules).rotations.map(a => +(a * 90).toFixed(6));
  const items = t.pcs.map((p, i) => { const q = pts(p, t.W); q.push(q[0].slice()); return { id: i, demand: 1, orientation: { rotation: { mode: 'discrete', angles: ang } }, shape: { type: 'simple_polygon', data: q } }; });
  fs.writeFileSync(path.join(dir, id + '.json'), JSON.stringify({ name: id, items, strip_height: t.W, defects: t.blocked.map(z => pts(z, t.W)) }));
  meta[id] = { set: r.set, kind: r.kind, seed: r.seed, n: t.pcs.length, W: t.W, area: t.area, nz: t.blocked.length }; cnt++;
}
fs.writeFileSync(metaF, JSON.stringify(meta)); console.log(cnt, 'задач');
