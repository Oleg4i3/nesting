// zpuzzle.js — пазли із заборонними зонами різної форми й розміру (півмісяці, S-смуги, плями, нерівні краї).
// Зони вирізано з рулона ДО розбиття: деталі еталона точно покривають вільну область (див. zgen.py).
//   python3 zgen.py <тег> <перше_зерно> <кількість>   -> data/zgen_<тег>.json
//   const Z = require('./zpuzzle.js'); const list = Z.load('z1'); const pz = Z.build(list[i]);
const fs = require('fs'), N = require('./raster.js'), P = require('./puzzle.js'), C = require('./common.js');
const cache = {};
function load(tag) { return cache[tag] || (cache[tag] = JSON.parse(fs.readFileSync(`${__dirname}/data/zgen_${tag}.json`, 'utf8'))); }
const toPoly = r => ({ vertices: r.map(p => ({ x: p[0], y: p[1] })), bezierControls: r.map(() => null) });
/** Пазл за записом генератора. opts.rules — перевизначити правила обертання. */
function build(rec, opts = {}) {
  const spec = C.randomSpecAng3(rec.seed, 'scoop', rec.big);
  const r = P.mulberry32(rec.seed * 2654435761 >>> 0)();
  Object.assign(spec, { width: rec.width, length: rec.length, pieces: rec.n, waste: 0, scoop: 0, trim: 0, hard: 'z' + rec.kind,
    rules: opts.rules || (rec.rot ? { rotations: rec.rot === 'half' ? [0, 2] : rec.rot, mirror: false } : r < 0.75 ? { rotations: 'deg15', mirror: false } : { rotations: [0, 2], mirror: false }),
    post: () => ({ origs: rec.pieces.map(toPoly), blocked: rec.zones.map(toPoly) }) });
  const pz = P.generate(spec);
  const ev = N.evaluateLayout(pz.originals.concat(pz.blocked), { width: pz.width, height: pz.length + 300 });
  const n = pz.originals.length, bad = (ev.overlaps || []).filter(o => (o.i >= n) !== (o.j >= n) && o.cells > 0);
  if (bad.length) throw new Error('еталон перетинає зони: ' + bad.length);
  pz.meta = Object.assign(pz.meta, { kind: 'z' + rec.kind, zoneFrac: rec.zoneFrac, nZones: rec.zones.length, plantedLength: pz.length,
    plantedEfficiency: pz.meta.cells * N.CELL * N.CELL / (pz.width * pz.length) });
  return pz;
}
module.exports = { load, build };
