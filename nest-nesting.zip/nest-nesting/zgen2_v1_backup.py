#!/usr/bin/env python3
"""zgen2.py — пазли «з точковими дотиками»: деталі торкаються сусідів лише в кількох точках (як у реальних розкладках),
заборонені зони — нерівні краї й діри у формі деталей викройок (кишеня, рукав, ...). Зони вирізано до розбиття.
python3 zgen2.py <тег> <перше_зерно> <кількість> [pool=train|test]  ->  data/zgen_<тег>.json
python3 zgen2.py zones <W> <L> <kind> <seed> [pool]  -> зони (JSON) для задач із реальними лекалами
Пул форм: train — brian, teagan, bella, penelope, sandy, aaron, titan; test — carlton, yuri, bent, sven (не збігаються)."""
import sys, json, math, random
import shapely
from shapely.geometry import Polygon, LineString, Point, box
from shapely.ops import unary_union, linemerge
from shapely import affinity
import zgen as Z0

POOLS = {'train': ['brian', 'teagan', 'bella', 'penelope', 'sandy', 'aaron', 'titan'], 'test': ['carlton', 'yuri', 'bent', 'sven']}
_parts = None
def parts(pool):
    global _parts
    if _parts is None: _parts = json.load(open('/home/claude/ext/fs/fs_parts.json'))
    out = []
    for d in POOLS[pool]:
        for q in _parts.get(d, []):
            p = Polygon(q['pts']).buffer(0)
            if p.geom_type == 'Polygon' and p.area > 2e4: out.append((d + '.' + q['name'].split('.')[-1], p.simplify(0.5)))
    return out

def part_zone(rng, pool, W, L):
    name, p = rng.choice(parts(pool))
    c = p.centroid; p = affinity.translate(p, -c.x, -c.y)
    p = affinity.rotate(p, rng.uniform(0, 360), origin=(0, 0))
    if rng.random() < 0.5: p = affinity.scale(p, -1, 1, origin=(0, 0))
    s = (W / 1500.0) * rng.uniform(0.7, 1.6)
    p = affinity.scale(p, s, s, origin=(0, 0))
    b = p.bounds; w, h = b[2] - b[0], b[3] - b[1]
    cx = rng.uniform(w / 2 * 0.7, W - w / 2 * 0.7); cy = rng.uniform(h / 2 * 0.5, max(h / 2 * 0.5 + 1, L - h / 2 * 0.5))
    return affinity.translate(p, cx, cy)

def make_zones2(rng, kind, W, L, pool):
    zs = []
    if kind == 'pplain': return zs
    n = rng.randint(1, 4) if kind == 'phole' else rng.randint(0, 2)
    for _ in range(n):
        for att in range(30):
            z = part_zone(rng, pool, W, L)
            if all(z.distance(o) > 12 for o in zs) and z.intersection(box(0, 0, W, L)).area > 0.6 * z.area: zs.append(z); break
    if kind == 'pragged':
        mode = rng.choice(['both', 'left', 'right'])
        for s in (['left', 'right'] if mode == 'both' else [mode]): zs.append(Z0.ragged(rng, W, L, s))
        if rng.random() < 0.25: zs.append(Z0.corner(rng, W, L))
    return zs

def sparsify(rng, faces, gmin=5.0, gmax=10.0):
    n = len(faces); strips = [[] for _ in range(n)]
    for i in range(n):
        for j in range(i + 1, n):
            it = faces[i].boundary.intersection(faces[j].boundary)
            gs = [g for g in ([it] if isinstance(it, LineString) else list(getattr(it, 'geoms', []))) if isinstance(g, LineString) and not g.is_empty]
            if not gs: continue
            lm = linemerge(gs)
            for g in ([lm] if isinstance(lm, LineString) else list(lm.geoms)):
                ln = g.length
                if ln < 8: continue
                nn = rng.choice([i, j]); k = rng.choices([0, 1, 2], [0.3, 0.5, 0.2])[0]
                ts = sorted(rng.uniform(0.15, 0.85) * ln for _ in range(k)); h = max(6.0, 0.12 * ln); G = rng.uniform(gmin, gmax)
                m = max(3, int(ln / 3)); P = []; Q = []
                for t in range(m + 1):
                    s = ln * t / m; p = g.interpolate(s); a = g.interpolate(max(0, s - 1.5)); b = g.interpolate(min(ln, s + 1.5))
                    dx, dy = b.x - a.x, b.y - a.y; l = math.hypot(dx, dy) or 1; nx, ny = -dy / l, dx / l
                    if faces[nn].buffer(0).contains(Point(p.x + nx * 0.8, p.y + ny * 0.8)) is False: nx, ny = -nx, -ny
                    w = 1.0
                    for s0 in ts: w = min(w, min(1.0, ((s - s0) / h) ** 2))
                    P.append((p.x, p.y)); Q.append((p.x + nx * G * w, p.y + ny * G * w))
                poly = Polygon(P + Q[::-1]).buffer(0)
                if not poly.is_empty: strips[nn].append(poly)
    out = []
    for f, st in zip(faces, strips):
        if st:
            g = f.difference(unary_union(st))
            ps = Z0.polys(g)
            if ps:
                big = max(ps, key=lambda q: q.area)
                if big.area >= 0.7 * f.area and not big.interiors: g = big
                else: g = f
            else: g = f
        else: g = f
        out.append(g)
    return out


def settle(rng, faces, zones, W, L, rounds=5):
    """Стискаємо кожну деталь на випадкову величину, потім «осаджуємо»: зсуваємо у випадковому напрямку до першого
    дотику з сусідом/зоною/краєм і трохи повертаємо. Контакти стають точковими, зазори — змінної ширини."""
    rect = box(0, 0, W, L); zun = unary_union(zones) if zones else None
    P = []
    for f in faces:
        g = f.buffer(-rng.uniform(1.5, 7.0), join_style=1)
        ps = Z0.polys(g)
        g = max(ps, key=lambda q: q.area) if ps else f
        P.append(g.simplify(0.4) if g.area > 0.6 * f.area else f.simplify(0.4))
    def ok(g, i):
        if not rect.buffer(0.01).contains(g): return False
        if zun is not None and g.intersects(zun) and g.intersection(zun).area > 1e-4: return False
        for j, q in enumerate(P):
            if j != i and g.bounds[0] <= q.bounds[2] and q.bounds[0] <= g.bounds[2] and g.bounds[1] <= q.bounds[3] and q.bounds[1] <= g.bounds[3]:
                if g.intersects(q) and g.intersection(q).area > 1e-4: return False
        return True
    n = len(P)
    for rd in range(rounds):
        for i in rng.sample(range(n), n):
            g = P[i]
            if rng.random() < 0.6:
                d = rng.uniform(-3.5, 3.5); h = affinity.rotate(g, d, origin=g.centroid)
                if ok(h, i): g = h
            a = rng.uniform(0, 2 * math.pi); dx, dy = math.cos(a), math.sin(a)
            lo, hi = 0.0, rng.uniform(8, 40)
            if ok(affinity.translate(g, dx * hi, dy * hi), i): lo = hi
            else:
                for _ in range(12):
                    m = (lo + hi) / 2
                    if ok(affinity.translate(g, dx * m, dy * m), i): lo = m
                    else: hi = m
            P[i] = affinity.translate(g, dx * lo, dy * lo)
    return P

def contact_stats(P):
    n = len(P); cl = []; gaps = []
    for i in range(n):
        for j in range(i + 1, n):
            d = P[i].distance(P[j])
            if d < 25:
                gaps.append(d)
                if d < 1.0: cl.append(P[i].boundary.intersection(P[j].buffer(1.5)).length)
    return cl, gaps

def gen2(seed, kind, big, pool='train'):
    rng = random.Random(seed * 7919 + 17)
    n = rng.randint(14, 24) if big else rng.randint(8, 13)
    W = 10 * rng.randint(24, 36)
    L0 = round(n * 12500 * rng.uniform(0.9, 1.1) / W / 10) * 10
    for att in range(30):
        zs = make_zones2(rng, kind, W, L0, pool)
        R = box(0, 0, W, L0)
        zu = unary_union([z.buffer(0) for z in zs]).intersection(R) if zs else Polygon()
        F = R.difference(zu)
        comps = sorted(Z0.polys(F), key=lambda p: -p.area)
        amin = 0.4 * (F.area / n)
        keep = [c for c in comps if c.area >= max(amin * 2, 2500) and not c.interiors]
        if not keep: continue
        Fk = unary_union(keep); zfrac = 1 - Fk.area / R.area
        if zfrac > 0.3 or (kind != 'pplain' and zfrac < 0.02): continue
        ns = max(6, round(n * Fk.area / R.area)); faces = []; ok = True
        for c in keep:
            r = Z0.partition(rng, c, max(2, round(ns * c.area / Fk.area)), W, L0, amin)
            if r is None: ok = False; break
            faces += r
        if not ok or len(faces) < 6: continue
        zon0 = [z.buffer(0).intersection(R) for z in zs] + [c for c in comps if c not in keep]
        sp = settle(rng, faces, [z for z in zon0 if not z.is_empty], W, L0)
        sp = [f for f in sp if f.area > 800]
        zon = [Polygon(p.exterior) for z in zs for p in Z0.polys(z.buffer(0).intersection(R))] + [Polygon(c.exterior) for c in comps if c not in keep]
        zun = unary_union(zon) if zon else Polygon()
        if zon and any(f.intersection(zun).area > 3.0 for f in sp): continue
        if len(sp) < 6: continue
        ov = sum(sp[i].intersection(sp[j]).area for i in range(len(sp)) for j in range(i + 1, len(sp)) if sp[i].intersects(sp[j]))
        if ov > 5.0: continue
        rot = rng.choices(['any', 'deg15', 'deg5', 'half'], [0.3, 0.35, 0.15, 0.2])[0]
        return dict(seed=seed, kind=kind, big=big, width=W, length=L0, n=len(sp), rot=rot, pool=pool,
                    zones=[[list(c) for c in p.exterior.coords[:-1]] for p in zon],
                    pieces=[[list(c) for c in f.exterior.coords[:-1]] for f in sp],
                    zoneFrac=1 - sum(f.area for f in sp) / R.area, zoneOnly=zfrac)
    return None

def zones_for2(seed, kind, W, L, pool='test'):
    rng = random.Random(seed * 104729 + 31)
    for att in range(40):
        zs = make_zones2(rng, kind, W, L, pool)
        R = box(0, 0, W, L)
        zu = unary_union([z.buffer(0) for z in zs]).intersection(R) if zs else Polygon()
        if kind == 'pplain' or 0.02 <= zu.area / R.area <= 0.3:
            return [[list(c) for c in p.exterior.coords[:-1]] for z in zs for p in Z0.polys(z.buffer(0).intersection(R))]
    return []

if __name__ == '__main__':
    if sys.argv[1] == 'zones':
        pool = sys.argv[6] if len(sys.argv) > 6 else 'test'
        print(json.dumps(zones_for2(int(sys.argv[5]), sys.argv[4], float(sys.argv[2]), float(sys.argv[3]), pool))); sys.exit(0)
    tag, s0, cnt = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]); pool = sys.argv[4] if len(sys.argv) > 4 else 'train'
    kinds = ['phole', 'pragged', 'phole', 'pragged', 'pplain']
    out = []; fail = 0
    for i in range(cnt):
        try: r = gen2(s0 + i, kinds[i % 5], 0 if i % 3 == 0 else 1, pool)
        except Exception as e: r = None; print('ERR', s0 + i, repr(e)[:100])
        if r: out.append(r)
        else: fail += 1
    json.dump(out, open(f'data/zgen_{tag}.json', 'w')); print(f'{tag}: {len(out)} пазлів, невдач {fail}')
